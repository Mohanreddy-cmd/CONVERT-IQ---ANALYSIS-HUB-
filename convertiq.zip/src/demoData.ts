import { GlobalFilters, UnifiedMetrics } from "./types";

export const DEFAULT_FILTERS: GlobalFilters = {
  dateRange: "30d",
  region: "all",
  device: "all",
  product: "all",
  channel: "all",
  customerSegment: "all",
};

// Generates dynamic analytics metrics derived from applied global filters
export function getFilteredMetrics(filters: GlobalFilters): UnifiedMetrics {
  // Let's create a scalable base factors depending on filters
  let scaleFactor = 1.0;
  let customAov = 86.40;
  let customCR = 2.45;
  let customCartAbandonment = 68.4;
  let customReturningRate = 26.2;

  // 1. Date Range adjustments
  if (filters.dateRange === "7d") {
    scaleFactor *= 0.23;
  } else if (filters.dateRange === "90d") {
    scaleFactor *= 3.0;
  }

  // 2. Region adjustments
  if (filters.region !== "all") {
    scaleFactor *= 0.35; // Each region holds a slice of the global pie
    if (filters.region === "Americas") {
      scaleFactor *= 1.4;
      customAov = 94.50;
      customCR = 2.62;
    } else if (filters.region === "Europe") {
      scaleFactor *= 1.1;
      customAov = 82.00;
      customCR = 2.38;
    } else if (filters.region === "APAC") {
      scaleFactor *= 0.8;
      customAov = 78.50;
      customCR = 2.15;
    } else if (filters.region === "MEA") {
      scaleFactor *= 0.4;
      customAov = 72.00;
      customCR = 1.95;
    }
  }

  // 3. Device adjustments
  if (filters.device !== "all") {
    scaleFactor *= 0.48; // Distribute device weights
    if (filters.device === "Desktop") {
      scaleFactor *= 1.2;
      customAov = 105.00;
      customCR = 3.25;
      customCartAbandonment = 58.2;
    } else if (filters.device === "Mobile") {
      scaleFactor *= 0.95;
      customAov = 68.20;
      customCR = 1.78;
      customCartAbandonment = 74.5;
    } else if (filters.device === "Tablet") {
      scaleFactor *= 0.18;
      customAov = 88.00;
      customCR = 2.12;
      customCartAbandonment = 65.8;
    }
  }

  // 4. Marketing Channel adjustments
  if (filters.channel !== "all") {
    scaleFactor *= 0.25;
    if (filters.channel === "Google Organic") {
      customCR = 3.10;
      customAov = 92.00;
    } else if (filters.channel === "Meta Social") {
      customCR = 1.92;
      customAov = 76.80;
    } else if (filters.channel === "Influencer") {
      customCR = 2.24;
      customAov = 84.50;
    } else if (filters.channel === "Email Campaign") {
      customCR = 4.15;
      customAov = 108.00;
    } else if (filters.channel === "Direct") {
      customCR = 2.80;
      customAov = 89.20;
    }
  }

  // 5. Product Catalog adjustments
  if (filters.product !== "all") {
    scaleFactor *= 0.28;
    if (filters.product === "Starlight Pro") {
      customAov = 149.00;
      customCR = 2.10;
    } else if (filters.product === "Aura Leather") {
      customAov = 185.00;
      customCR = 1.65;
      customCartAbandonment = 78.4;
    } else if (filters.product === "Sonic Wave") {
      customAov = 89.00;
      customCR = 2.85;
    } else if (filters.product === "Titan Fit") {
      customAov = 65.00;
      customCR = 3.10;
    }
  }

  // Calculate scaled metrics
  const defaultTotalVisitors = 184500;
  const visitors = Math.round(defaultTotalVisitors * scaleFactor);
  const conversionRate = parseFloat(customCR.toFixed(2));
  const aov = parseFloat(customAov.toFixed(2));
  const cartAbandonment = parseFloat(customCartAbandonment.toFixed(2));
  const returningCustomerRate = parseFloat(customReturningRate.toFixed(2));

  // Calculated orders and revenue
  const orders = Math.round(visitors * (conversionRate / 100));
  const revenue = Math.round(orders * aov);

  // Generate date ranges for trends
  const daysCount = filters.dateRange === "7d" ? 7 : filters.dateRange === "90d" ? 90 : 30;
  const revenueTrend = [];
  const conversionTrend = [];

  for (let i = daysCount; i > 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const dateStr = d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
    
    // Add custom sinusoidal variance to trends
    const sinFactor = Math.sin(i / 3) * 0.15 + 1.0;
    const randomFactor = 0.92 + Math.random() * 0.16;
    const dayRevenue = Math.round((revenue / daysCount) * sinFactor * randomFactor);
    const lastYearRevenue = Math.round(dayRevenue * 0.88 * (1.0 + Math.cos(i / 4) * 0.1));
    const dayCR = parseFloat((conversionRate * (0.9 + Math.sin(i / 5) * 0.08) * randomFactor).toFixed(2));

    revenueTrend.push({
      date: dateStr,
      value: dayRevenue,
      lastYear: lastYearRevenue,
    });

    conversionTrend.push({
      date: dateStr,
      value: dayCR,
    });
  }

  // E-commerce Funnel simulation
  const fVisitors = visitors;
  const fViews = Math.round(fVisitors * 0.74);
  const fCarts = Math.round(fViews * 0.28);
  const fCheckouts = Math.round(fCarts * 0.38);
  const fPurchases = orders;

  const currentAOV = aov || 85.00;

  const funnelData = [
    { stage: "Sessions (Traffic)", value: fVisitors, percentage: 100, dropoff: 0, revenueLeakage: 0 },
    { stage: "Product Page Views", value: fViews, percentage: parseInt(((fViews / fVisitors) * 100).toFixed(0)), dropoff: Math.round(((fVisitors - fViews) / fVisitors) * 100), revenueLeakage: Math.max(0, fVisitors - fViews) * currentAOV },
    { stage: "Add To Cart", value: fCarts, percentage: parseInt(((fCarts / fVisitors) * 100).toFixed(0)), dropoff: Math.round(((fViews - fCarts) / fViews) * 100), revenueLeakage: Math.max(0, fViews - fCarts) * currentAOV },
    { stage: "Initiate Checkout", value: fCheckouts, percentage: parseInt(((fCheckouts / fVisitors) * 100).toFixed(0)), dropoff: Math.round(((fCarts - fCheckouts) / fCarts) * 100), revenueLeakage: Math.max(0, fCarts - fCheckouts) * currentAOV },
    { stage: "Success Purchase", value: fPurchases, percentage: parseInt(((fPurchases / fVisitors) * 100).toFixed(0)), dropoff: Math.round(((fCheckouts - fPurchases) / fCheckouts) * 100), revenueLeakage: Math.max(0, fCheckouts - fPurchases) * currentAOV },
  ];

  // Marketing Channels performance simulation
  const channelPerformance = [
    {
      channel: "Google Organic",
      visitors: Math.round(visitors * 0.38),
      orders: Math.round(orders * 0.44),
      conversion: parseFloat((conversionRate * 1.2).toFixed(2)),
      revenue: Math.round(revenue * 0.42),
      roi: 3.8,
    },
    {
      channel: "Meta Social Ads",
      visitors: Math.round(visitors * 0.26),
      orders: Math.round(orders * 0.20),
      conversion: parseFloat((conversionRate * 0.8).toFixed(2)),
      revenue: Math.round(revenue * 0.18),
      roi: 2.3,
    },
    {
      channel: "Instagram Influencers",
      visitors: Math.round(visitors * 0.16),
      orders: Math.round(orders * 0.13),
      conversion: parseFloat((conversionRate * 0.85).toFixed(2)),
      revenue: Math.round(revenue * 0.14),
      roi: 2.8,
    },
    {
      channel: "Email Newsletter",
      visitors: Math.round(visitors * 0.12),
      orders: Math.round(orders * 0.18),
      conversion: parseFloat((conversionRate * 1.5).toFixed(2)),
      revenue: Math.round(revenue * 0.21),
      roi: 5.4,
    },
    {
      channel: "Direct Traffic",
      visitors: Math.round(visitors * 0.08),
      orders: Math.round(orders * 0.05),
      conversion: parseFloat((conversionRate * 0.65).toFixed(2)),
      revenue: Math.round(revenue * 0.05),
      roi: 0, // Organic direct
    },
  ];

  // Specific catalog product performance simulation
  const productPerformance = [
    {
      name: "Starlight Pro Wireless Headphones",
      views: Math.round(visitors * 0.22),
      cartInserts: Math.round(visitors * 0.22 * 0.12),
      orders: Math.round(orders * 0.24),
      revenue: Math.round(orders * 0.24 * 149),
      conversion: parseFloat((conversionRate * 1.1).toFixed(2)),
    },
    {
      name: "Aura Leather Messenger Bag",
      views: Math.round(visitors * 0.18),
      cartInserts: Math.round(visitors * 0.18 * 0.14),
      orders: Math.round(orders * 0.13),
      revenue: Math.round(orders * 0.13 * 185),
      conversion: parseFloat((conversionRate * 0.72).toFixed(2)),
    },
    {
      name: "Sonic Wave Waterproof Speaker",
      views: Math.round(visitors * 0.32),
      cartInserts: Math.round(visitors * 0.32 * 0.08),
      orders: Math.round(orders * 0.35),
      revenue: Math.round(orders * 0.35 * 89),
      conversion: parseFloat((conversionRate * 1.15).toFixed(2)),
    },
    {
      name: "Titan Fit Waterproof Smartwatch",
      views: Math.round(visitors * 0.28),
      cartInserts: Math.round(visitors * 0.28 * 0.09),
      orders: Math.round(orders * 0.28),
      revenue: Math.round(orders * 0.28 * 65),
      conversion: parseFloat((conversionRate * 1.0).toFixed(2)),
    },
  ];

  // Geographic breakdowns
  const regionPerformance = [
    { region: "North Americas", orders: Math.round(orders * 0.52), revenue: Math.round(revenue * 0.55), conversion: parseFloat((conversionRate * 1.1).toFixed(2)) },
    { region: "European Union", orders: Math.round(orders * 0.24), revenue: Math.round(revenue * 0.22), conversion: parseFloat((conversionRate * 0.95).toFixed(2)) },
    { region: "Asia Pacific", orders: Math.round(orders * 0.16), revenue: Math.round(revenue * 0.15), conversion: parseFloat((conversionRate * 0.9).toFixed(2)) },
    { region: "Middle East/Africa", orders: Math.round(orders * 0.08), revenue: Math.round(revenue * 0.08), conversion: parseFloat((conversionRate * 0.85).toFixed(2)) },
  ];

  // Device type breakdowns
  const devicePerformance = [
    { device: "Desktop", visitors: Math.round(visitors * 0.44), orders: Math.round(orders * 0.56), conversion: parseFloat((conversionRate * 1.3).toFixed(2)), revenue: Math.round(revenue * 0.58) },
    { device: "Mobile", visitors: Math.round(visitors * 0.49), orders: Math.round(orders * 0.38), conversion: parseFloat((conversionRate * 0.78).toFixed(2)), revenue: Math.round(revenue * 0.36) },
    { device: "Tablet", visitors: Math.round(visitors * 0.07), orders: Math.round(orders * 0.06), conversion: parseFloat((conversionRate * 0.85).toFixed(2)), revenue: Math.round(revenue * 0.06) },
  ];

  // Cohort Heatmap retention
  const cohortData = [
    { cohort: "Jan Cohort", size: 1250, m1: 100, m2: 24.2, m3: 16.5, m4: 12.8, m5: 9.6 },
    { cohort: "Feb Cohort", size: 1420, m1: 100, m2: 26.8, m3: 18.2, m4: 14.1, m5: 10.3 },
    { cohort: "Mar Cohort", size: 1510, m1: 100, m2: 22.4, m3: 15.1, m4: 11.2, m5: 8.4 },
    { cohort: "Apr Cohort", size: 1680, m1: 100, m2: 25.1, m3: 17.4, m4: 12.9, m5: 0 },
    { cohort: "May Cohort", size: 1950, m1: 100, m2: 27.5, m3: 19.1, m4: 0, m5: 0 },
  ];

  return {
    revenue,
    orders,
    conversionRate,
    aov,
    cartAbandonment,
    returningCustomerRate,
    revenueTrend,
    conversionTrend,
    funnelData,
    channelPerformance,
    productPerformance,
    regionPerformance,
    devicePerformance,
    cohortData,
  };
}

// Full premium offline intelligence dataset response used during validation
export const OFFLINE_AI_PAYLOAD = {
  executiveSummary: "ConvertIQ intelligence indicates healthy conversion velocity but isolated cart leakages. Over the last operational window, total conversion peaked near 2.45% under high direct search traffic, whilst mobile transactions represent the highest volume opportunity with 49% traffic share but only 36% revenue capturing due to cart friction.",
  conversionInsights: "The multi-stage sales stream displays an optimized top-of-funnel (74% to Product Views). However, deep leakage is isolated when migrating carts to final checkouts where 68.4% of potential buyers abandon. This drop corresponds with unexpected shipping calculations and mobile processing times.",
  customerJourneyInsights: "Common high-conversion paths begin on organic content nodes, touch product cards, and end with Apple Pay checkouts. Users on Cohort cycles show stabilization by Month 3 (Jan/Feb cohorts holding ~10-14% premium active user indices). Churn warning alerts are triggered for Day-14 disengaged VIP segments.",
  marketingInsights: "Google Organic search leads margins with a 3.10% Conversion rate, followed in raw efficiency by Email Campaigns representing a highly cost-effective 5.4x ROI. Meta Ad campaigns are scaling traffic rapidly but require checkout custom targets to boost their 2.3x ROI.",
  productInsights: "The Sonic Wave Waterproof Speaker yields high checkout transition ratios. Conversely, the high-margin Aura Leather Messenger Bag attracts attention (Views: 18%) but exhibits critical abandonment (representing 28% of total checkout volume loss). Fix shipping weight indicators on this model.",
  recommendations: [
    {
      title: "Consolidate checkout options with Apple/Google Pay",
      description: "Allow instant checkout directly on product cards to reduce form validation hurdles which represents 41% of mobile funnel abandons.",
      priority: "high",
      impact: "Projected +0.45% direct checkout lift"
    },
    {
      title: "Activate immediate Cart abandonment push reminders",
      description: "Trigger SMS and dynamic email reminders within 15 minutes of abandonment, capturing top of mind high-affinity users.",
      priority: "high",
      impact: "Recoups estimated $14,000 monthly leakages"
    },
    {
      title: "Introduce free shipping thresholds starting at $75+",
      description: "Align flat-rate transparency upfront at cart view models, totally bypassing unexpected checkout surcharge shocks.",
      priority: "medium",
      impact: "Reduces cart abandonment by estimated absolute 5%"
    },
    {
      title: "Personalize Day-30 retargeting recommendations",
      description: "Re-engage cold accounts with context-specific accessories dynamically generated from their previous purchasing history.",
      priority: "low",
      impact: "+8.2% Returning user cohort scale"
    }
  ],
  anomalies: [
    {
      title: "Anomalous checkout leakage in Leather Messenger catalog",
      metric: "Aura Bag Abandonment",
      severity: "critical",
      details: "Checkout abandoned levels have surged past 78% on mobile devices, denoting layout or payment verification blockages."
    },
    {
      title: "Email campaign ROI spike outperformer",
      metric: "Newsletter revenue share",
      severity: "warning",
      details: "Email traffic is contributing 21% of gross margins. Opportunities to scale newsletter frequencies to twice weekly are highly recommended."
    }
  ]
};
