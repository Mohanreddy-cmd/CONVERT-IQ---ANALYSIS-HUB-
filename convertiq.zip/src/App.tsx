import { useState, useEffect } from "react";
import {
  Sparkles,
  Inbox,
  TrendingUp,
  BrainCircuit,
  MessageSquare,
  PanelRightClose,
  PanelRight,
  Database,
  ArrowRight
} from "lucide-react";

import Sidebar from "./components/Sidebar";
import Header from "./components/Header";
import AboutPage from "./components/AboutPage";
import ProcessingOverlay from "./components/ProcessingOverlay";
import DashboardHome from "./components/DashboardHome";
import EDAHub from "./components/EDAHub";
import AIInsightsPanel from "./components/AIInsightsPanel";
import CustomAnalysisPanel from "./components/CustomAnalysisPanel";
import ReportsCenter from "./components/ReportsCenter";

import { ActiveTab, GlobalFilters, AIAnalysisResult, UploadHistoryItem, IngestedRecord } from "./types";
import { DEFAULT_FILTERS, getFilteredMetrics, OFFLINE_AI_PAYLOAD } from "./demoData";
import { AnalyticsService } from "./services/analyticsService";
import { AIInsightEngine } from "./services/aiInsightEngine";

export default function App() {
  const [theme, setTheme] = useState<"dark" | "light">("light");
  const [activeTab, setActiveTab] = useState<ActiveTab>("about");
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isRightPanelExpanded, setIsRightPanelExpanded] = useState(false); // keep closed by default so layout stays pristine

  // Core filters and simulated tickers
  const [filters, setFilters] = useState<GlobalFilters>(DEFAULT_FILTERS);
  const [isSimulating, setIsSimulating] = useState(false);

  // Conversion Preference optimization goal state
  const [conversionPreference, setConversionPreference] = useState<string>(
    "Optimize checkout completion rate and mobile funnel conversion"
  );

  // Ingest state
  const [uploadedData, setUploadedData] = useState<IngestedRecord[]>([]);
  const [history, setHistory] = useState<UploadHistoryItem[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastUploadedFile, setLastUploadedFile] = useState<string>("");

  // AI Insights State with loading indicator
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysisResult>(OFFLINE_AI_PAYLOAD);
  const [analysisLoading, setAnalysisLoading] = useState(false);

  // Automated EDA generated report persistence
  const [generatedEDAReport, setGeneratedEDAReport] = useState<any | null>(null);

  // Global Q&A tracking customer queries asked
  const [chatHistory, setChatHistory] = useState<{ sender: "user" | "assistant"; text: string; time: string }[]>([]);

  // States to pass custom query analysis selections down to CustomAnalysisPanel
  const [passedAnalysisType, setPassedAnalysisType] = useState<"apriori" | "segmentation" | "salesTrend" | "customFormula" | undefined>(undefined);
  const [passedCustomPrompt, setPassedCustomPrompt] = useState<string>("");
  const [passedAutoTrigger, setPassedAutoTrigger] = useState<boolean>(false);

  // Popup overlay triggers
  const [showAfterEdaPopup, setShowAfterEdaPopup] = useState<boolean>(false);
  const [popupQueryInput, setPopupQueryInput] = useState<string>("");

  const matchAndTriggerAnalysisFromPopup = (queryText: string) => {
    const textLower = queryText.toLowerCase();
    let matchedType: "apriori" | "segmentation" | "salesTrend" | "customFormula" = "customFormula";
    
    if (
      textLower.includes("basket") || 
      textLower.includes("apriori") || 
      textLower.includes("bought together") || 
      textLower.includes("co-purchase") ||
      textLower.includes("affinity") || 
      textLower.includes("bundle") ||
      textLower.includes("item") ||
      textLower.includes("association")
    ) {
      matchedType = "apriori";
    } else if (
      textLower.includes("segment") || 
      textLower.includes("cluster") || 
      textLower.includes("rfm") || 
      textLower.includes("cohort") || 
      textLower.includes("demographic") ||
      textLower.includes("group") || 
      textLower.includes("vip") ||
      textLower.includes("churn")
    ) {
      matchedType = "segmentation";
    } else if (
      textLower.includes("trend") || 
      textLower.includes("sale") || 
      textLower.includes("velocity") || 
      textLower.includes("regression") || 
      textLower.includes("forecast") || 
      textLower.includes("revenue") ||
      textLower.includes("growth") ||
      textLower.includes("projection")
    ) {
      matchedType = "salesTrend";
    }
    
    setPassedAnalysisType(matchedType);
    setPassedCustomPrompt(queryText);
    setPassedAutoTrigger(true);
    setPopupQueryInput("");
    setActiveTab("customAnalysis");
    setShowAfterEdaPopup(false);
  };

  // Sync theme class to root container html
  useEffect(() => {
    const root = document.documentElement;
    if (theme === "dark") {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
  }, [theme]);

  // Compute calculated metrics dynamic of filters applied
  const currentMetrics = (!isSimulating && uploadedData.length > 0)
    ? AnalyticsService.generateDashboardMetrics(filters)
    : getFilteredMetrics(filters);

  // Pull new insights from server
  const fetchNewInsights = async () => {
    setAnalysisLoading(true);
    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          dataSummary: lastUploadedFile ? `Parsed structure: ${lastUploadedFile} with ${currentMetrics.orders} orders.` : "Demo Dataset Log",
          filters: filters,
          metrics: currentMetrics,
          preference: conversionPreference // Pass conversion target preference directly to the API
        })
      });
      if (response.ok) {
        const data = await response.json();
        setAiAnalysis(data);
      } else {
        console.warn("Could not retrieve AI analysis, serving dynamic localized insights.");
        setAiAnalysis(AIInsightEngine.generateInsights(currentMetrics));
      }
    } catch (err) {
      console.warn("Secure pipeline offline, using local analytics engine:", err);
      setAiAnalysis(AIInsightEngine.generateInsights(currentMetrics));
    } finally {
      setAnalysisLoading(false);
    }
  };

  // Pull automated responses for custom-asked questions
  const handleAskCustomPrompt = async (promptText: string): Promise<string> => {
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: promptText,
          filters: filters,
          preference: conversionPreference
        })
      });
      if (response.ok) {
        const data = await response.json();
        return data.reply;
      }
    } catch (err) {
      console.warn("Chat pipeline timed out, running localized heuristic co-pilot:", err);
    }
    
    // Heuristic fallback text answer aligned properly with layperson preferences
    return `Based on your optimization preference ("${conversionPreference}") and active metrics stream, we advise optimizing checkout steps particularly for mobile browsers, introducing digital wallet checks, and trimming legacy billing form fields.`;
  };

  // Re-fetch semantic models when filters or preferences undergo updates
  useEffect(() => {
    fetchNewInsights();
  }, [filters, activeTab, conversionPreference]);

  const handleDataParsed = (recordsCount: number, fileName: string, fileDataSummary: any, parsedRecords: IngestedRecord[]) => {
    setLastUploadedFile(fileName);
    AnalyticsService.setStore(parsedRecords);
    setUploadedData(parsedRecords);
    setIsSimulating(false);
    setGeneratedEDAReport(true); // Automatically pre-generate exploratory analytics report
  };

  const triggerOnExploreDemo = () => {
    setIsSimulating(true);
    setGeneratedEDAReport(true); // Automatically populate EDA report for demo dataset
    setActiveTab("dashboard");
    setShowAfterEdaPopup(true); // Show the check-EDA & specific-analysis popup modal
  };

  return (
    <div
      id="app-viewport-root"
      className="min-h-screen flex text-gray-800 dark:text-zinc-100 bg-gray-55/40 dark:bg-zinc-950 font-sans transition-colors duration-300 relative selection:bg-cyan-500/20"
    >
      
      {/* Dynamic step-by-step processing overlay */}
      {isProcessing && (
        <ProcessingOverlay
          fileName={lastUploadedFile}
          onComplete={() => {
            setIsProcessing(false);
            setActiveTab("dashboard");
            fetchNewInsights();
            setShowAfterEdaPopup(true); // Show popup modal after dynamic parsing finishes
          }}
        />
      )}

      {/* SOLID WORKSPACE ECOSYSTEM */}
      <>
        {/* Collapsible Left Navigation Sidebar */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          isCollapsed={isSidebarCollapsed}
          setCollapsed={setIsSidebarCollapsed}
        />

        {/* Core Body Workspace Container */}
        <div
          id="workspace-body-container"
          className={`flex-1 flex flex-col min-h-screen transition-all duration-300 ${
            isSidebarCollapsed ? "ml-16" : "ml-64"
          } ${isRightPanelExpanded ? "mr-96" : "mr-0"}`}
        >
          {/* Sticky Header Topbar */}
          <Header
            theme={theme}
            toggleTheme={() => setTheme(theme === "light" ? "dark" : "light")}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            filters={filters}
            setFilters={setFilters}
            isSimulating={isSimulating}
            setIsSimulating={setIsSimulating}
          />

          {/* Render Active Tab Workspace View portal */}
          <main className="flex-1 p-6 overflow-y-auto space-y-6 relative max-w-7xl w-full mx-auto">
            
            {activeTab === "about" && (
              <div className="animate-fadeIn">
                <AboutPage
                  onDataParsed={handleDataParsed}
                  uploadHistory={history}
                  setUploadHistory={setHistory}
                  onStartProcessing={() => setIsProcessing(true)}
                  conversionPreference={conversionPreference}
                  setConversionPreference={setConversionPreference}
                  triggerOnExploreDemo={triggerOnExploreDemo}
                />
              </div>
            )}

            {activeTab === "dashboard" && (
              <div className="animate-fadeIn">
                <DashboardHome
                  metrics={currentMetrics}
                  filters={filters}
                  setFilters={setFilters}
                  uploadedData={uploadedData}
                  isSimulating={isSimulating}
                  onSelectPreset={() => setIsSimulating(true)}
                />
              </div>
            )}

            {activeTab === "eda" && (
              <div className="animate-fadeIn">
                <EDAHub
                  uploadedData={uploadedData}
                  isSimulating={isSimulating}
                  onSelectPreset={() => setIsSimulating(true)}
                  generatedEDAReport={generatedEDAReport}
                  setGeneratedEDAReport={setGeneratedEDAReport}
                  onEdaCompleted={() => setShowAfterEdaPopup(true)}
                />
              </div>
            )}

            {activeTab === "customAnalysis" && (
              <div className="animate-fadeIn">
                <CustomAnalysisPanel
                  uploadedData={uploadedData}
                  isSimulating={isSimulating}
                  onSelectPreset={() => setIsSimulating(true)}
                  initialAnalysisType={passedAnalysisType}
                  initialCustomPrompt={passedCustomPrompt}
                  autoTriggerAnalysis={passedAutoTrigger}
                />
              </div>
            )}

            {activeTab === "optimizer" && (
              <div className="animate-fadeIn">
                <AIInsightsPanel
                  insights={aiAnalysis}
                  loading={analysisLoading}
                  onRefresh={fetchNewInsights}
                  onAskCustomPrompt={handleAskCustomPrompt}
                  conversionPreference={conversionPreference}
                  chatHistory={chatHistory}
                  setChatHistory={setChatHistory}
                />
              </div>
            )}

            {activeTab === "reports" && (
              <div className="animate-fadeIn">
                <ReportsCenter
                  metrics={currentMetrics}
                  insights={aiAnalysis}
                  uploadedData={uploadedData}
                  filters={filters}
                  isSimulating={isSimulating}
                  chatHistory={chatHistory}
                />
              </div>
            )}

          </main>
        </div>

        {/* Right Floating Co-Pilot Workspace Sidebar */}
        <div
          className={`fixed right-0 top-16 bottom-0 z-20 bg-white dark:bg-zinc-900 border-l border-gray-200/60 dark:border-zinc-800/60 transition-all duration-300 shadow-xl overflow-y-auto ${
            isRightPanelExpanded ? "w-96 p-4" : "w-0 p-0 overflow-hidden"
          }`}
        >
          {isRightPanelExpanded && (
            <AIInsightsPanel
              insights={aiAnalysis}
              loading={analysisLoading}
              onRefresh={fetchNewInsights}
              onAskCustomPrompt={handleAskCustomPrompt}
              conversionPreference={conversionPreference}
              chatHistory={chatHistory}
              setChatHistory={setChatHistory}
            />
          )}
        </div>

        {/* Floating toggle button for optional right pane */}
        <button
          id="panel-right-toggle-btn"
          onClick={() => setIsRightPanelExpanded(!isRightPanelExpanded)}
          className="fixed bottom-6 right-6 z-30 h-11 w-11 rounded-full bg-gradient-to-tr from-cyan-500 to-indigo-600 text-white flex items-center justify-center shadow-lg hover:opacity-95 transition-all select-none cursor-pointer focus:outline-none"
          title={isRightPanelExpanded ? "Hide Co-Pilot Pane" : "Expand Co-Pilot Pane"}
        >
          {isRightPanelExpanded ? (
            <PanelRightClose className="h-5 w-5" />
          ) : (
            <PanelRight className="h-5 w-5" />
          )}
        </button>

        {/* Success / Prompt Navigation Popup Modal */}
        {showAfterEdaPopup && (
          <div id="eda-success-popup-backdrop" className="fixed inset-0 z-50 bg-neutral-950/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
            <div className="bg-white dark:bg-zinc-900 border border-gray-150 dark:border-zinc-800 rounded-3xl p-6 md:p-8 max-w-lg w-full shadow-2xl relative overflow-hidden flex flex-col gap-6 text-left transform scale-100 transition-all">
              
              {/* Close button top right */}
              <button 
                id="eda-popup-close-btn"
                onClick={() => setShowAfterEdaPopup(false)}
                className="absolute top-4 right-4 p-2 rounded-full text-gray-400 hover:text-gray-650 dark:hover:text-zinc-200 hover:bg-gray-100 dark:hover:bg-zinc-850 transition-all cursor-pointer"
              >
                <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>

              {/* Icon & Title */}
              <div className="flex gap-4 items-start select-none">
                <div className="h-12 w-12 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-500 shrink-0 animate-pulse">
                  <Sparkles className="h-6 w-6" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-lg font-black font-sans tracking-tight text-gray-905 dark:text-white leading-tight">
                    Insights Prepared & Cached!
                  </h3>
                  <p className="text-xs text-gray-400 dark:text-zinc-400 leading-normal">
                    The 25-section Exploratory Data Analysis (EDA) report of segments and statistical coefficients is ready.
                  </p>
                </div>
              </div>

              {/* Separator / Choice split */}
              <div className="border-t border-gray-100 dark:border-zinc-800 my-1" />

              {/* Two choice sections */}
              <div className="space-y-4">
                
                {/* Option A: Navigate directly to EDA */}
                <div className="space-y-2">
                  <h4 className="text-[10px] font-mono font-black text-indigo-650 dark:text-indigo-400 uppercase tracking-widest leading-none">Option A: Read Full EDA</h4>
                  <button
                    id="eda-popup-navigate-eda"
                    onClick={() => {
                      setActiveTab("eda");
                      setShowAfterEdaPopup(false);
                    }}
                    className="w-full flex items-center justify-between text-left p-3.5 bg-gradient-to-r from-indigo-50/50 to-cyan-50/35 dark:from-zinc-850/60 dark:to-zinc-800/40 border border-indigo-100/50 dark:border-zinc-700/60 hover:border-indigo-400 dark:hover:border-indigo-500 rounded-2xl transition-all cursor-pointer group"
                  >
                    <div className="space-y-0.5">
                      <span className="block text-xs font-black text-indigo-950 dark:text-indigo-200 group-hover:text-indigo-600 transition-colors">
                        Explore Automated EDA Receipt
                      </span>
                      <p className="text-[10px] text-gray-450 dark:text-zinc-400">
                        Examine acquisition shares, cohort retention models, and RFM details on-the-fly.
                      </p>
                    </div>
                    <ArrowRight className="h-4.5 w-4.5 text-indigo-500 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>

                {/* Option B: Match custom specific analysis */}
                <div className="space-y-2">
                  <h4 className="text-[10px] font-mono font-black text-purple-650 dark:text-purple-400 uppercase tracking-widest leading-none">Option B: Target Specific Advanced Analysis</h4>
                  <div className="space-y-3 bg-gray-55/65 dark:bg-zinc-950/60 p-4 rounded-2xl border border-gray-200/60 dark:border-zinc-800">
                    <p className="text-[10.5px] text-gray-500 dark:text-zinc-400 leading-normal">
                      Or prompt ConvertIQ with a targeted question. We will segment the calculation model (basket rules, buyer cohorts, or sales trends):
                    </p>
                    
                    <div className="space-y-2">
                      <textarea
                        id="eda-popup-custom-query"
                        value={popupQueryInput}
                        onChange={(e) => setPopupQueryInput(e.target.value)}
                        placeholder="e.g., 'What products sell together?' or 'Calculate customer groupings' or 'Forecast revenue vel'."
                        className="w-full text-xs p-2.5 rounded-xl border border-gray-200 dark:border-zinc-750 bg-white dark:bg-zinc-900 outline-none focus:border-indigo-400 text-gray-800 dark:text-zinc-200 min-h-[60px] resize-none"
                      />

                      <button
                        id="eda-popup-run-analysis"
                        disabled={!popupQueryInput.trim()}
                        onClick={() => matchAndTriggerAnalysisFromPopup(popupQueryInput)}
                        className="w-full inline-flex items-center justify-center gap-2 text-xs font-black text-white bg-indigo-650 hover:bg-indigo-700 dark:bg-indigo-600 rounded-xl p-2.5 shadow transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <BrainCircuit className="h-4 w-4" />
                        <span>Match & Perform Analysis</span>
                      </button>
                    </div>
                  </div>
                </div>

              </div>

            </div>
          </div>
        )}
      </>

    </div>
  );
}
