export type ActiveTab =
  | "about"
  | "dashboard"
  | "eda"
  | "customAnalysis"
  | "optimizer"
  | "reports";

export interface IngestedRecord {
  timestamp: string;
  user_id: string;
  session_id: string;
  product_id: string;
  product_name: string;
  category: string;
  event_type: string; // "view" | "cart" | "checkout" | "purchase"
  traffic_source: string;
  device_type: string;
  region: string;
  revenue: number;
}

export interface ValidationSummary {
  isValid: boolean;
  totalRecords: number;
  duplicateCount: number;
  emptyValueCount: number;
  invalidTimestampCount: number;
  missingColumns: string[];
  errors: string[];
}

export interface GlobalFilters {
  dateRange: string; // e.g. "30d" | "7d" | "90d"
  region: string;     // e.g. "all" | "Americas" | "Europe" | "APAC" | "MEA"
  device: string;     // e.g. "all" | "Desktop" | "Mobile" | "Tablet"
  product: string;    // e.g. "all" | "Starlight Pro" | "Aura Leather" | "Sonic Wave" | "Titan Fit"
  channel: string;    // e.g. "all" | "Google Organic" | "Meta Social" | "Influencer" | "Email Campaign" | "Direct"
  customerSegment: string; // e.g. "all" | "New Customer" | "Returning" | "VIP/High Value"
}

export interface Recommendation {
  title: string;
  description: string;
  priority: "high" | "medium" | "low";
  impact: string;
}

export interface Anomaly {
  title: string;
  metric: string;
  severity: "critical" | "warning";
  details: string;
}

export interface AIAnalysisResult {
  executiveSummary: string;
  conversionInsights: string;
  customerJourneyInsights: string;
  marketingInsights: string;
  productInsights: string;
  recommendations: Recommendation[];
  anomalies: Anomaly[];
  revenueIncrInsight?: string;
  deviceContrastInsight?: string;
  productLeverInsight?: string;
}

export interface UploadHistoryItem {
  id: string;
  filename: string;
  fileSize: string;
  recordCount: number;
  timestamp: string;
  status: "success" | "validating" | "error";
  format: "CSV" | "JSON" | "XLSX";
}

export interface UnifiedMetrics {
  revenue: number;
  orders: number;
  conversionRate: number; // e.g. 2.45
  aov: number;            // e.g. 84.50
  cartAbandonment: number;// e.g. 68.2
  returningCustomerRate: number;// e.g. 24.8
  revenueTrend: { date: string; value: number; lastYear: number }[];
  conversionTrend: { date: string; value: number }[];
  funnelData: { stage: string; value: number; percentage: number; dropoff: number; revenueLeakage?: number }[];
  channelPerformance: { channel: string; visitors: number; orders: number; conversion: number; revenue: number; roi: number }[];
  productPerformance: { name: string; views: number; cartInserts: number; orders: number; revenue: number; conversion: number }[];
  regionPerformance: { region: string; orders: number; revenue: number; conversion: number }[];
  devicePerformance: { device: string; visitors: number; orders: number; conversion: number; revenue: number }[];
  cohortData: { cohort: string; size: number; m1: number; m2: number; m3: number; m4: number; m5: number }[];
}
