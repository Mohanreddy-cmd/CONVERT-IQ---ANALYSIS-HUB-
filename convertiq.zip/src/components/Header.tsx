import { useState, useEffect } from "react";
import {
  Bell,
  Search,
  User,
  Zap,
  CheckCircle,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  RefreshCw,
  LogOut,
  Sliders,
  Settings
} from "lucide-react";
import { ActiveTab, GlobalFilters } from "../types";
import ThemeToggle from "./ThemeToggle";

interface HeaderProps {
  theme: "dark" | "light";
  toggleTheme: () => void;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  filters: GlobalFilters;
  setFilters: (filters: GlobalFilters) => void;
  isSimulating: boolean;
  setIsSimulating: (simulating: boolean) => void;
}

export default function Header({
  theme,
  toggleTheme,
  activeTab,
  setActiveTab,
  filters,
  setFilters,
  isSimulating,
  setIsSimulating,
}: HeaderProps) {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  
  // Real-time ticker values
  const [liveUsers, setLiveUsers] = useState(1482);
  const [liveOrders, setLiveOrders] = useState(24);
  const [liveRevenue, setLiveRevenue] = useState(2140);
  const [liveCR, setLiveCR] = useState(2.45);

  // Notifications state
  const [notifications, setNotifications] = useState([
    {
      id: "n1",
      title: "Data Upload Completed",
      message: "Shopify Q1 store dataset valid & synced.",
      time: "2 mins ago",
      type: "success",
      read: false,
    },
    {
      id: "n2",
      title: "Cart Leak Alert",
      message: "Aura messenger bag abandonment spiked to 78.4%.",
      time: "15 mins ago",
      type: "warning",
      read: false,
    },
    {
      id: "n3",
      title: "Gemini Insights Ready",
      message: "Automated business report created successfully.",
      time: "1 hour ago",
      type: "success",
      read: true,
    },
    {
      id: "n4",
      title: "Google Channels surge",
      message: "Ad traffic spiked 15% in last 24 hours.",
      time: "3 hours ago",
      type: "info",
      read: true,
    }
  ]);

  // Simulate real-time ticking
  useEffect(() => {
    if (!isSimulating) return;

    const interval = setInterval(() => {
      setLiveUsers((prev) => Math.max(1200, prev + Math.floor(Math.random() * 15) - 7));
      setLiveCR((prev) => parseFloat(Math.max(1.8, Math.min(3.5, prev + (Math.random() * 0.1 - 0.05))).toFixed(2)));
      
      if (Math.random() > 0.7) {
        setLiveOrders((prev) => prev + 1);
        setLiveRevenue((prev) => prev + Math.floor(Math.random() * 60) + 40);
        
        // Push a live notification sometimes
        const newNotif = {
          id: String(Date.now()),
          title: "Live Purchase Processed!",
          message: `New standard checkout of $${(Math.random() * 80 + 35).toFixed(2)} completed.`,
          time: "Just now",
          type: "success",
          read: false,
        };
        setNotifications((prev) => [newNotif, ...prev.slice(0, 4)]);
      }
    }, 4500);

    return () => clearInterval(interval);
  }, [isSimulating]);

  const markAllRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <header className="sticky top-0 z-30 w-full h-16 flex items-center justify-between px-6 bg-white/80 dark:bg-zinc-900/80 backdrop-blur-md border-b border-gray-200/60 dark:border-zinc-800/60 transition-all duration-300">
      
      {/* Top Left Live Simulator Status Ticker */}
      <div className="flex items-center gap-4">
        {true && (
          <div className="flex items-center gap-1.5 p-1 px-2.5 rounded-full bg-cyan-50 dark:bg-cyan-950/40 border border-cyan-100 dark:border-cyan-900/40">
            <span className="relative flex h-2 w-2">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${isSimulating ? "bg-cyan-500" : "bg-zinc-400"}`}></span>
              <span className={`relative inline-flex rounded-full h-2 w-2 ${isSimulating ? "bg-cyan-500" : "bg-zinc-400"}`}></span>
            </span>
            <div className="flex items-center gap-3">
              <span className="text-[10px] font-bold tracking-tight text-cyan-700 dark:text-cyan-400 uppercase">
                {isSimulating ? "Live Feed" : "Feed Paused"}
              </span>
              <div className="hidden sm:flex items-center gap-4 text-[10px] text-gray-500 dark:text-zinc-400 font-mono">
                <span>Active: <strong className="text-gray-900 dark:text-white font-semibold">{liveUsers}</strong></span>
                <span>Revenue: <strong className="text-gray-900 dark:text-white font-semibold">${liveRevenue}</strong></span>
                <span>Live CR: <strong className="text-gray-900 dark:text-white font-semibold">{liveCR}%</strong></span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Top Right Action Area */}
      <div className="flex items-center gap-2">
        {/* Simulator controller button */}
        {true && (
          <button
            id="simulation-toggle-btn"
            onClick={() => setIsSimulating(!isSimulating)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold select-none border transition-all duration-200 focus:outline-none ${
              isSimulating
                ? "bg-emerald-50 text-emerald-700 border-emerald-200/60 dark:bg-emerald-950/20 dark:text-emerald-400 dark:border-emerald-900/60 hover:bg-emerald-100 hover:dark:bg-emerald-950/40"
                : "bg-gray-100 text-gray-600 border-gray-250 dark:bg-zinc-800 dark:text-zinc-400 dark:border-zinc-700 hover:bg-gray-200 hover:dark:bg-zinc-700"
            }`}
          >
            <RefreshCw className={`h-3 w-3 ${isSimulating ? "animate-spin duration-10000" : ""}`} />
            <span>{isSimulating ? "Simulation Live" : "Resume Simulation"}</span>
          </button>
        )}

        {/* Theme and notifications center */}
        <ThemeToggle theme={theme} toggleTheme={toggleTheme} />

        {/* Notifications Popover */}
        <div className="relative">
          <button
            id="notification-hub-btn"
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-2 rounded-xl text-gray-600 dark:text-zinc-300 hover:bg-gray-100 dark:hover:bg-zinc-800/80 border border-gray-200/40 dark:border-zinc-800/40 focus:outline-none"
          >
            <div className="relative">
              <Bell className="h-4.5 w-4.5" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-gradient-to-tr from-cyan-400 to-indigo-500"></span>
                </span>
              )}
            </div>
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-2xl shadow-xl z-50 overflow-hidden divide-y divide-gray-100 dark:divide-zinc-800/60 transition-all">
              <div className="p-3 px-4 flex items-center justify-between">
                <span className="text-xs font-bold text-gray-900 dark:text-white">Active Alerts Center</span>
                <button
                  onClick={markAllRead}
                  className="text-[10px] text-cyan-600 dark:text-cyan-400 hover:underline hover:text-cyan-500"
                >
                  Mark all read
                </button>
              </div>

              <div className="max-h-72 overflow-y-auto">
                {notifications.map((item) => (
                  <div
                    key={item.id}
                    className={`p-3 px-4 transition-colors ${
                      item.read ? "bg-white dark:bg-zinc-900" : "bg-cyan-50/20 dark:bg-cyan-950/10"
                    }`}
                  >
                    <div className="flex gap-2">
                      {item.type === "success" ? (
                        <CheckCircle className="h-4 w-4 text-emerald-500 mt-0.5" />
                      ) : (
                        <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5" />
                      )}
                      <div>
                        <p className="text-xs font-semibold text-gray-800 dark:text-zinc-200 leading-tight">
                          {item.title}
                        </p>
                        <p className="text-[10px] text-gray-500 dark:text-zinc-400 mt-0.5">
                          {item.message}
                        </p>
                        <span className="text-[9px] text-gray-400 dark:text-zinc-500 mt-1 block">
                          {item.time}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="p-2.5 text-center bg-gray-50 dark:bg-zinc-850">
                <button
                  onClick={() => {
                    setActiveTab("dashboard");
                    setShowNotifications(false);
                  }}
                  className="text-[10px] font-bold text-gray-600 dark:text-zinc-300 hover:text-gray-900 dark:hover:text-white"
                >
                  View active system console
                </button>
              </div>
            </div>
          )}
        </div>

        {/* User Account Drawer */}
        <div className="relative">
          <button
            id="user-profile-btn"
            onClick={() => setShowProfile(!showProfile)}
            className="flex items-center gap-2 p-1 pl-1.5 pr-2.5 rounded-xl border border-gray-200/50 dark:border-zinc-800 bg-gray-50 dark:bg-zinc-850 hover:bg-gray-100 dark:hover:bg-zinc-805 transition-colors focus:outline-none"
          >
            <div className="h-7.5 w-7.5 rounded-xl overflow-hidden bg-gradient-to-tr from-cyan-400 to-indigo-500 flex items-center justify-center text-white text-xs font-bold font-mono">
              S
            </div>
            <div className="hidden md:block text-left">
              <p className="text-[10px] font-bold text-gray-800 dark:text-zinc-200 leading-none">
                Sivalingam Siva
              </p>
              <p className="text-[9px] text-gray-400 dark:text-zinc-400 leading-none mt-1">
                Owner
              </p>
            </div>
          </button>

          {showProfile && (
            <div className="absolute right-0 mt-2 w-56 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-2xl shadow-xl z-50 overflow-hidden divide-y divide-gray-100 dark:divide-zinc-800/60 transition-all">
              <div className="p-3">
                <p className="text-xs font-bold text-gray-900 dark:text-white">Sivalingam Siva</p>
                <p className="text-[10px] text-gray-500 dark:text-zinc-400 truncate">sivalingamsiva077@gmail.com</p>
              </div>
              <div className="p-1 space-y-0.5">
                <button
                  onClick={() => {
                    setActiveTab("about");
                    setShowProfile(false);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-1.5 text-xs text-gray-600 dark:text-zinc-300 hover:bg-gray-50 dark:hover:bg-zinc-800/60 rounded-xl"
                >
                  <Sliders className="h-3.5 w-3.5" />
                  <span>Configure Store</span>
                </button>
                <button
                  onClick={() => {
                    setActiveTab("about");
                    setShowProfile(false);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-1.5 text-xs text-gray-600 dark:text-zinc-300 hover:bg-gray-50 dark:hover:bg-zinc-800/60 rounded-xl"
                >
                  <LogOut className="h-3.5 w-3.5" />
                  <span>Public About Page</span>
                </button>
              </div>
            </div>
          )}
        </div>

      </div>
    </header>
  );
}
