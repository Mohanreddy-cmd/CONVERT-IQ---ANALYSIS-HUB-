import React, { useState, useRef } from "react";
import {
  UploadCloud,
  FileSpreadsheet,
  FileCode,
  CheckCircle,
  AlertCircle,
  FileText,
  Clock,
  Sparkles,
  ArrowRight,
  Database,
  Download,
  AlertTriangle,
  Info
} from "lucide-react";
import { IngestedRecord, UploadHistoryItem, ValidationSummary } from "../types";
import { parseCSV, parseExcel, validateDataset, formatToIngestedRecords } from "../utils/fileParser";

interface UploadCenterProps {
  onDataParsed: (recordsCount: number, fileName: string, fileDataSummary: any, parsedRecords: IngestedRecord[]) => void;
  uploadHistory: UploadHistoryItem[];
  setUploadHistory: React.Dispatch<React.SetStateAction<UploadHistoryItem[]>>;
  onStartProcessing: () => void;
}

export default function UploadCenter({
  onDataParsed,
  uploadHistory,
  setUploadHistory,
  onStartProcessing
}: UploadCenterProps) {
  const [dragActive, setDragActive] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const [selectedFile, setSelectedFile] = useState<{
    name: string;
    size: string;
    count: number;
    dataSummary: any;
  } | null>(null);
  
  const [validationResult, setValidationResult] = useState<ValidationSummary | null>(null);
  const [parsedRecords, setParsedRecords] = useState<IngestedRecord[]>([]);
  const [validationError, setValidationError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelected(e.dataTransfer.files[0]);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileSelected(e.target.files[0]);
    }
  };

  const formatBytes = (bytes: number, decimals = 2) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i];
  };

  const handleFileSelected = (file: File) => {
    const extension = file.name.split(".").pop()?.toLowerCase();
    const authorized = ["csv", "xlsx", "xls"];
    if (!extension || !authorized.includes(extension)) {
      setValidationError("Incorrect format. Please upload a valid CSV (.csv) or Excel (.xlsx) file.");
      setSelectedFile(null);
      setValidationResult(null);
      setParsedRecords([]);
      return;
    }

    setValidationError(null);
    setUploadProgress(10);

    const reader = new FileReader();

    reader.onload = async (e) => {
      try {
        let rawRows: any[] = [];
        
        if (extension === "csv") {
          const text = e.target?.result as string;
          rawRows = await parseCSV(text);
        } else {
          const arrayBuffer = e.target?.result as ArrayBuffer;
          rawRows = parseExcel(arrayBuffer);
        }

        // Run structured schema validations
        const summary = validateDataset(rawRows);
        setValidationResult(summary);

        let formatted: IngestedRecord[] = [];
        if (summary.isValid) {
          formatted = formatToIngestedRecords(rawRows);
          setParsedRecords(formatted);
        } else {
          setParsedRecords([]);
        }

        // Simulate upload animation
        let progressVal = 10;
        const interval = setInterval(() => {
          progressVal += 18;
          if (progressVal >= 100) {
            clearInterval(interval);
            setUploadProgress(null);
            setSelectedFile({
              name: file.name,
              size: formatBytes(file.size),
              count: rawRows.length,
              dataSummary: {
                format: extension.toUpperCase(),
                rowCount: rawRows.length,
                columnsNormalized: rawRows.length > 0 ? Object.keys(rawRows[0]).map(k => k.trim().toLowerCase()) : []
              }
            });
          } else {
            setUploadProgress(progressVal);
          }
        }, 80);

      } catch (err: any) {
        setUploadProgress(null);
        setValidationError(`Failed to parse file: ${err.message || 'Unknown parsing error'}`);
        setValidationResult(null);
        setParsedRecords([]);
      }
    };

    if (extension === "csv") {
      reader.readAsText(file);
    } else {
      reader.readAsArrayBuffer(file);
    }
  };

  const executePipeline = async () => {
    if (!selectedFile || !validationResult || !validationResult.isValid) return;

    setUploadProgress(15);
    try {
      const fileFormat = selectedFile.name.endsWith(".csv") ? "CSV" : "XLSX" as "CSV" | "XLSX";

      // POST parsed datasets to the newly constructed backend processing architecture
      const response = await fetch("/api/generate-analytics", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          rawRows: parsedRecords,
          filters: {
            dateRange: "30d",
            region: "all",
            device: "all",
            product: "all",
            channel: "all",
            customerSegment: "all"
          }
        })
      });

      if (!response.ok) {
        throw new Error(`Pipeline rejection from server with response status ${response.status}`);
      }

      const resData = await response.json();
      if (!resData.success || !resData.validation.isValid) {
        setValidationError(resData.validation.errors.join(", ") || "Failed to generate analytics on backend.");
        setUploadProgress(null);
        return;
      }

      setUploadProgress(100);
      setTimeout(() => {
        setUploadProgress(null);
        
        const historyItem: UploadHistoryItem = {
          id: "u" + Date.now(),
          filename: selectedFile.name,
          fileSize: selectedFile.size,
          recordCount: selectedFile.count,
          timestamp: new Date().toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" }),
          status: "success",
          format: fileFormat
        };

        setUploadHistory(prev => [historyItem, ...prev]);
        onDataParsed(selectedFile.count, selectedFile.name, selectedFile.dataSummary, parsedRecords);
        onStartProcessing();
      }, 500);

    } catch (apiErr: any) {
      console.error("Ingestion pipeline failed:", apiErr);
      setValidationError(`Backend processing error: ${apiErr.message || "Server did not respond to analytical request."}`);
      setUploadProgress(null);
    }
  };

  const downloadSampleTemplate = () => {
    const csvContent = 
      "timestamp,user_id,session_id,product_id,product_name,category,event_type,traffic_source,device_type,region,revenue\n" +
      "2026-06-04T12:00:00Z,usr_101,sess_902,p_001,Starlight Pro Wireless Headphones,Electronics,view,Google Organic,Desktop,North Americas,0\n" +
      "2026-06-04T12:05:00Z,usr_101,sess_902,p_001,Starlight Pro Wireless Headphones,Electronics,cart,Google Organic,Desktop,North Americas,0\n" +
      "2026-06-04T12:10:00Z,usr_101,sess_902,p_001,Starlight Pro Wireless Headphones,Electronics,checkout,Google Organic,Desktop,North Americas,0\n" +
      "2026-06-04T12:12:00Z,usr_101,sess_902,p_001,Starlight Pro Wireless Headphones,Electronics,purchase,Google Organic,Desktop,North Americas,149.00\n" +
      "2026-06-04T13:40:00Z,usr_102,sess_903,p_002,Aura Leather Messenger Bag,Accessories,view,Meta Social Ads,Mobile,European Union,0\n" +
      "2026-06-04T13:42:00Z,usr_102,sess_903,p_002,Aura Leather Messenger Bag,Accessories,cart,Meta Social Ads,Mobile,European Union,0\n" +
      "2026-06-04T13:45:00Z,usr_102,sess_903,p_002,Aura Leather Messenger Bag,Accessories,purchase,Meta Social Ads,Mobile,European Union,185.00\n" +
      "2026-06-04T14:15:00Z,usr_103,sess_904,p_003,Sonic Wave Waterproof Speaker,Electronics,purchase,Direct,Tablet,Asia Pacific,89.00\n";
    
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "convertiq_sample_template.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const isGenerateEnabled = selectedFile && validationResult?.isValid;

  return (
    <div id="upload-center-root" className="space-y-6">
      
      {/* Title block banner & Trigger Generate Action */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">Customer Data Upload Terminal</h2>
          <p className="text-xs text-gray-500 dark:text-zinc-400 mt-1">
            Map files to required e-commerce schema variables to compile live dashboards.
          </p>
        </div>
        
        {selectedFile && (
          <button
            id="upload-execute-pipeline-btn"
            onClick={executePipeline}
            disabled={!isGenerateEnabled}
            className={`flex items-center gap-1.5 p-2 px-4 rounded-xl font-bold text-xs shadow-md transition-all cursor-pointer ${
              isGenerateEnabled
                ? "bg-gradient-to-tr from-cyan-500 to-indigo-600 text-white hover:opacity-95 shadow-indigo-500/10"
                : "bg-gray-150 text-gray-400 border border-gray-200 dark:bg-zinc-800 dark:border-zinc-700/60 cursor-not-allowed opacity-60"
            }`}
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>Generate IQ Analytics</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column Upload Area and Verification Report */}
        <div className="lg:col-span-2 space-y-5">
          
          {/* Main Drop-zone Area */}
          <div
            id="drag-drop-zone"
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`cursor-pointer border-2 border-dashed rounded-2xl p-10 flex flex-col items-center justify-center text-center transition-all duration-300 relative overflow-hidden ${
              dragActive
                ? "border-cyan-500 bg-cyan-50/20 dark:bg-cyan-950/10 scale-[0.99]"
                : "border-gray-200 dark:border-zinc-800 hover:border-gray-300 dark:hover:border-zinc-700 bg-white dark:bg-zinc-900/50"
            }`}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileInputChange}
              className="hidden"
              accept=".csv,.xlsx,.xls"
            />

            {uploadProgress !== null ? (
              <div className="space-y-4 w-full max-w-xs">
                <div className="mx-auto h-12 w-12 rounded-full border-4 border-indigo-500/20 border-t-indigo-500 animate-spin" />
                <div>
                  <p className="text-xs font-bold text-gray-900 dark:text-white">Streaming Log Packets</p>
                  <p className="text-[10px] text-gray-500 dark:text-zinc-500 mt-1">Parsing schema variables & rows... {uploadProgress}%</p>
                </div>
                <div className="w-full bg-gray-100 dark:bg-zinc-800 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-cyan-500 to-indigo-500 h-1.5 rounded-full transition-all duration-200"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="mx-auto h-12 w-12 rounded-xl bg-gray-55 dark:bg-zinc-850 border border-gray-205 dark:border-zinc-800 flex items-center justify-center text-gray-500 dark:text-zinc-400 transition-transform">
                  <UploadCloud className="h-6 w-6 text-cyan-600 dark:text-cyan-400" />
                </div>
                
                <div>
                  <p className="text-xs font-bold text-gray-900 dark:text-white text-sans">Drag & drop tables or click to upload</p>
                  <p className="text-[10px] text-gray-500 dark:text-zinc-400 mt-1.5 max-w-sm mx-auto leading-relaxed">
                    Supports <strong className="text-gray-700 dark:text-zinc-300 font-semibold mb-0.5">CSV</strong> sequences and <strong className="text-gray-700 dark:text-zinc-300 font-semibold">Excel (.xlsx)</strong> log models with standard timestamp configurations.
                  </p>
                </div>

                <div className="flex gap-2 justify-center">
                  <div className="flex items-center gap-1.5 text-[9px] font-bold text-gray-400 bg-gray-100 dark:bg-zinc-800 px-2.5 py-1 rounded-lg">
                    <FileSpreadsheet className="h-3 w-3 text-emerald-500" />
                    <span>CSV / XLS / XLSX</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Validation Failure blocker warning */}
          {validationError && (
            <div className="p-3.5 rounded-xl bg-orange-50 dark:bg-amber-950/10 border border-orange-200/60 dark:border-amber-900/30 text-orange-950 dark:text-amber-400 flex gap-2 text-xs">
              <AlertCircle className="h-4.5 w-4.5 text-orange-500 shrink-0 mt-0.5" />
              <div>
                <strong className="font-bold">Encoding / Format Blockage</strong>
                <p className="text-[10px] mt-0.5 text-orange-900 dark:text-amber-300/80">{validationError}</p>
              </div>
            </div>
          )}

          {/* Verification detail metrics view */}
          {selectedFile && validationResult && (
            <div className="space-y-4">
              
              {/* Report Header panel */}
              <div className="p-4 rounded-xl border border-cyan-500/20 bg-cyan-500/5 dark:bg-cyan-950/5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div className="flex gap-3">
                  <div className="h-10 w-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                    <FileSpreadsheet className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-gray-900 dark:text-white truncate max-w-xs">{selectedFile.name}</h4>
                    <div className="flex gap-2 items-center text-[10px] text-gray-500 dark:text-zinc-400 mt-1">
                      <span>Size: <strong className="font-bold text-gray-750 dark:text-zinc-300">{selectedFile.size}</strong></span>
                      <span className="h-1 w-1 bg-gray-300 dark:bg-zinc-700 rounded-full" />
                      <span>Format: <strong className="font-mono text-cyan-600 dark:text-cyan-400 font-bold">{selectedFile.dataSummary.format}</strong></span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-1.5">
                  <button
                    onClick={() => {
                      setSelectedFile(null);
                      setValidationResult(null);
                      setParsedRecords([]);
                    }}
                    className="text-[10px] font-bold text-gray-400 hover:text-red-500 bg-gray-150 hover:bg-red-50 dark:bg-zinc-800 dark:hover:bg-red-950/25 p-2 px-3 rounded-xl transition-all"
                  >
                    Discard
                  </button>
                  {validationResult.isValid && (
                    <button
                      id="upload-initiate-pipeline-short"
                      onClick={executePipeline}
                      className="text-[10px] font-black text-white bg-gradient-to-r from-cyan-500 to-indigo-600 p-2 px-3.5 rounded-xl transition-all"
                    >
                      Process Dataset
                    </button>
                  )}
                </div>
              </div>

              {/* Data Ingestion validation scorecard */}
              <div className="p-5 rounded-2xl border border-gray-200/60 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 space-y-4">
                <div className="flex justify-between items-center pb-3 border-b border-gray-100 dark:border-zinc-805">
                  <h4 className="text-xs font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                    {validationResult.isValid ? (
                      <CheckCircle className="h-4.5 w-4.5 text-emerald-500" />
                    ) : (
                      <AlertTriangle className="h-4.5 w-4.5 text-rose-500" />
                    )}
                    <span>Dataset Verification Diagnostics</span>
                  </h4>
                  <span className={`text-[9px] uppercase font-black px-2 py-0.5 rounded-full ${
                    validationResult.isValid ? "bg-emerald-500/10 text-emerald-500" : "bg-rose-500/10 text-rose-500 animate-pulse"
                  }`}>
                    {validationResult.isValid ? "Verified" : "Invalid Layout"}
                  </span>
                </div>

                {/* Grid analytics variables counters */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="p-3 rounded-xl bg-gray-50/50 dark:bg-zinc-850/80 border border-gray-100 dark:border-zinc-800">
                    <span className="block text-[9.5px] font-bold text-gray-400 uppercase tracking-wide">Total Records</span>
                    <span className="text-sm font-black text-gray-905 dark:text-white font-mono mt-1 block">{validationResult.totalRecords}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-gray-50/50 dark:bg-zinc-850/80 border border-gray-100 dark:border-zinc-800">
                    <span className="block text-[9.5px] font-bold text-gray-400 uppercase tracking-wide">Duplicates</span>
                    <span className={`text-sm font-black font-mono mt-1 block ${validationResult.duplicateCount > 0 ? "text-amber-500" : "text-gray-400"}`}>
                      {validationResult.duplicateCount}
                    </span>
                  </div>
                  <div className="p-3 rounded-xl bg-gray-50/50 dark:bg-zinc-850/80 border border-gray-100 dark:border-zinc-800">
                    <span className="block text-[9.5px] font-bold text-gray-400 uppercase tracking-wide">Empty Fields</span>
                    <span className={`text-sm font-black font-mono mt-1 block ${validationResult.emptyValueCount > 0 ? "text-rose-500" : "text-gray-400"}`}>
                      {validationResult.emptyValueCount}
                    </span>
                  </div>
                  <div className="p-3 rounded-xl bg-gray-50/50 dark:bg-zinc-850/80 border border-gray-100 dark:border-zinc-800">
                    <span className="block text-[9.5px] font-bold text-gray-400 uppercase tracking-wide">Invalid Dates</span>
                    <span className={`text-sm font-black font-mono mt-1 block ${validationResult.invalidTimestampCount > 0 ? "text-rose-500" : "text-gray-400"}`}>
                      {validationResult.invalidTimestampCount}
                    </span>
                  </div>
                </div>

                {/* Diagnostics list */}
                {validationResult.errors.length > 0 ? (
                  <div className="space-y-1.5 p-3.5 rounded-xl bg-rose-500/5 border border-rose-500/15 text-rose-800 dark:text-rose-400">
                    <p className="text-[10px] font-extrabold flex items-center gap-1">
                      <AlertCircle className="h-3.5 w-3.5" />
                      <span>Schema Warnings or Blocker details:</span>
                    </p>
                    <ul className="text-[10px] list-disc list-inside space-y-1 block font-mono pl-1">
                      {validationResult.errors.map((err, eIdx) => (
                        <li key={eIdx}>{err}</li>
                      ))}
                    </ul>
                  </div>
                ) : (
                  <div className="p-3.5 rounded-xl bg-emerald-500/5 border border-emerald-500/15 text-emerald-800 dark:text-emerald-400">
                    <p className="text-[10.5px] font-bold flex items-center gap-1.5">
                      <CheckCircle className="h-3.5 w-3.5 text-emerald-500" />
                      <span>Dataset fully fits required schema format! Click 'Generate IQ Analytics' to compile reports.</span>
                    </p>
                  </div>
                )}
              </div>

            </div>
          )}

          {/* Quick interactive schema reference and demo template */}
          <div className="p-4 rounded-xl border border-gray-150 dark:border-zinc-85 bg-white dark:bg-zinc-900/30 text-left space-y-3.5">
            <div className="flex justify-between items-center pb-2 border-b border-gray-100 dark:border-zinc-800">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                <Info className="h-3.5 w-3.5 text-indigo-500" />
                Required CSV/XLS Template variables
              </span>
              <button
                onClick={downloadSampleTemplate}
                className="flex items-center gap-1 px-3 py-1 rounded-lg border border-indigo-200 hover:bg-slate-50 dark:border-indigo-900/40 dark:hover:bg-slate-900/10 text-[10px] font-bold text-indigo-600 dark:text-indigo-400 cursor-pointer"
              >
                <Download className="h-3 w-3" />
                <span>Download Sample Template</span>
              </button>
            </div>

            <p className="text-[10.5px] text-gray-500 dark:text-zinc-400 max-w-xl leading-normal">
              Your uploaded file must map precisely to these e-commerce columns. Use the button above to download a standard working reference template.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
              {[
                { name: "timestamp", type: "Datetime (ISO)" },
                { name: "user_id", type: "Text (Unique ID)" },
                { name: "session_id", type: "Text (Session Link)" },
                { name: "product_id", type: "Text (Product Part)" },
                { name: "product_name", type: "Text" },
                { name: "category", type: "Text" },
                { name: "event_type", type: "view | cart | checkout | purchase" },
                { name: "traffic_source", type: "Text (Referral)" },
                { name: "device_type", type: "Desktop | Mobile | Tablet" },
                { name: "region", type: "Americas | Europe | APAC..." },
                { name: "revenue", type: "Numeric decimal" }
              ].map((c, i) => (
                <div key={i} className="p-2 rounded bg-gray-55/70 dark:bg-zinc-850/60 border border-gray-100 dark:border-zinc-805">
                  <span className="block text-[10px] font-semibold text-gray-800 dark:text-zinc-300 font-mono leading-none truncate">{c.name}</span>
                  <span className="block text-[8.5px] text-gray-400 mt-1 truncate">{c.type}</span>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Right Column Upload log panel */}
        <div className="space-y-4">
          <div className="p-4 rounded-xl border border-gray-200/50 dark:border-zinc-800/80 bg-white dark:bg-zinc-900/50">
            <h3 className="text-xs font-bold text-gray-900 dark:text-white flex items-center gap-1.5 border-b border-gray-100 dark:border-zinc-805 pb-3">
              <Database className="h-4 w-4 text-indigo-500" />
              <span>Historical File Ingestion Log</span>
            </h3>

            {uploadHistory.length === 0 ? (
              <div className="text-center py-12 space-y-2">
                <Clock className="h-8 w-8 text-gray-300 dark:text-zinc-700 mx-auto" />
                <p className="text-[11px] text-gray-400 dark:text-zinc-550">No files ingested into current session state.</p>
              </div>
            ) : (
              <div className="mt-3 space-y-2 max-h-80 overflow-y-auto pr-1">
                {uploadHistory.map((log) => (
                  <div
                    key={log.id}
                    className="p-2.5 rounded-lg border border-gray-150 dark:border-zinc-800 bg-gray-55/60 dark:bg-zinc-900/60 flex items-center justify-between"
                  >
                    <div className="flex gap-2">
                      <FileSpreadsheet className={`h-4.5 w-4.5 mt-0.5 ${
                        log.format === "CSV" ? "text-emerald-500" : "text-sky-500"
                      }`} />
                      <div>
                        <p className="text-[11px] font-semibold text-gray-800 dark:text-zinc-350 truncate max-w-32">{log.filename}</p>
                        <span className="text-[9px] text-gray-400 block mt-0.5 font-mono">{log.timestamp} • {log.recordCount} rows</span>
                      </div>
                    </div>
                    <span className="text-[9px] font-bold text-emerald-500 dark:text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                      ready
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
