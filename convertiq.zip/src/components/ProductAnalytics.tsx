import { useState, useMemo } from "react";
import {
  ShoppingBag,
  Globe,
  Smartphone,
  Monitor,
  Tablet,
  TrendingDown,
  TrendingUp,
  MapPin,
  Sparkles,
  Layers,
  ArrowUpDown,
  ChevronUp,
  ChevronDown,
  SlidersHorizontal,
  Eye,
  ShoppingCart,
  DollarSign,
  CheckCircle,
  Search,
  Award,
  Info,
  X,
  Target,
  Flame,
  ArrowRightLeft,
  ChevronRight,
  TrendingUp as TrendingUpIcon
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  AreaChart,
  Area,
  ComposedChart,
  Line
} from "recharts";
import { IngestedRecord, GlobalFilters, UnifiedMetrics } from "../types";

interface ProductAnalyticsProps {
  metrics: UnifiedMetrics;
  filters: GlobalFilters;
  setFilters: (filters: GlobalFilters) => void;
  isSimulating: boolean;
  uploadedData?: IngestedRecord[];
}

interface ComputedProductMetrics {
  name: string;
  category: string;
  views: number;
  cartInserts: number;
  addToCartRate: number; // (cartInserts / views) * 100
  orders: number;
  purchaseRate: number; // (orders / views) * 100
  revenue: number;
}

// Helper mock generator to power simulation modes utilizing identical metrics engine
const generateMockProductLogs = (filters: GlobalFilters): IngestedRecord[] => {
  const products = [
    { name: "Starlight Pro Wireless Headphones", category: "Audio", price: 149 },
    { name: "Aura Leather Messenger Bag", category: "Accessories", price: 185 },
    { name: "Sonic Wave Waterproof Speaker", category: "Audio", price: 89 },
    { name: "Titan Fit Waterproof Smartwatch", category: "Wearables", price: 65 },
    { name: "Hyperion Mechanical Gaming Mouse", category: "Electronics", price: 79 },
    { name: "Vortex Red Backlit Keyboard", category: "Electronics", price: 129 },
    { name: "Zephyr Ergo Cooling Stand", category: "Accessories", price: 39 },
    { name: "Zenith Active Sportband", category: "Wearables", price: 49 },
  ];

  const devices = ["Desktop", "Mobile", "Tablet"];
  const regions = ["Americas", "Europe", "APAC", "MEA"];
  const channels = ["Google", "Facebook", "Instagram", "Email", "Direct"];

  const logs: IngestedRecord[] = [];
  const now = Date.now();

  products.forEach((prod, pIdx) => {
    // Generate engagements
    const baseViews = 300 + (pIdx * 137) % 350;
    const baseCartRate = 0.12 + (pIdx * 0.04) % 0.16; // 12% - 28% Add to cart
    const basePurchaseRate = 0.03 + (pIdx * 0.015) % 0.09; // 3% - 12% Purchase

    for (let i = 0; i < baseViews; i++) {
      const dev = devices[i % devices.length];
      const reg = regions[(i + pIdx) % regions.length];
      const chan = channels[(i + pIdx * 2) % channels.length];
      const timestamp = new Date(now - (i % 30) * 24 * 60 * 60 * 1000).toISOString();

      // View Log
      logs.push({
        timestamp,
        user_id: `u_${pIdx}_${i}`,
        session_id: `sess_${pIdx}_${i}`,
        product_id: `p_${pIdx + 1}`,
        product_name: prod.name,
        category: prod.category,
        event_type: "view",
        traffic_source: chan,
        device_type: dev,
        region: reg,
        revenue: 0
      });

      // Cart log
      if (i < baseViews * baseCartRate) {
        logs.push({
          timestamp,
          user_id: `u_${pIdx}_${i}`,
          session_id: `sess_${pIdx}_${i}`,
          product_id: `p_${pIdx + 1}`,
          product_name: prod.name,
          category: prod.category,
          event_type: "cart",
          traffic_source: chan,
          device_type: dev,
          region: reg,
          revenue: 0
        });
      }

      // Purchase log
      if (i < baseViews * basePurchaseRate) {
        logs.push({
          timestamp,
          user_id: `u_${pIdx}_${i}`,
          session_id: `sess_${pIdx}_${i}`,
          product_id: `p_${pIdx + 1}`,
          product_name: prod.name,
          category: prod.category,
          event_type: "purchase",
          traffic_source: chan,
          device_type: dev,
          region: reg,
          revenue: prod.price
        });
      }
    }
  });

  return logs;
};

export default function ProductAnalytics({
  metrics,
  filters,
  setFilters,
  isSimulating,
  uploadedData = []
}: ProductAnalyticsProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [activeLeaderboardTab, setActiveLeaderboardTab] = useState<"leaders" | "conversions" | "adds" | "worst">("leaders");
  const [activeChartTab, setActiveChartTab] = useState<"comparison" | "revenues" | "conversions">("comparison");

  // Sorting metrics states
  const [sortColumn, setSortColumn] = useState<keyof ComputedProductMetrics>("revenue");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");

  // Multi-color schema
  const colors = ["#6366f1", "#06b6d4", "#10b981", "#f59e0b", "#d946ef", "#0284c7"];

  // 1. Core Data Stream Pipeline
  const activeLogs = useMemo(() => {
    if (!isSimulating && uploadedData && uploadedData.length > 0) {
      return uploadedData;
    }
    return generateMockProductLogs(filters);
  }, [isSimulating, uploadedData, filters]);

  // 2. Filter & Compute Metrics per Product from Active logs
  const rawProductMetrics = useMemo(() => {
    // Evaluate Global Date constraint
    const timestamps = activeLogs.map(v => new Date(v.timestamp).getTime()).filter(t => !isNaN(t));
    const latestTime = timestamps.length > 0 ? timestamps.reduce((max, t) => t > max ? t : max, timestamps[0]) : Date.now();
    const daysLimit = filters.dateRange === "7d" ? 7 : filters.dateRange === "90d" ? 90 : 30;
    const milliLimit = daysLimit * 24 * 60 * 60 * 1000;

    let filtered = activeLogs.filter(v => {
      const recTime = new Date(v.timestamp).getTime();
      if (isNaN(recTime)) return false;
      if (latestTime - recTime > milliLimit) return false;

      if (filters.region !== "all" && v.region) {
        const checkVal = v.region.toLowerCase();
        const searchVal = filters.region.toLowerCase();
        if (!checkVal.includes(searchVal) && !searchVal.includes(checkVal)) return false;
      }

      if (filters.device !== "all" && v.device_type) {
        if (v.device_type.toLowerCase() !== filters.device.toLowerCase()) return false;
      }

      if (filters.channel !== "all" && v.traffic_source) {
        const checkVal = v.traffic_source.toLowerCase();
        const searchVal = filters.channel.toLowerCase();
        if (!checkVal.includes(searchVal) && !searchVal.includes(checkVal)) return false;
      }

      return true;
    });

    // Grouping computation
    const productGroups: Record<string, {
      name: string;
      category: string;
      views: number;
      cartInserts: number;
      orders: number;
      revenue: number;
    }> = {};

    filtered.forEach(r => {
      const name = r.product_name || "Unnamed Product";
      const cat = r.category || "Uncategorized";

      if (!productGroups[name]) {
        productGroups[name] = {
          name,
          category: cat,
          views: 0,
          cartInserts: 0,
          orders: 0,
          revenue: 0
        };
      }

      const event = r.event_type.toLowerCase();
      // Handle different names representing views, carts, and purchases
      if (event === "view" || event === "page_view" || event === "click") {
        productGroups[name].views++;
      } else if (event === "cart" || event === "cart_insert" || event === "add_to_cart") {
        productGroups[name].cartInserts++;
      } else if (event === "purchase" || event === "order" || event === "checkout") {
        productGroups[name].orders++;
        productGroups[name].revenue += Number(r.revenue || 0);
      }
    });

    // Turn groups map into complete records with parsed precision formulas
    return Object.values(productGroups).map((g): ComputedProductMetrics => {
      // Add safe guarantees against zero views
      const addToCartRate = g.views > 0 ? parseFloat(((g.cartInserts / g.views) * 100).toFixed(2)) : (g.cartInserts > 0 ? 100 : 0);
      const purchaseRate = g.views > 0 ? parseFloat(((g.orders / g.views) * 100).toFixed(2)) : (g.orders > 0 ? 100 : 0);

      return {
        ...g,
        addToCartRate,
        purchaseRate,
        revenue: Math.round(g.revenue)
      };
    });
  }, [activeLogs, filters]);

  // Extract unique categories available from the parsed log products
  const uniqueCategories = useMemo(() => {
    const catsSet = new Set(rawProductMetrics.map(p => p.category).filter(Boolean));
    return ["all", ...Array.from(catsSet)];
  }, [rawProductMetrics]);

  // Filter products locally by Category & Search query
  const filteredProducts = useMemo(() => {
    return rawProductMetrics.filter(p => {
      if (selectedCategory !== "all" && p.category !== selectedCategory) return false;
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const matchName = p.name.toLowerCase().includes(query);
        const matchCat = p.category.toLowerCase().includes(query);
        if (!matchName && !matchCat) return false;
      }
      return true;
    });
  }, [rawProductMetrics, selectedCategory, searchQuery]);

  // Sortable engine for Product Catalog Master Matrix table
  const sortedProducts = useMemo(() => {
    const sorted = [...filteredProducts];
    sorted.sort((a, b) => {
      let aVal = a[sortColumn];
      let bVal = b[sortColumn];

      if (typeof aVal === "string" && typeof bVal === "string") {
        return sortDirection === "asc"
          ? aVal.localeCompare(bVal)
          : bVal.localeCompare(aVal);
      }

      // Numerical handles
      aVal = Number(aVal) || 0;
      bVal = Number(bVal) || 0;
      return sortDirection === "asc"
        ? aVal - bVal
        : bVal - aVal;
    });
    return sorted;
  }, [filteredProducts, sortColumn, sortDirection]);

  // Group performance segmented rankings
  const rankedByRevenue = useMemo(() => {
    return [...filteredProducts].sort((a, b) => b.revenue - a.revenue);
  }, [filteredProducts]);

  const rankedByConversion = useMemo(() => {
    return [...filteredProducts].sort((a, b) => b.purchaseRate - a.purchaseRate);
  }, [filteredProducts]);

  const rankedByCartRates = useMemo(() => {
    return [...filteredProducts].sort((a, b) => b.addToCartRate - a.addToCartRate);
  }, [filteredProducts]);

  const rankedByWorstStats = useMemo(() => {
    // Underperforming items with views but minimal purchase volume or revenue
    return [...filteredProducts]
      .filter(p => p.views > 2)
      .sort((a, b) => a.purchaseRate - b.purchaseRate);
  }, [filteredProducts]);

  // Automatic leader / bottleneck extraction safely
  const topProduct = rankedByRevenue[0];
  const worstProduct = rankedByWorstStats[0];
  const conversionChamp = rankedByConversion[0];
  const cartHero = rankedByCartRates[0];

  const handleSortClick = (column: keyof ComputedProductMetrics) => {
    if (sortColumn === column) {
      setSortDirection(prev => prev === "asc" ? "desc" : "asc");
    } else {
      setSortColumn(column);
      setSortDirection("desc");
    }
  };

  return (
    <div id="product-performance-root" className="space-y-6">

      {/* Visual Header Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-gray-150 dark:border-zinc-850 pb-5">
        <div>
          <h2 className="text-xl font-extrabold text-gray-900 dark:text-white flex items-center gap-2 tracking-tight">
            <ShoppingBag className="h-5.5 w-5.5 text-indigo-505 bg-indigo-500/10 text-indigo-550 p-0.5 rounded-lg shrink-0" />
            <span>Product Catalog Performance Analytics</span>
          </h2>
          <p className="text-xs text-gray-500 dark:text-zinc-400 mt-1 leading-normal">
            Analyze absolute product views, add-to-cart ratios, purchase conversion percentages, and gross revenues directly parsed from {isSimulating ? "simulated environments" : "uploaded log datasets"}.
          </p>
        </div>

        {/* Unified data stream banner */}
        <div className="flex items-center gap-2">
          {filters.product !== "all" && (
            <button
              onClick={() => {
                const refreshed = { ...filters, product: "all" };
                setFilters(refreshed);
              }}
              className="text-[10px] bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 px-2.5 py-1 rounded-full flex items-center gap-1 hover:bg-indigo-500/20 transition-all font-bold"
            >
              <span>Product filtered: {filters.product}</span>
              <X className="h-3 w-3" />
            </button>
          )}

          <span className={`text-[10px] uppercase tracking-wider font-extrabold px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-sm border ${
            isSimulating
              ? "bg-amber-500/10 text-amber-650 dark:text-amber-400 border-amber-500/20"
              : "bg-emerald-500/10 text-emerald-650 dark:text-emerald-400 border-emerald-500/20"
          }`}>
            <span className={`h-2 w-2 rounded-full ${isSimulating ? "bg-amber-500 animate-pulse" : "bg-emerald-500 animate-bounce"}`} />
            <span>{isSimulating ? "Demo Product Sim" : "Uploaded Product Log Stream"}</span>
          </span>
        </div>
      </div>

      {/* -----------------------------------------------------------------------
          AI HEURISTICS INSIGHT CARDS (Identifying Top and Worst Performers)
          ----------------------------------------------------------------------- */}
      {rawProductMetrics.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-left">
          
          {/* CARD 1: OVERALL REVENUE LEADERS */}
          {topProduct && (
            <div className="p-4.5 rounded-2xl border border-emerald-500/20 dark:border-emerald-950 bg-emerald-500/5 dark:bg-emerald-500/[0.01] flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-center">
                  <span className="text-[9px] font-black tracking-widest text-emerald-600 dark:text-emerald-400 uppercase font-mono">Revenue Champion</span>
                  <Award className="h-4 w-4 text-emerald-500" />
                </div>
                <h4 className="text-sm font-extrabold text-gray-900 dark:text-white mt-1 select-all">{topProduct.name}</h4>
                <p className="text-[10px] text-gray-400 mt-1 block">Category: <strong>{topProduct.category}</strong></p>
                <div className="mt-3 grid grid-cols-2 gap-1 border-t border-gray-100 dark:border-zinc-805/40 pt-2.5">
                  <div>
                    <span className="text-[8px] text-gray-400 uppercase font-black font-mono">Gross Revenue</span>
                    <p className="text-sm font-bold text-gray-900 dark:text-white font-mono">${topProduct.revenue.toLocaleString()}</p>
                  </div>
                  <div>
                    <span className="text-[8px] text-gray-400 uppercase font-black font-mono">Total Orders</span>
                    <p className="text-sm font-bold text-gray-950 dark:text-white font-mono">{topProduct.orders.toLocaleString()}</p>
                  </div>
                </div>
              </div>
              <div className="text-[9px] text-emerald-650 dark:text-emerald-400 font-bold bg-emerald-500/10 px-2 py-1 rounded mt-3 text-center">
                🏆 Outstanding: Drives peak capital inflows!
              </div>
            </div>
          )}

          {/* CARD 2: CONVERSION CHAMPIONS */}
          {conversionChamp && (
            <div className="p-4.5 rounded-2xl border border-indigo-500/20 dark:border-indigo-950 bg-indigo-500/5 dark:bg-indigo-500/[0.01] flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-center">
                  <span className="text-[9px] font-black tracking-widest text-indigo-600 dark:text-indigo-400 uppercase font-mono">Conversion Leader</span>
                  <Target className="h-4 w-4 text-indigo-500" />
                </div>
                <h4 className="text-sm font-extrabold text-gray-900 dark:text-white mt-1">{conversionChamp.name}</h4>
                <p className="text-[10px] text-gray-400 mt-1 block">Category: <strong>{conversionChamp.category}</strong></p>
                <div className="mt-3 grid grid-cols-2 gap-1 border-t border-gray-100 dark:border-zinc-805/40 pt-2.5">
                  <div>
                    <span className="text-[8px] text-gray-400 uppercase font-black font-mono">Conversion (CR)</span>
                    <p className="text-sm font-bold text-indigo-600 dark:text-indigo-400 font-mono">{conversionChamp.purchaseRate}%</p>
                  </div>
                  <div>
                    <span className="text-[8px] text-gray-400 uppercase font-black font-mono">Product Views</span>
                    <p className="text-sm font-bold text-gray-900 dark:text-white font-mono">{conversionChamp.views.toLocaleString()}</p>
                  </div>
                </div>
              </div>
              <div className="text-[9px] text-indigo-650 dark:text-indigo-400 font-bold bg-indigo-500/10 px-2 py-1 rounded mt-3 text-center">
                🎯 Extremely high buying intent across visits!
              </div>
            </div>
          )}

          {/* CARD 3: ADD-TO-CART STARS */}
          {cartHero && (
            <div className="p-4.5 rounded-2xl border border-cyan-500/20 dark:border-cyan-950 bg-cyan-500/5 dark:bg-cyan-500/[0.01] flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-center">
                  <span className="text-[9px] font-black tracking-widest text-cyan-600 dark:text-cyan-400 uppercase font-mono">Add-to-cart Star</span>
                  <ShoppingCart className="h-4 w-4 text-cyan-500" />
                </div>
                <h4 className="text-sm font-extrabold text-gray-900 dark:text-white mt-1">{cartHero.name}</h4>
                <p className="text-[10px] text-gray-400 mt-1 block">Category: <strong>{cartHero.category}</strong></p>
                <div className="mt-3 grid grid-cols-2 gap-1 border-t border-gray-100 dark:border-zinc-805/40 pt-2.5">
                  <div>
                    <span className="text-[8px] text-gray-400 uppercase font-black font-mono">ATC Inserts Rate</span>
                    <p className="text-sm font-bold text-cyan-600 dark:text-cyan-400 font-mono">{cartHero.addToCartRate}%</p>
                  </div>
                  <div>
                    <span className="text-[8px] text-gray-400 uppercase font-black font-mono">Cart Items</span>
                    <p className="text-sm font-bold text-gray-900 dark:text-white font-mono">{cartHero.cartInserts.toLocaleString()}</p>
                  </div>
                </div>
              </div>
              <div className="text-[9px] text-cyan-650 dark:text-cyan-400 font-bold bg-cyan-500/10 px-2 py-1 rounded mt-3 text-center">
                🛒 Add-to-cart magnets with peak initial pull!
              </div>
            </div>
          )}

          {/* CARD 4: BOTTLENECKS / WORST PERFORMERS */}
          {worstProduct ? (
            <div className="p-4.5 rounded-2xl border border-rose-500/20 dark:border-rose-950 bg-rose-500/5 dark:bg-rose-500/[0.01] flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-center">
                  <span className="text-[9px] font-black tracking-widest text-rose-600 dark:text-rose-400 uppercase font-mono">Lagging Bottleneck</span>
                  <TrendingDown className="h-4 w-4 text-rose-500" />
                </div>
                <h4 className="text-sm font-extrabold text-gray-900 dark:text-white mt-1 ">{worstProduct.name}</h4>
                <p className="text-[10px] text-gray-400 mt-1 block">Category: <strong>{worstProduct.category}</strong></p>
                <div className="mt-3 grid grid-cols-2 gap-1 border-t border-gray-100 dark:border-zinc-805/40 pt-2.5">
                  <div>
                    <span className="text-[8px] text-gray-400 uppercase font-black font-mono">Conversion Rate</span>
                    <p className="text-sm font-bold text-rose-600 dark:text-rose-400 font-mono">{worstProduct.purchaseRate}%</p>
                  </div>
                  <div>
                    <span className="text-[8px] text-gray-400 uppercase font-black font-mono">Total Revenue</span>
                    <p className="text-sm font-bold text-gray-900 dark:text-white font-mono">${worstProduct.revenue.toLocaleString()}</p>
                  </div>
                </div>
              </div>
              <div className="text-[9px] text-rose-650 dark:text-rose-400 font-bold bg-rose-500/10 px-2 py-1 rounded mt-3 text-center">
                ⚠️ Danger Zone: High view count but low checkouts!
              </div>
            </div>
          ) : (
            <div className="p-4.5 rounded-2xl border border-gray-200 dark:border-zinc-800 bg-gray-50 dark:bg-zinc-900/30 flex flex-col justify-between">
              <div>
                <h4 className="text-sm font-bold text-gray-400">All products performing in green parameters.</h4>
              </div>
            </div>
          )}

        </div>
      )}

      {/* -----------------------------------------------------------------------
          INTEGRATED SEARCH, CATEGORY PILL FILTER, & DATA TAB MODULE
          ----------------------------------------------------------------------- */}
      <div className="p-5 rounded-2xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 text-left">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 border-b border-gray-100 dark:border-zinc-805 pb-4">
          <div>
            <h3 className="text-sm font-bold text-gray-950 dark:text-white flex items-center gap-2">
              <SlidersHorizontal className="h-4 w-4 text-indigo-500" />
              <span>Interactive Filters & Catalog Search Selector</span>
            </h3>
            <p className="text-[10px] text-gray-400">Target metrics using search queries and dynamic category pill classifications.</p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto">
            {/* Search Input box */}
            <div className="relative w-full sm:w-64">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                <Search className="h-3.5 w-3.5" />
              </span>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search catalog item or category..."
                className="w-full pl-9 pr-8 py-1.5 text-xs text-gray-800 dark:text-zinc-200 bg-gray-50/50 dark:bg-zinc-900 rounded-lg border border-gray-200/60 dark:border-zinc-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-600"
                >
                  <X className="h-3 w-3" />
                </button>
              )}
            </div>

            {/* Category dropdown selector */}
            <div className="w-full sm:w-48">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full text-xs py-1.5 px-3 rounded-lg border border-gray-200/60 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-900 text-gray-850 dark:text-zinc-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-bold"
              >
                <option value="all">📁 All Categories (Total)</option>
                {uniqueCategories.map(cat => {
                  if (cat === "all") return null;
                  return (
                    <option key={cat} value={cat}>
                      📦 {cat}
                    </option>
                  );
                })}
              </select>
            </div>
          </div>
        </div>

        {/* Categories sliding pill selector cards */}
        <div className="flex flex-wrap gap-2 mt-4">
          {uniqueCategories.map(cat => {
            const isActive = selectedCategory === cat;
            const countInCat = rawProductMetrics.filter(p => cat === "all" || p.category === cat).length;
            
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`text-[10px] font-bold px-3 py-1.5 rounded-full transition-all flex items-center gap-1.5 ${
                  isActive
                    ? "bg-indigo-600 text-white shadow-xs"
                    : "bg-gray-100 hover:bg-gray-200/60 dark:bg-zinc-850 dark:hover:bg-zinc-800 text-gray-600 dark:text-zinc-400"
                }`}
              >
                <span>{cat === "all" ? "Whole Catalog" : cat}</span>
                <span className={`text-[8.5px] px-1.5 py-0.2 rounded-full font-mono ${
                  isActive ? "bg-white/20 text-white" : "bg-gray-200 dark:bg-zinc-800 text-gray-500"
                }`}>
                  {countInCat}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* -----------------------------------------------------------------------
          HIGH END CHART GRAPH DISPLAY HUB (Recharts interactive charts)
          ----------------------------------------------------------------------- */}
      <div className="p-5 rounded-2xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 flex flex-col text-left">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-gray-100 dark:border-zinc-805 pb-3">
          <div>
            <h3 className="text-sm font-extrabold text-gray-850 dark:text-white flex items-center gap-2">
              <TrendingUpIcon className="h-4.5 w-4.5 text-indigo-550" />
              <span>Interactive Product Visualizer Chartboards</span>
            </h3>
            <p className="text-[10px] text-gray-400">Dynamic charts reflecting searches, filter segments, and category parameters.</p>
          </div>

          {/* Chart selector tabs buttons */}
          <div className="flex bg-gray-100 dark:bg-zinc-850 p-0.5 rounded-lg border border-gray-200/50 dark:border-zinc-800 text-[10px] font-bold">
            <button
              onClick={() => setActiveChartTab("comparison")}
              className={`px-3 py-1.5 rounded-md transition-all ${
                activeChartTab === "comparison"
                  ? "bg-indigo-600 text-white font-extrabold shadow-sm"
                  : "text-gray-500 hover:text-gray-950 dark:text-zinc-400 dark:hover:text-zinc-200"
              }`}
            >
              Views vs Carts vs Orders
            </button>
            <button
              onClick={() => setActiveChartTab("revenues")}
              className={`px-3 py-1.5 rounded-md transition-all ${
                activeChartTab === "revenues"
                  ? "bg-indigo-600 text-white font-extrabold shadow-sm"
                  : "text-gray-500 hover:text-gray-950 dark:text-zinc-400 dark:hover:text-zinc-200"
              }`}
            >
              Revenue Leaders ($)
            </button>
            <button
              onClick={() => setActiveChartTab("conversions")}
              className={`px-3 py-1.5 rounded-md transition-all ${
                activeChartTab === "conversions"
                  ? "bg-indigo-600 text-white font-extrabold shadow-sm"
                  : "text-gray-500 hover:text-gray-950 dark:text-zinc-400 dark:hover:text-zinc-200"
              }`}
            >
              Add-to-cart vs Sale CR
            </button>
          </div>
        </div>

        {/* Canvas stage layout */}
        <div className="h-72 mt-5">
          {sortedProducts.length === 0 ? (
            <div className="h-full w-full flex flex-col items-center justify-center text-center text-gray-400 border border-dashed border-gray-150 dark:border-zinc-800 rounded-xl">
              <Info className="h-7 w-7 text-gray-300 mb-2" />
              <p className="text-xs">No active catalog items match the query criteria.</p>
              <button
                onClick={() => { setSelectedCategory("all"); setSearchQuery(""); }}
                className="text-[10px] font-bold text-indigo-500 underline mt-1"
              >
                Clear local filters
              </button>
            </div>
          ) : activeChartTab === "comparison" ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={sortedProducts.slice(0, 8)} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(120, 120, 120, 0.08)" />
                <XAxis dataKey="name" tickFormatter={(n) => n.length > 15 ? `${n.slice(0, 12)}...` : n} style={{ fontSize: 9, fill: "#888", fontWeight: "bold" }} tickLine={false} />
                <YAxis style={{ fontSize: 9, fill: "#888" }} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(12, 12, 12, 0.95)",
                    border: "1px solid rgba(80, 80, 80, 0.15)",
                    borderRadius: 12,
                    fontSize: 10,
                    color: "#fff"
                  }}
                  formatter={(val: any, name: string) => {
                    const mappedName: Record<string, string> = { views: "Views", cartInserts: "Cart Inserts", orders: "Orders" };
                    return [val.toLocaleString(), mappedName[name] || name];
                  }}
                />
                <Legend wrapperStyle={{ fontSize: 9 }} />
                <Bar dataKey="views" fill="#3b82f6" name="Product Views" radius={[3, 3, 0, 0]} />
                <Bar dataKey="cartInserts" fill="#06b6d4" name="Cart Inserts" radius={[3, 3, 0, 0]} />
                <Bar dataKey="orders" fill="#f59e0b" name="Orders Volume" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : activeChartTab === "revenues" ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={sortedProducts.slice(0, 8)} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <defs>
                  <linearGradient id="areaPremiumGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.35}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(120, 120, 120, 0.08)" />
                <XAxis dataKey="name" tickFormatter={(n) => n.length > 15 ? `${n.slice(0, 12)}...` : n} style={{ fontSize: 9, fill: "#888", fontWeight: "bold" }} tickLine={false} />
                <YAxis style={{ fontSize: 9, fill: "#888" }} tickFormatter={(val) => `$${val}`} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(12, 12, 12, 0.95)",
                    border: "1px solid rgba(80, 80, 80, 0.15)",
                    borderRadius: 12,
                    fontSize: 10,
                    color: "#fff"
                  }}
                  formatter={(val: any) => [`$${val.toLocaleString()}`, "Attributed Revenue"]}
                />
                <Area type="monotone" dataKey="revenue" stroke="#10b981" fillOpacity={1} fill="url(#areaPremiumGrad)" strokeWidth={2.5} name="Revenue ($)" />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={sortedProducts.slice(0, 8)} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(120, 120, 120, 0.08)" />
                <XAxis dataKey="name" tickFormatter={(n) => n.length > 15 ? `${n.slice(0, 12)}...` : n} style={{ fontSize: 9, fill: "#888", fontWeight: "bold" }} tickLine={false} />
                <YAxis style={{ fontSize: 9, fill: "#888" }} label={{ value: 'Percentage (%)', angle: -90, position: 'insideLeft', offset: -10, style: { fontSize: 8, fill: '#aaa' } }} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(12, 12, 12, 0.95)",
                    border: "1px solid rgba(80, 80, 80, 0.15)",
                    borderRadius: 12,
                    fontSize: 10,
                    color: "#fff"
                  }}
                  formatter={(val: any, name: string) => [`${val}%`, name === "addToCartRate" ? "Add-to-cart Rate" : "Purchase CR"] }
                />
                <Legend wrapperStyle={{ fontSize: 9 }} />
                <Bar dataKey="addToCartRate" fill="#6366f1" name="Add-to-cart Rate (%)" barSize={25} radius={[3, 3, 0, 0]} />
                <Line type="monotone" dataKey="purchaseRate" stroke="#ec4899" strokeWidth={3} name="Purchase Conversion Rate (%)" />
              </ComposedChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* -----------------------------------------------------------------------
          SEGMENTED TARGETED LEADERBOARD MATRICES
          ----------------------------------------------------------------------- */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Quick Segmented lists card */}
        <div className="p-5 rounded-2xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 text-left lg:col-span-1 flex flex-col justify-between">
          <div>
            <div className="border-b border-gray-100 dark:border-zinc-805 pb-3">
              <h3 className="text-xs font-black tracking-widest text-indigo-650 dark:text-indigo-400 uppercase font-mono">
                Catalog Leaders Boards
              </h3>
              <p className="text-[10px] text-gray-400 mt-0.5">Quick ranking matrices detailing peak performers and lagging categories.</p>
            </div>

            {/* Sub-selector board options */}
            <div className="grid grid-cols-2 gap-1.5 mt-4">
              <button
                onClick={() => setActiveLeaderboardTab("leaders")}
                className={`text-[9px] font-extrabold py-2 px-2.5 rounded-lg border text-center transition-all flex flex-col items-center justify-center gap-1 leading-tight ${
                  activeLeaderboardTab === "leaders"
                    ? "bg-emerald-500/10 border-emerald-500/25 text-emerald-700 dark:text-emerald-400"
                    : "bg-gray-50/50 dark:bg-zinc-900/35 border-gray-150 dark:border-zinc-850 text-gray-500 dark:text-zinc-400"
                }`}
              >
                <Award className="h-4 w-4 shrink-0" />
                <span>Revenue Leaders</span>
              </button>
              <button
                onClick={() => setActiveLeaderboardTab("conversions")}
                className={`text-[9px] font-extrabold py-2 px-2.5 rounded-lg border text-center transition-all flex flex-col items-center justify-center gap-1 leading-tight ${
                  activeLeaderboardTab === "conversions"
                    ? "bg-indigo-500/10 border-indigo-505/25 text-indigo-700 dark:text-indigo-400"
                    : "bg-gray-50/50 dark:bg-zinc-900/35 border-gray-150 dark:border-zinc-850 text-gray-500 dark:text-zinc-400"
                }`}
              >
                <Target className="h-4 w-4" />
                <span>Conversion Leaders</span>
              </button>
              <button
                onClick={() => setActiveLeaderboardTab("adds")}
                className={`text-[9px] font-extrabold py-2 px-2.5 rounded-lg border text-center transition-all flex flex-col items-center justify-center gap-1 leading-tight ${
                  activeLeaderboardTab === "adds"
                    ? "bg-cyan-500/10 border-cyan-502/25 text-cyan-700 dark:text-cyan-400"
                    : "bg-gray-50/50 dark:bg-zinc-900/35 border-gray-150 dark:border-zinc-850 text-gray-500 dark:text-zinc-400"
                }`}
              >
                <ShoppingCart className="h-4 w-4" />
                <span>Add To Cart leaders</span>
              </button>
              <button
                onClick={() => setActiveLeaderboardTab("worst")}
                className={`text-[9px] font-extrabold py-2 px-2.5 rounded-lg border text-center transition-all flex flex-col items-center justify-center gap-1 leading-tight ${
                  activeLeaderboardTab === "worst"
                    ? "bg-rose-500/10 border-rose-505/25 text-rose-700 dark:text-rose-400"
                    : "bg-gray-50/50 dark:bg-zinc-900/35 border-gray-150 dark:border-zinc-850 text-gray-500 dark:text-zinc-400"
                }`}
              >
                <TrendingDown className="h-4 w-4" />
                <span>Worst Performing</span>
              </button>
            </div>

            {/* List entries rendering */}
            <div className="mt-5 space-y-2.5">
              {(activeLeaderboardTab === "leaders" ? rankedByRevenue :
                activeLeaderboardTab === "conversions" ? rankedByConversion :
                activeLeaderboardTab === "adds" ? rankedByCartRates : rankedByWorstStats)
                .slice(0, 4)
                .map((p, pIdx) => {
                  let visualStat = `$${p.revenue.toLocaleString()}`;
                  let metricLabel = "Revenue";
                  if (activeLeaderboardTab === "conversions") {
                    visualStat = `${p.purchaseRate}% CR`;
                    metricLabel = "Purchase CR";
                  } else if (activeLeaderboardTab === "adds") {
                    visualStat = `${p.addToCartRate}% ATC`;
                    metricLabel = "Add-to-cart";
                  } else if (activeLeaderboardTab === "worst") {
                    visualStat = `${p.purchaseRate}% CR`;
                    metricLabel = "Low CR";
                  }

                  return (
                    <div key={p.name} className="flex items-center justify-between p-2 rounded-lg bg-gray-55/40 dark:bg-zinc-900/25 border border-gray-100 dark:border-zinc-850">
                      <div className="flex gap-2 items-center min-w-0">
                        <span className="text-[10px] font-mono text-gray-400 font-bold w-4">
                          #{pIdx + 1}
                        </span>
                        <div className="min-w-0">
                          <p className="text-[11px] font-black text-gray-800 dark:text-zinc-150 truncate max-w-[120px] lg:max-w-[160px]">{p.name}</p>
                          <span className="text-[9px] text-gray-400 block font-light">{p.category}</span>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <p className="text-[11px] font-black text-gray-950 dark:text-white font-mono">{visualStat}</p>
                        <span className="text-[8px] text-gray-400 block font-mono">{metricLabel}</span>
                      </div>
                    </div>
                  );
                })}

              {/* No items matched indicator */}
              {(activeLeaderboardTab === "leaders" ? rankedByRevenue :
                activeLeaderboardTab === "conversions" ? rankedByConversion :
                activeLeaderboardTab === "adds" ? rankedByCartRates : rankedByWorstStats).length === 0 && (
                <p className="text-xs text-center text-gray-400 font-light mt-5">No active items captured in metrics ledger.</p>
              )}
            </div>
          </div>

          <div className="text-[10px] text-gray-400 leading-normal border-t border-gray-100 dark:border-zinc-800/80 pt-3 mt-4">
            🚀 <strong>Direction:</strong> Invest in advertising channels referring to top Conversion leaders. For items displaying High ATC but low Purchase, consider launching automated abandoned cart checkout triggers.
          </div>
        </div>

        {/* -----------------------------------------------------------------------
            MASTER SYSTEM SORTABLE TABLE (Slick layout with clickable sorting triggers)
            ----------------------------------------------------------------------- */}
        <div className="lg:col-span-2 p-5 rounded-2xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 overflow-x-auto text-left">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-gray-100 dark:border-zinc-805 pb-3">
            <div>
              <h3 className="text-xs font-black tracking-widest text-indigo-650 dark:text-indigo-400 uppercase font-mono flex items-center gap-1.5">
                <SlidersHorizontal className="h-4 w-4 text-indigo-500 animate-pulse" />
                <span>Sortable Performance Ledger Matrix</span>
              </h3>
              <p className="text-[10px] text-gray-400 mt-0.5">Click any header title to toggle sorted rankings (asc vs desc).</p>
            </div>

            <span className="text-[9.5px] font-mono text-indigo-600 bg-indigo-500/10 dark:text-indigo-400 font-black px-2.5 py-1 rounded">
              Showing {sortedProducts.length} Items
            </span>
          </div>

          <div className="overflow-x-auto min-w-[500px] mt-4">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="border-b border-gray-150 dark:border-zinc-800 text-[9.5px] text-gray-400 font-mono tracking-wider uppercase font-extrabold select-none">
                  
                  {/* Name Sortable */}
                  <th 
                    onClick={() => handleSortClick("name")}
                    className="py-2.5 text-left font-bold cursor-pointer hover:text-gray-900 dark:hover:text-white transition-all"
                  >
                    <div className="flex items-center gap-1">
                      <span>Catalog Product</span>
                      <ArrowUpDown className="h-3 w-3 text-gray-300" />
                    </div>
                  </th>

                  {/* Category Sortable */}
                  <th 
                    onClick={() => handleSortClick("category")}
                    className="py-2.5 text-center font-bold cursor-pointer hover:text-gray-900 dark:hover:text-white transition-all"
                  >
                    <div className="flex items-center justify-center gap-1">
                      <span>Category</span>
                      <ArrowUpDown className="h-3 w-3 text-gray-300" />
                    </div>
                  </th>

                  {/* Views Sortable */}
                  <th 
                    onClick={() => handleSortClick("views")}
                    className="py-2.5 text-center font-bold cursor-pointer hover:text-gray-900 dark:hover:text-white transition-all"
                  >
                    <div className="flex items-center justify-center gap-1">
                      <span>Views</span>
                      <ArrowUpDown className="h-3 w-3 text-gray-300" />
                    </div>
                  </th>

                  {/* Add To Cart Rate Sortable */}
                  <th 
                    onClick={() => handleSortClick("addToCartRate")}
                    className="py-2.5 text-center font-bold cursor-pointer hover:text-gray-950 dark:hover:text-white transition-all text-cyan-600 dark:text-cyan-400"
                  >
                    <div className="flex items-center justify-center gap-1">
                      <span>ATC %</span>
                      <ArrowUpDown className="h-3 w-3 text-gray-300" />
                    </div>
                  </th>

                  {/* Purchase Rate Sortable */}
                  <th 
                    onClick={() => handleSortClick("purchaseRate")}
                    className="py-2.5 text-center font-bold cursor-pointer hover:text-gray-950 dark:hover:text-white transition-all text-indigo-650 dark:text-indigo-400"
                  >
                    <div className="flex items-center justify-center gap-1">
                      <span>CR %</span>
                      <ArrowUpDown className="h-3 w-3 text-gray-300" />
                    </div>
                  </th>

                  {/* Orders Sortable */}
                  <th 
                    onClick={() => handleSortClick("orders")}
                    className="py-2.5 text-center font-bold cursor-pointer hover:text-gray-900 dark:hover:text-white transition-all"
                  >
                    <div className="flex items-center justify-center gap-1">
                      <span>Sales</span>
                      <ArrowUpDown className="h-3 w-3 text-gray-300" />
                    </div>
                  </th>

                  {/* Revenue Sortable */}
                  <th 
                    onClick={() => handleSortClick("revenue")}
                    className="py-2.5 text-right font-bold cursor-pointer hover:text-gray-900 dark:hover:text-white transition-all text-emerald-600 dark:text-emerald-400"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Revenue</span>
                      <ArrowUpDown className="h-3 w-3 text-gray-300" />
                    </div>
                  </th>

                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-zinc-850 text-gray-700 dark:text-zinc-300 font-medium font-sans">
                {sortedProducts.map((pro, idx) => {
                  const highlightHeader = sortColumn;

                  return (
                    <tr key={pro.name} className="hover:bg-gray-55/40 dark:hover:bg-zinc-850/20 transition-colors">
                      {/* Name */}
                      <td className="py-3 px-1">
                        <div>
                          <p className="font-extrabold text-gray-950 dark:text-white">{pro.name}</p>
                          <span className="text-[9px] text-gray-400 block font-mono">ID SKU #044{idx + 1}</span>
                        </div>
                      </td>

                      {/* Category */}
                      <td className="py-3 text-center">
                        <span className="text-[10px] font-semibold bg-gray-100 hover:bg-gray-200/50 dark:bg-zinc-850/60 dark:hover:bg-zinc-800 rounded px-2.5 py-1 text-gray-600 dark:text-zinc-300 inline-block">
                          {pro.category}
                        </span>
                      </td>

                      {/* Views */}
                      <td className={`py-3 text-center font-mono ${highlightHeader === "views" ? "font-bold text-gray-950 dark:text-white" : "text-gray-500"}`}>
                        {pro.views.toLocaleString()}
                      </td>

                      {/* ATC Rate */}
                      <td className="py-3 text-center">
                        <span className={`font-mono text-xs font-bold text-cyan-600 dark:text-cyan-400 ${highlightHeader === "addToCartRate" && "underline decoration-cyan-400 decoration-2"}`}>
                          {pro.addToCartRate}%
                        </span>
                      </td>

                      {/* Purchase Rate */}
                      <td className="py-3 text-center">
                        <span className={`font-mono text-xs font-bold text-indigo-650 dark:text-indigo-400 ${highlightHeader === "purchaseRate" && "underline decoration-indigo-400 decoration-2"}`}>
                          {pro.purchaseRate}%
                        </span>
                      </td>

                      {/* Orders */}
                      <td className={`py-3 text-center font-mono ${highlightHeader === "orders" ? "font-bold text-gray-950 dark:text-white" : "text-gray-500"}`}>
                        {pro.orders.toLocaleString()}
                      </td>

                      {/* Revenue */}
                      <td className={`py-3 text-right font-black font-mono text-gray-900 dark:text-white ${highlightHeader === "revenue" && "text-emerald-600 dark:text-emerald-400 text-sm"}`}>
                        ${pro.revenue.toLocaleString()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {sortedProducts.length === 0 && (
            <div className="text-center py-8 text-gray-400 font-light text-xs font-sans">
              No matching records identified in the sorted matrix grid. Try adjusting search queries.
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
