import {
  ArrowRight,
  TrendingUp,
  Zap,
  Globe,
  Database,
  Lock,
  ChevronRight,
  Sparkles,
  ShoppingBag,
  Users,
  ShieldAlert,
  FolderSync
} from "lucide-react";
import { count } from "console";

interface LandingPageProps {
  onExploreDemo: () => void;
  onGoToUpload: () => void;
}

export default function LandingPage({ onExploreDemo, onGoToUpload }: LandingPageProps) {
  const stats = [
    { label: "Average Purchase Lift", value: "+28.4%", desc: "Proven through algorithmic friction-removal advice." },
    { label: "Cart Completion rate", value: "74.6%", desc: "Averages 12%+ points over standard benchmark platforms." },
    { label: "Data Pipeline ingestion", value: "instant", desc: "Universal mapping parses complex multi-store outputs in seconds." },
    { label: "Annual Client Revenue Tracked", value: "$1.4B+", desc: "Powering modern retail catalog streams worldwide." }
  ];

  const features = [
    {
      icon: TrendingUp,
      title: "Funnel Recovery Intelligence",
      desc: "Isolate precise stage leakage levels down to individual device dimensions, pinpointing friction sources automatically."
    },
    {
      icon: Users,
      title: "Interactive Retention Cohorts",
      desc: "Visualize Day-30, Day-60, and Day-90 lifetime cycles with colored heatmaps tracking exactly when customers disengage."
    },
    {
      icon: Zap,
      title: "Simulated Live Metrics Engine",
      desc: "Stream real-time checkout actions, revenue ticker indices, and cart updates in real-time, perfect for control centers."
    },
    {
      icon: Sparkles,
      title: "Generative AI Analyst Assistant",
      desc: "Leverage server-side Gemini 3.5 models to execute automated diagnostic logs and customized optimization summaries directly."
    }
  ];

  return (
    <div id="landing-page-root" className="min-h-screen bg-neutral-950 text-neutral-100 font-sans overflow-x-hidden selection:bg-cyan-500/30">
      
      {/* Decorative background visual ambient glows */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Hero Header Navbar of Landing Page */}
      <nav className="border-b border-neutral-900 bg-neutral-950/80 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-9 w-9 rounded-xl flex items-center justify-center bg-gradient-to-tr from-cyan-500 to-indigo-600 text-white font-black text-sm tracking-tighter">
              C
            </div>
            <span className="font-extrabold text-sm tracking-tight bg-gradient-to-r from-neutral-50 to-neutral-300 bg-clip-text text-transparent">
              Convert<span className="text-cyan-400">IQ</span>
            </span>
          </div>
          
          <div className="flex items-center gap-4">
            <button
              onClick={onExploreDemo}
              className="text-xs font-semibold text-neutral-400 hover:text-white transition-all cursor-pointer"
            >
              Integrations
            </button>
            <button
              onClick={onExploreDemo}
              className="text-xs font-semibold text-neutral-400 hover:text-white transition-all cursor-pointer"
            >
              Pricing
            </button>
            <button
              id="landing-navbar-cta-demo"
              onClick={onExploreDemo}
              className="text-xs font-bold text-cyan-400 border border-cyan-500/30 hover:border-cyan-400 bg-cyan-950/20 px-3.5 py-1.5 rounded-xl transition-all cursor-pointer"
            >
              Demo Core
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Layout */}
      <section className="max-w-7xl mx-auto px-6 pt-16 pb-20 relative text-center">
        <div className="inline-flex items-center gap-1.5 py-1 px-3 mb-6 rounded-full bg-indigo-950/40 border border-indigo-900/60 text-indigo-300 text-[10px] font-bold uppercase tracking-widest animate-pulse">
          <Sparkles className="h-3 w-3 text-cyan-400" />
          <span>V3.5 Intelligence Hub Powered by Gemini</span>
        </div>
        
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-white max-w-4xl mx-auto leading-[1.1]">
          E-commerce conversion <br />
          <span className="bg-gradient-to-r from-cyan-400 via-indigo-400 to-purple-500 bg-clip-text text-transparent font-black">
            intelligence without guesswork.
          </span>
        </h1>
        
        <p className="text-sm md:text-base text-neutral-400 max-w-2xl mx-auto mt-6 leading-relaxed">
          Stop wondering why checkout funnels abandon. Upload your analytics logs, parse traffic ROIs instantly, and generate actionable improvement checklists using enterprise-grade diagnostic maps.
        </p>

        {/* Action Button Tethers */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-10">
          <button
            id="landing-hero-cta-upload"
            onClick={onGoToUpload}
            className="w-full sm:w-auto flex items-center justify-center gap-2 bg-gradient-to-tr from-cyan-500 to-indigo-600 hover:opacity-90 text-white font-bold text-xs px-6 py-3.5 rounded-xl transition-all shadow-lg shadow-indigo-600/10 cursor-pointer"
          >
            <span>Upload Your Data</span>
            <FolderSync className="h-3.5 w-3.5" />
          </button>
          
          <button
            id="landing-hero-cta-demo"
            onClick={onExploreDemo}
            className="w-full sm:w-auto flex items-center justify-center gap-2 bg-neutral-900/70 hover:bg-neutral-900 text-neutral-200 border border-neutral-800 font-bold text-xs px-6 py-3.5 rounded-xl transition-all cursor-pointer"
          >
            <span>Explore Demo Dashboard</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>

        {/* Interactive Dashboard Graphic Mockup */}
        <div className="mt-14 max-w-5xl mx-auto p-1.5 rounded-2xl bg-neutral-900/60 border border-neutral-800/80 shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 left-0 right-0 h-8 bg-neutral-950/80 border-b border-neutral-900 flex items-center px-4 gap-1.5">
            <div className="h-2.5 w-2.5 rounded-full bg-rose-500" />
            <div className="h-2.5 w-2.5 rounded-full bg-amber-500" />
            <div className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
            <div className="ml-4 text-[10px] text-neutral-500 font-mono">https://convertiq.io/console/demostore</div>
          </div>
          <div className="pt-8 h-80 bg-neutral-950 overflow-hidden flex flex-col justify-between">
            {/* Inner aesthetic chart lines simulating analytics UI layout */}
            <div className="p-4 flex justify-between border-b border-neutral-900">
              <div className="text-left space-y-1">
                <span className="text-[10px] text-neutral-500">CONVERSION INTELLIGENCE GATEWAYS</span>
                <p className="text-sm font-bold text-white flex items-center gap-1.5">
                  Gross Growth Velocity <span className="text-xs text-emerald-400 font-semibold">+14.2%</span>
                </p>
              </div>
              <div className="flex gap-2">
                <div className="h-6 w-16 rounded bg-neutral-900 border border-neutral-800 animate-pulse" />
                <div className="h-6 w-16 rounded bg-neutral-900 border border-neutral-800 animate-pulse" />
              </div>
            </div>
            
            <div className="p-4 grid grid-cols-4 gap-3 flex-1 items-end">
              <div className="space-y-2">
                <div className="h-24 w-full rounded bg-gradient-to-t from-cyan-600/80 to-cyan-500/20" />
                <span className="text-[9px] text-neutral-500 font-mono">SESSIONS</span>
              </div>
              <div className="space-y-2">
                <div className="h-16 w-full rounded bg-gradient-to-t from-indigo-600/80 to-indigo-500/20" />
                <span className="text-[9px] text-neutral-500 font-mono">PAGE VIEWS</span>
              </div>
              <div className="space-y-2">
                <div className="h-10 w-full rounded bg-gradient-to-t from-purple-600/80 to-purple-500/20" />
                <span className="text-[9px] text-neutral-500 font-mono">CARTS</span>
              </div>
              <div className="space-y-2">
                <div className="h-6 w-full rounded bg-gradient-to-t from-indigo-600 to-indigo-400" />
                <span className="text-[9px] text-neutral-400 font-bold font-mono">PURCHASES</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Showcase Grid */}
      <section className="border-t border-neutral-900 bg-neutral-900/10 py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs text-cyan-400 font-extrabold uppercase tracking-widest">Enterprise Platform Capabilities</span>
            <h2 className="text-xl md:text-3xl font-bold text-white mt-2">Engineered for data-driven operations.</h2>
            <p className="text-xs text-neutral-400 mt-3">
              Deep-dive metrics across entire visual lifecycles. No complex SQL configurations or broken Tag Manager parameters needed.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feat, index) => {
              const Icon = feat.icon;
              return (
                <div key={index} className="p-5 rounded-2xl bg-neutral-900/40 border border-neutral-800/80 hover:border-neutral-700/60 transition-all duration-300">
                  <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-cyan-500/10 to-indigo-600/10 flex items-center justify-center text-cyan-400 mb-4">
                    <Icon className="h-5 w-5" />
                  </div>
                  <h3 className="text-xs font-bold text-white">{feat.title}</h3>
                  <p className="text-[11px] text-neutral-400 mt-2 leading-relaxed">{feat.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Stats and Value Proposition Grid */}
      <section className="max-w-7xl mx-auto px-6 py-16 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div>
          <span className="text-xs text-indigo-400 font-bold uppercase tracking-widest">Value Proposition</span>
          <h2 className="text-xl md:text-3xl font-extrabold text-white mt-2 leading-snug">
            We deliver the clarity missing in classic analytical dashboards.
          </h2>
          <p className="text-xs text-neutral-400 mt-4 leading-relaxed">
            Classic e-commerce trackers tell you *what* happened but completely obscure *where* potential revenue was leaked. ConvertIQ utilizes automated funnel metrics mapping combined with server-side LLM diagnosis to compile diagnostic solutions on the spot, empowering product growth leads.
          </p>
          <div className="mt-6 space-y-3.5">
            <div className="flex gap-2.5 items-start">
              <div className="h-5 w-5 rounded bg-cyan-950/40 border border-cyan-800 flex items-center justify-center text-cyan-300 font-bold text-[10px]">✓</div>
              <span className="text-xs text-neutral-300 font-medium">Bypass complex spreadsheet conversions or formula setups.</span>
            </div>
            <div className="flex gap-2.5 items-start">
              <div className="h-5 w-5 rounded bg-cyan-950/40 border border-cyan-800 flex items-center justify-center text-cyan-300 font-bold text-[10px]">✓</div>
              <span className="text-xs text-neutral-300 font-medium">Isolate anomalous dropoffs matching desktop vs. mobile users dynamically.</span>
            </div>
            <div className="flex gap-2.5 items-start">
              <div className="h-5 w-5 rounded bg-cyan-950/40 border border-cyan-800 flex items-center justify-center text-cyan-300 font-bold text-[10px]">✓</div>
              <span className="text-xs text-neutral-300 font-medium font-sans">Receive instant diagnostic reports using Google's highly advanced Gemini models.</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {stats.map((st, i) => (
            <div key={i} className="p-5 rounded-2xl bg-neutral-900/30 border border-neutral-800/80 border-b-2 border-b-indigo-500/20 text-left">
              <p className="text-2xl font-black text-white tracking-tight">{st.value}</p>
              <p className="text-[10px] font-bold text-indigo-300 uppercase mt-1 tracking-wider">{st.label}</p>
              <p className="text-[10px] text-neutral-500 mt-1 lines-2 leading-normal">{st.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-neutral-900/30 border-t border-b border-neutral-900 py-16 text-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/5 to-transparent pointer-events-none" />
        <div className="max-w-3xl mx-auto px-6 relative z-10">
          <h2 className="text-2xl md:text-3xl font-black text-white tracking-tight">
            Ready to reclaim lost e-commerce margins?
          </h2>
          <p className="text-xs text-neutral-400 max-w-lg mx-auto mt-3">
            Load diagnostic CSV files (Shopify, Segment, or Amplitude analytics output formats supported) or immediately run the full simulated live control dashboard.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 items-center justify-center mt-8">
            <button
              id="landing-bottom-cta-upload"
              onClick={onGoToUpload}
              className="w-full sm:w-auto bg-gradient-to-tr from-cyan-500 to-indigo-600 hover:opacity-90 text-white font-bold text-xs px-5 py-3 rounded-xl cursor-pointer"
            >
              Upload Custom Log
            </button>
            <button
              id="landing-bottom-cta-demo"
              onClick={onExploreDemo}
              className="w-full sm:w-auto bg-neutral-950 hover:bg-neutral-900 text-neutral-300 border border-neutral-800 font-bold text-xs px-5 py-3 rounded-xl cursor-pointer"
            >
              Start Instantly
            </button>
          </div>
        </div>
      </section>

      {/* Footer Area */}
      <footer className="border-t border-neutral-900 py-10 bg-neutral-950">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <div className="h-6 w-6 rounded bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-white text-[10px] font-black">C</div>
            <span className="text-xs text-neutral-300 font-bold font-mono">ConvertIQ © 2026. All rights corporate reserved.</span>
          </div>
          <div className="flex gap-4 text-[10px] text-neutral-500">
            <a href="#privacy" className="hover:text-neutral-300">Privacy Policy</a>
            <a href="#terms" className="hover:text-neutral-300">Terms of Enterprise Support</a>
            <a href="#docs" className="hover:text-neutral-300">SaaS documentation</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
