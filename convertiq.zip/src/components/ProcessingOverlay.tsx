import { useState, useEffect } from "react";
import { Sparkles, BrainCircuit, Activity, RotateCw, CheckCircle, Database, BarChart } from "lucide-react";

interface ProcessingOverlayProps {
  onComplete: () => void;
  fileName?: string;
}

export default function ProcessingOverlay({ onComplete, fileName }: ProcessingOverlayProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [progress, setProgress] = useState(0);

  const steps = [
    { label: "Decoding Upload Structure & Headers", icon: Database, duration: 800 },
    { label: "Computing Multi-dimensional KPI Metrics", icon: Activity, duration: 1000 },
    { label: "Mapping Deep-Dive Funnel Leaking Stages", icon: BarChart, duration: 900 },
    { label: "Generating Artificial Intelligence recommendations", icon: BrainCircuit, duration: 1100 }
  ];

  useEffect(() => {
    let stepTimer: NodeJS.Timeout;
    let progressTimer: NodeJS.Timeout;

    // Simulate steady progress incrementation
    progressTimer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressTimer);
          return 100;
        }
        return prev + 1;
      });
    }, 38);

    const runSteps = (index: number) => {
      if (index >= steps.length) {
        setTimeout(() => {
          onComplete();
        }, 300);
        return;
      }

      stepTimer = setTimeout(() => {
        setCurrentStep(index + 1);
        runSteps(index + 1);
      }, steps[index].duration);
    };

    runSteps(0);

    return () => {
      clearTimeout(stepTimer);
      clearInterval(progressTimer);
    };
  }, []);

  return (
    <div className="fixed inset-0 bg-neutral-950/95 backdrop-blur-md z-50 flex flex-col items-center justify-center p-6 text-neutral-100 font-sans">
      
      {/* Visual background atmospheric orb */}
      <div className="absolute h-96 w-96 rounded-full bg-indigo-600/10 blur-3xl top-1/4 left-1/3 animate-pulse pointer-events-none" />

      <div className="w-full max-w-md text-center space-y-6 relative z-10">
        
        {/* Animated Visual Core */}
        <div className="relative h-20 w-20 mx-auto">
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-tr from-cyan-500 to-indigo-600 animate-spin duration-3000 opacity-60 filter blur-sm" />
          <div className="absolute inset-1.5 bg-neutral-950 rounded-2xl flex items-center justify-center">
            <BrainCircuit className="h-8 w-8 text-cyan-400 animate-pulse duration-1500" />
          </div>
        </div>

        {/* Dynamic header updates */}
        <div className="space-y-1.5">
          <h2 className="text-lg font-black text-white tracking-tight">Processing Analytics</h2>
          <p className="text-xs text-neutral-400">
            {currentStep < steps.length ? "Generating Business Insights" : "Preparing Dashboards"}
          </p>
          {fileName && (
            <span className="inline-block text-[10px] text-indigo-300 font-mono bg-indigo-950/50 p-1 px-2.5 rounded-md border border-indigo-900/40">
              parsing: {fileName}
            </span>
          )}
        </div>

        {/* Dynamic Loading Meter indicator */}
        <div className="space-y-2">
          <div className="flex justify-between text-[10px] text-neutral-500 font-mono">
            <span>ALGORITHMIC CALCULATION MATRIX</span>
            <span className="font-bold text-neural-300">{progress}%</span>
          </div>
          <div className="w-full bg-neutral-900 border border-neutral-800 rounded-full h-2.5 overflow-hidden p-0.5">
            <div
              className="bg-gradient-to-r from-cyan-400 via-indigo-500 to-purple-600 h-1.5 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Stepper Steps UI */}
        <div className="p-4 rounded-2xl bg-neutral-900/45 border border-neutral-800/80 text-left space-y-3">
          {steps.map((st, i) => {
            const Icon = st.icon;
            const isCompleted = i < currentStep;
            const isActive = i === currentStep;

            return (
              <div
                key={i}
                className={`flex gap-3 items-center transition-all duration-300 ${
                  isCompleted ? "text-neutral-300" : isActive ? "text-cyan-400 font-semibold" : "text-neutral-600"
                }`}
              >
                {isCompleted ? (
                  <CheckCircle className="h-4.5 w-4.5 text-emerald-500 flex-shrink-0" />
                ) : isActive ? (
                  <RotateCw className="h-4.5 w-4.5 text-cyan-400 animate-spin flex-shrink-0" />
                ) : (
                  <Icon className="h-4.5 w-4.5 flex-shrink-0" />
                )}
                <span className="text-[11px] truncate leading-none">{st.label}</span>
              </div>
            );
          })}
        </div>

      </div>
    </div>
  );
}
