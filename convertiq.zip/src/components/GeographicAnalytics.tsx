import { useState, useMemo } from "react";
import {
  Globe,
  MapPin,
  TrendingUp,
  TrendingDown,
  DollarSign,
  ShoppingBag,
  Award,
  Plus,
  Percent,
  Search,
  ChevronRight,
  Info,
  X,
  Map,
  Activity,
  ArrowUpRight,
  Layers
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  ComposedChart,
  Line
} from "recharts";
import { motion, AnimatePresence } from "motion/react";
import { IngestedRecord, GlobalFilters, UnifiedMetrics } from "../types";

interface GeographicAnalyticsProps {
  metrics: UnifiedMetrics;
  filters: GlobalFilters;
  setFilters: (filters: GlobalFilters) => void;
  isSimulating: boolean;
  uploadedData?: IngestedRecord[];
}

// Map detailed region strings to core 4 region keys
const mapToCoreRegion = (reg: string): "Americas" | "Europe" | "APAC" | "MEA" => {
  const r = (reg || "").toLowerCase();
  if (r.includes("amer") || r.includes("us") || r.includes("canada") || r.includes("brazil")) return "Americas";
  if (r.includes("euro") || r.includes("union") || r.includes("uk") || r.includes("german") || r.includes("france")) return "Europe";
  if (r.includes("apac") || r.includes("asia") || r.includes("pacif") || r.includes("tokyo") || r.includes("austr") || r.includes("tokyo")) return "APAC";
  if (r.includes("mea") || r.includes("middle") || r.includes("afric") || r.includes("dubai") || r.includes("east")) return "MEA";
  return "Americas"; // Default fallback
};

export default function GeographicAnalytics({
  metrics,
  filters,
  setFilters,
  isSimulating,
  uploadedData = []
}: GeographicAnalyticsProps) {
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"charts" | "table">("charts");

  // Colors mapping for charts and map zones
  const regionColors = {
    Americas: { fill: "#6366f1", stroke: "#818cf8", bg: "rgba(99, 102, 241, 0.15)", text: "text-indigo-600 dark:text-indigo-400" },
    Europe: { fill: "#0ea5e9", stroke: "#38bdf8", bg: "rgba(14, 165, 233, 0.15)", text: "text-sky-600 dark:text-sky-400" },
    APAC: { fill: "#10b981", stroke: "#34d399", bg: "rgba(16, 185, 129, 0.15)", text: "text-emerald-600 dark:text-emerald-400" },
    MEA: { fill: "#f59e0b", stroke: "#fbbf24", bg: "rgba(245, 158, 11, 0.15)", text: "text-amber-600 dark:text-amber-400" }
  };

  // 1. Process Raw regional segments from logs (if uploaded) or metrics data stream
  const computedRegionalData = useMemo(() => {
    // If not simulating and we have logs, we compute from active raw log files to keep 100% precision
    if (!isSimulating && uploadedData && uploadedData.length > 0) {
      const recordsToUse = uploadedData.filter(v => {
        // Apply other non-geographic global filters
        const recordTime = new Date(v.timestamp).getTime();
        // Calculate dynamic date constraint limit
        const timestamps = uploadedData.map(r => new Date(r.timestamp).getTime()).filter(t => !isNaN(t));
        const latestTime = timestamps.length > 0 ? timestamps.reduce((max, t) => t > max ? t : max, timestamps[0]) : Date.now();
        const daysLimit = filters.dateRange === "7d" ? 7 : filters.dateRange === "90d" ? 90 : 30;
        const milliLimit = daysLimit * 24 * 60 * 60 * 1000;

        if (isNaN(recordTime) || latestTime - recordTime > milliLimit) return false;

        if (filters.device !== "all" && v.device_type) {
          if (v.device_type.toLowerCase() !== filters.device.toLowerCase()) return false;
        }
        if (filters.product !== "all" && v.product_name) {
          const checkP = v.product_name.toLowerCase();
          const filterP = filters.product.toLowerCase();
          if (!checkP.includes(filterP)) return false;
        }
        if (filters.channel !== "all" && v.traffic_source) {
          if (v.traffic_source.toLowerCase() !== filters.channel.toLowerCase()) return false;
        }
        return true;
      });

      // Bin records by target region groups
      const bins: Record<"Americas" | "Europe" | "APAC" | "MEA", IngestedRecord[]> = {
        Americas: [],
        Europe: [],
        APAC: [],
        MEA: []
      };

      recordsToUse.forEach(rec => {
        const mapped = mapToCoreRegion(rec.region);
        bins[mapped].push(rec);
      });

      return (Object.keys(bins) as Array<keyof typeof bins>).map(rName => {
        const binRecs = bins[rName];
        const rSessions = new Set(binRecs.map(r => r.session_id)).size;
        const rPurchases = binRecs.filter(r => r.event_type === "purchase");
        const orders = rPurchases.length;
        const revenue = rPurchases.reduce((sum, r) => sum + r.revenue, 0);
        const conversion = rSessions > 0 ? parseFloat(((orders / rSessions) * 100).toFixed(2)) : 0;

        return {
          id: rName,
          name: rName,
          orders,
          revenue: Math.round(revenue),
          conversion: isNaN(conversion) ? 0 : conversion,
          percentage: 0 // Will compute relative share later
        };
      });
    }

    // In Simulation mode, map the mock dataset region output array
    const rawMockPerf = metrics.regionPerformance || [];
    const grouped = {
      Americas: { orders: 0, revenue: 0, conversionSum: 0, count: 0 },
      Europe: { orders: 0, revenue: 0, conversionSum: 0, count: 0 },
      APAC: { orders: 0, revenue: 0, conversionSum: 0, count: 0 },
      MEA: { orders: 0, revenue: 0, conversionSum: 0, count: 0 }
    };

    rawMockPerf.forEach(p => {
      const mapped = mapToCoreRegion(p.region);
      grouped[mapped].orders += p.orders;
      grouped[mapped].revenue += p.revenue;
      grouped[mapped].conversionSum += p.conversion;
      grouped[mapped].count += 1;
    });

    return (Object.keys(grouped) as Array<keyof typeof grouped>).map(rName => {
      const g = grouped[rName];
      return {
        id: rName,
        name: rName,
        orders: g.orders,
        revenue: g.revenue,
        conversion: g.count > 0 ? parseFloat((g.conversionSum / g.count).toFixed(2)) : 0,
        percentage: 0
      };
    });
  }, [isSimulating, uploadedData, metrics.regionPerformance, filters]);

  // Compute percentage contributions and totals
  const totalGeoRevenue = useMemo(() => computedRegionalData.reduce((sum, r) => sum + r.revenue, 0), [computedRegionalData]);
  const totalGeoOrders = useMemo(() => computedRegionalData.reduce((sum, r) => sum + r.orders, 0), [computedRegionalData]);

  const regionalDataWithContribution = useMemo(() => {
    return computedRegionalData.map(r => ({
      ...r,
      revenueContribution: totalGeoRevenue > 0 ? parseFloat(((r.revenue / totalGeoRevenue) * 100).toFixed(1)) : 0,
      orderContribution: totalGeoOrders > 0 ? parseFloat(((r.orders / totalGeoOrders) * 100).toFixed(1)) : 0
    })).sort((a, b) => b.revenue - a.revenue);
  }, [computedRegionalData, totalGeoRevenue, totalGeoOrders]);

  // Leaders highlights
  const topRegion = useMemo(() => {
    return [...regionalDataWithContribution].sort((a, b) => b.revenue - a.revenue)[0];
  }, [regionalDataWithContribution]);

  const topConvertingRegion = useMemo(() => {
    return [...regionalDataWithContribution].sort((a, b) => b.conversion - a.conversion)[0];
  }, [regionalDataWithContribution]);

  // Handle toggling the global region filter
  const toggleRegionFilter = (regionKey: string) => {
    // If already active, clear it. Otherwise, set it to selected key
    const newRegionValue = filters.region.toLowerCase() === regionKey.toLowerCase() ? "all" : regionKey;
    setFilters({
      ...filters,
      region: newRegionValue
    });
  };

  return (
    <div id="geographic-analytics-view" className="space-y-6">
      
      {/* Visual Header Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-gray-150 dark:border-zinc-850 pb-5 text-left">
        <div>
          <h2 className="text-xl font-extrabold text-gray-900 dark:text-white flex items-center gap-2 tracking-tight">
            <Globe className="h-5.5 w-5.5 text-indigo-505 bg-indigo-500/10 text-indigo-550 p-0.5 rounded-lg shrink-0" />
            <span>GeoDistribution Analytics</span>
          </h2>
          <p className="text-xs text-gray-500 dark:text-zinc-400 mt-1 leading-normal">
            Deep dive into localized user acquisitions, buying patterns, aggregate order metrics, and purchase conversion ratios. Click map nodes to apply cross-filters.
          </p>
        </div>

        {/* Global Filter Indicator */}
        <div className="flex items-center gap-2">
          {filters.region !== "all" && (
            <button
              onClick={() => setFilters({ ...filters, region: "all" })}
              className="text-[10px] bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 px-2.5 py-1 rounded-full flex items-center gap-1 hover:bg-indigo-500/20 transition-all font-bold"
            >
              <span>Map filter active: {filters.region}</span>
              <X className="h-3 w-3" />
            </button>
          )}

          <span className={`text-[10px] uppercase tracking-wider font-extrabold px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-xs border ${
            isSimulating
              ? "bg-amber-500/10 text-amber-650 dark:text-amber-400 border-amber-500/20"
              : "bg-emerald-500/10 text-emerald-650 dark:text-emerald-400 border-emerald-500/20"
          }`}>
            <span className={`h-2 w-2 rounded-full ${isSimulating ? "bg-amber-500 animate-pulse" : "bg-emerald-500"}`} />
            <span>{isSimulating ? "Demo Sim Streams" : "Live Store Ingest Streams"}</span>
          </span>
        </div>
      </div>

      {/* Heuristic High-Value KPI Summaries */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-left">
        {/* KPI 1: Top performing region */}
        {topRegion && (
          <div className="p-4 rounded-xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/30 flex items-center gap-4.5">
            <div className="p-3 rounded-lg bg-indigo-500/10 text-indigo-500 shrink-0">
              <Award className="h-5 w-5" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-gray-400 block font-mono">Revenue Champion</span>
              <h4 className="text-lg font-black text-gray-900 dark:text-white mt-0.5">{topRegion.name}</h4>
              <p className="text-[11px] text-gray-500 mt-1">
                Generates <strong>${topRegion.revenue.toLocaleString()}</strong> ({topRegion.revenueContribution}% share)
              </p>
            </div>
          </div>
        )}

        {/* KPI 2: Highest converting region */}
        {topConvertingRegion && (
          <div className="p-4 rounded-xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/30 flex items-center gap-4.5">
            <div className="p-3 rounded-lg bg-emerald-500/10 text-emerald-500 shrink-0">
              <TrendingUp className="h-5 w-5" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-gray-400 block font-mono">Top Conversion Rate</span>
              <h4 className="text-lg font-black text-emerald-600 dark:text-emerald-400 mt-0.5">{topConvertingRegion.conversion}% CR</h4>
              <p className="text-[11px] text-gray-500 mt-1">
                Highest checkout velocity holds in the <strong>{topConvertingRegion.name}</strong> region.
              </p>
            </div>
          </div>
        )}

        {/* KPI 3: Global footprint aggregates */}
        <div className="p-4 rounded-xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/30 flex items-center gap-4.5">
          <div className="p-3 rounded-lg bg-sky-500/10 text-sky-500 shrink-0">
            <ShoppingBag className="h-5 w-5" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold tracking-wider text-gray-400 block font-mono">Total Global Orders</span>
            <h4 className="text-lg font-black text-gray-900 dark:text-white mt-0.5">{totalGeoOrders.toLocaleString()} Sales</h4>
            <p className="text-[11px] text-gray-500 mt-1">
              Spanning <strong>4 major key hubs</strong> representing total global logistics.
            </p>
          </div>
        </div>
      </div>

      {/* Main interactive map & cross filter panel */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        
        {/* INTERACTIVE GEOGRAPHIC SVG WORLD MAP */}
        <div className="col-span-1 lg:col-span-3 p-5 rounded-2xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 text-left flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center border-b border-gray-100 dark:border-zinc-805 pb-3">
              <div>
                <h3 className="text-xs font-black tracking-widest text-indigo-650 dark:text-indigo-400 uppercase font-mono flex items-center gap-2">
                  <Map className="h-4 w-4" />
                  <span>Interactive Regional Overlay Projection</span>
                </h3>
                <p className="text-[10.5px] text-gray-400">Pulsing anchors indicate region metrics. Hover to load tooltips, Click to isolate filters.</p>
              </div>

              <span className="text-[9px] bg-gray-100 dark:bg-zinc-800 px-2 py-1 rounded text-gray-400 font-mono font-bold uppercase select-none">
                Mercator Grid Projection
              </span>
            </div>

            {/* World Map SVG Layout Content */}
            <div className="relative mt-8 select-none bg-gray-50/50 dark:bg-zinc-950/20 border border-gray-150/40 dark:border-zinc-850/40 rounded-xl overflow-hidden p-3 flex items-center justify-center">
              
              <svg viewBox="0 0 1000 520" className="w-full h-auto text-gray-300 dark:text-zinc-800">
                {/* Stylized background gridlines for high-tech SaaS map theme */}
                <line x1="0" y1="130" x2="1000" y2="130" stroke="rgba(128,128,128,0.06)" strokeDasharray="3 3" />
                <line x1="0" y1="260" x2="1000" y2="260" stroke="rgba(128,128,128,0.06)" strokeDasharray="3 3" />
                <line x1="0" y1="390" x2="1000" y2="390" stroke="rgba(128,128,128,0.06)" strokeDasharray="3 3" />
                <line x1="200" y1="0" x2="200" y2="520" stroke="rgba(128,128,128,0.06)" strokeDasharray="3 3" />
                <line x1="400" y1="0" x2="400" y2="520" stroke="rgba(128,128,128,0.06)" strokeDasharray="3 3" />
                <line x1="600" y1="0" x2="600" y2="520" stroke="rgba(128,128,128,0.06)" strokeDasharray="3 3" />
                <line x1="800" y1="0" x2="800" y2="520" stroke="rgba(128,128,128,0.06)" strokeDasharray="3 3" />

                {/* Highly structured, clean polygonal vector silhouettes matching continents */}
                {/* AMERICAS (North and South America silhouette) */}
                <path
                  d="M 120,40 L 260,40 L 290,130 L 250,195 L 300,240 L 260,330 L 298,460 L 260,490 L 210,410 L 220,310 L 170,250 L 150,150 Z"
                  fill={filters.region.toLowerCase() === "americas" ? "rgba(99, 102, 241, 0.22)" : "rgba(128, 128, 128, 0.08)"}
                  stroke={filters.region.toLowerCase() === "americas" ? "#6366f1" : "rgba(128, 128, 128, 0.18)"}
                  strokeWidth={1.5}
                  className="transition-all duration-300 cursor-pointer hover:fill-indigo-500/10 focus:outline-none"
                  onClick={() => toggleRegionFilter("Americas")}
                  onMouseEnter={() => setHoveredRegion("Americas")}
                  onMouseLeave={() => setHoveredRegion(null)}
                />

                {/* EUROPE (Europe silhouette) */}
                <path
                  d="M 440,40 L 590,40 L 610,90 L 590,160 L 520,180 L 460,140 L 439,90 Z"
                  fill={filters.region.toLowerCase() === "europe" ? "rgba(14, 165, 233, 0.22)" : "rgba(128, 128, 128, 0.08)"}
                  stroke={filters.region.toLowerCase() === "europe" ? "#0ea5e9" : "rgba(128, 128, 128, 0.18)"}
                  strokeWidth={1.5}
                  className="transition-all duration-300 cursor-pointer hover:fill-sky-500/10 focus:outline-none"
                  onClick={() => toggleRegionFilter("Europe")}
                  onMouseEnter={() => setHoveredRegion("Europe")}
                  onMouseLeave={() => setHoveredRegion(null)}
                />

                {/* MEA (Africa + Middle East silhouette) */}
                <path
                  d="M 440,150 L 540,190 L 590,260 L 550,330 L 520,440 L 476,430 L 410,310 L 398,210 Z"
                  fill={filters.region.toLowerCase() === "mea" ? "rgba(245, 158, 11, 0.22)" : "rgba(128, 128, 128, 0.08)"}
                  stroke={filters.region.toLowerCase() === "mea" ? "#f59e0b" : "rgba(128, 128, 128, 0.18)"}
                  strokeWidth={1.5}
                  className="transition-all duration-300 cursor-pointer hover:fill-amber-500/10 focus:outline-none"
                  onClick={() => toggleRegionFilter("MEA")}
                  onMouseEnter={() => setHoveredRegion("MEA")}
                  onMouseLeave={() => setHoveredRegion(null)}
                />

                {/* APAC (Asia + Australia + Southeast Asia silhouette) */}
                <path
                  d="M 600,60 L 890,70 L 920,240 L 820,330 L 880,480 L 780,470 L 700,320 L 610,210 Z"
                  fill={filters.region.toLowerCase() === "apac" ? "rgba(16, 185, 129, 0.22)" : "rgba(128, 128, 128, 0.08)"}
                  stroke={filters.region.toLowerCase() === "apac" ? "#10b981" : "rgba(128, 128, 128, 0.18)"}
                  strokeWidth={1.5}
                  className="transition-all duration-300 cursor-pointer hover:fill-emerald-500/10 focus:outline-none"
                  onClick={() => toggleRegionFilter("APAC")}
                  onMouseEnter={() => setHoveredRegion("APAC")}
                  onMouseLeave={() => setHoveredRegion(null)}
                />

                {/* Dotted connections depicting logistics channel routes to visual centers */}
                <path d="M 230,170 Q 350,150 490,120" stroke="rgba(99, 102, 241, 0.2)" strokeWidth={1} strokeDasharray="3 4" fill="none" />
                <path d="M 760,200 Q 640,240 500,280" stroke="rgba(16, 185, 129, 0.2)" strokeWidth={1} strokeDasharray="3 4" fill="none" />

                {/* -----------------------------------------------------------------
                    REGIONAL ANCHOR HOTSPOTS & BEACONS
                    ----------------------------------------------------------------- */}
                {/* Node 1: AMERICAS (Anchored near NY - 210, 130) */}
                <g onClick={() => toggleRegionFilter("Americas")} className="cursor-pointer">
                  {filters.region.toLowerCase() === "all" || filters.region.toLowerCase() === "americas" ? (
                    <circle cx="210" cy="130" r="22" fill="rgba(99, 102, 241, 0.15)" stroke="rgba(99, 102, 241, 0.4)" strokeWidth={1} className={filters.region.toLowerCase() === "americas" ? "animate-pulse" : ""} />
                  ) : null}
                  <circle cx="210" cy="130" r="6" fill="#6366f1" />
                  <circle cx="210" cy="130" r="1.5" fill="#fff" />
                </g>

                {/* Node 2: EUROPE (Anchored near London/Paris - 490, 120) */}
                <g onClick={() => toggleRegionFilter("Europe")} className="cursor-pointer">
                  {filters.region.toLowerCase() === "all" || filters.region.toLowerCase() === "europe" ? (
                    <circle cx="490" cy="120" r="18" fill="rgba(14, 165, 233, 0.15)" stroke="rgba(14, 165, 233, 0.4)" strokeWidth={1} className={filters.region.toLowerCase() === "europe" ? "animate-pulse" : ""} />
                  ) : null}
                  <circle cx="490" cy="120" r="6" fill="#0ea5e9" />
                  <circle cx="490" cy="120" r="1.5" fill="#fff" />
                </g>

                {/* Node 3: MEA (Anchored near Dubai - 580, 200) */}
                <g onClick={() => toggleRegionFilter("MEA")} className="cursor-pointer">
                  {filters.region.toLowerCase() === "all" || filters.region.toLowerCase() === "mea" ? (
                    <circle cx="580" cy="200" r="14" fill="rgba(245, 158, 11, 0.15)" stroke="rgba(245, 158, 11, 0.4)" strokeWidth={1} className={filters.region.toLowerCase() === "mea" ? "animate-pulse" : ""} />
                  ) : null}
                  <circle cx="580" cy="200" r="6" fill="#f59e0b" />
                  <circle cx="580" cy="200" r="1.5" fill="#fff" />
                </g>

                {/* Node 4: APAC (Anchored near Tokyo - 780, 160) */}
                <g onClick={() => toggleRegionFilter("APAC")} className="cursor-pointer">
                  {filters.region.toLowerCase() === "all" || filters.region.toLowerCase() === "apac" ? (
                    <circle cx="780" cy="160" r="20" fill="rgba(16, 185, 129, 0.15)" stroke="rgba(16, 185, 129, 0.4)" strokeWidth={1} className={filters.region.toLowerCase() === "apac" ? "animate-pulse" : ""} />
                  ) : null}
                  <circle cx="780" cy="160" r="6" fill="#10b981" />
                  <circle cx="780" cy="160" r="1.5" fill="#fff" />
                </g>

              </svg>

              {/* Floating, dynamic HTML tooltip inside the relative viewport container */}
              <AnimatePresence>
                {(hoveredRegion || filters.region !== "all") && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute bottom-4 left-4 right-4 bg-zinc-950/95 text-white border border-zinc-800 p-3 rounded-xl shadow-xl flex items-center justify-between text-xs backdrop-blur-md"
                  >
                    {(() => {
                      const tgtKey = (hoveredRegion || filters.region) as keyof typeof regionColors;
                      const stats = regionalDataWithContribution.find(x => x.id === tgtKey);
                      if (!stats) return <p className="text-gray-400">Hover or select a region node to query local metrics.</p>;

                      return (
                        <>
                          <div className="flex items-center gap-2">
                            <span className="h-3 w-3 rounded-full" style={{ backgroundColor: regionColors[stats.id as keyof typeof regionColors].fill }} />
                            <div>
                              <p className="font-extrabold text-white text-[13px]">{stats.name} Segment</p>
                              <span className="text-[10px] text-zinc-400">
                                Global share: <strong>{stats.revenueContribution}%</strong> revenue • <strong>{stats.orderContribution}%</strong> orders
                              </span>
                            </div>
                          </div>

                          <div className="flex gap-4 items-center">
                            <div className="text-right">
                              <span className="text-[8px] text-zinc-500 uppercase font-bold font-mono">Revenue</span>
                              <p className="text-[12px] font-black text-emerald-400 font-mono">${stats.revenue.toLocaleString()}</p>
                            </div>
                            <div className="text-right">
                              <span className="text-[8px] text-zinc-500 uppercase font-bold font-mono">Conversion</span>
                              <p className="text-[12px] font-black text-indigo-300 font-mono">{stats.conversion}% CR</p>
                            </div>
                            {filters.region !== "all" && hoveredRegion === null && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setFilters({ ...filters, region: "all" });
                                }}
                                className="bg-zinc-800 hover:bg-zinc-700/80 rounded p-1 text-zinc-400 hover:text-white"
                                title="Reset filter"
                              >
                                <X className="h-3.5 w-3.5" />
                              </button>
                            )}
                          </div>
                        </>
                      );
                    })()}
                  </motion.div>
                )}
              </AnimatePresence>

            </div>

            <p className="text-[10px] text-gray-400 mt-3 text-center italic">
              *Note: Continent vector shapes represent localized regions. Click any vector region to configure cross-market filtering.
            </p>
          </div>
        </div>

        {/* REGIONAL STATS & SEGMENT LIST LISTER */}
        <div className="col-span-1 lg:col-span-2 p-5 rounded-2xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 text-left flex flex-col justify-between">
          <div>
            <div className="border-b border-gray-100 dark:border-zinc-805 pb-3 flex justify-between items-center">
              <div>
                <h3 className="text-xs font-black tracking-widest text-indigo-650 dark:text-indigo-400 uppercase font-mono">
                  Market Breakdown List
                </h3>
                <p className="text-[10.5px] text-gray-400">Total metrics mapped across individual operational hubs.</p>
              </div>

              <div className="flex bg-gray-150 dark:bg-zinc-850 p-0.5 rounded-md text-[9px] font-bold">
                <button
                  onClick={() => setActiveTab("charts")}
                  className={`px-2 py-1 rounded ${activeTab === "charts" ? "bg-white dark:bg-zinc-900 shadow-xs text-indigo-600 dark:text-indigo-400" : "text-gray-500"}`}
                >
                  Contrib %
                </button>
                <button
                  onClick={() => setActiveTab("table")}
                  className={`px-2 py-1 rounded ${activeTab === "table" ? "bg-white dark:bg-zinc-900 shadow-xs text-indigo-600 dark:text-indigo-400" : "text-gray-500"}`}
                >
                  Raw values
                </button>
              </div>
            </div>

            <div className="mt-5 space-y-4">
              {regionalDataWithContribution.map((region) => {
                const colorConfig = regionColors[region.id as keyof typeof regionColors] || { fill: "#6366f1", stroke: "#818cf8", bg: "rgba(99,102,241,0.1)", text: "" };
                const isSelected = filters.region.toLowerCase() === region.id.toLowerCase();

                return (
                  <div
                    key={region.id}
                    onClick={() => toggleRegionFilter(region.id)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer select-none text-left ${
                      isSelected
                        ? "bg-slate-50 dark:bg-zinc-900/60 border-indigo-500 ring-2 ring-indigo-500/10 shadow-md"
                        : "border-gray-150/60 dark:border-zinc-850 bg-gray-55/20 hover:bg-gray-100/50 dark:hover:bg-zinc-850/40"
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-2">
                        <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: colorConfig.fill }} />
                        <div>
                          <p className="text-[12.5px] font-black text-gray-800 dark:text-white flex items-center gap-1.5">
                            <span>{region.name}</span>
                            {isSelected && (
                              <span className="text-[8px] bg-indigo-600 text-white font-mono uppercase tracking-wider font-extrabold px-1.5 py-0.2 rounded-full">
                                Filtering Active
                              </span>
                            )}
                          </p>
                          <span className="text-[9.5px] text-gray-400 font-light block">Conversion Velocity</span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="text-xs font-black text-gray-900 dark:text-white font-mono">
                          {region.conversion}% CR
                        </span>
                        <span className="text-[8px] text-gray-450 block font-light">Average Session CR</span>
                      </div>
                    </div>

                    {/* Progress representation metrics based on tab selected */}
                    {activeTab === "charts" ? (
                      <div className="mt-3.5 space-y-2">
                        {/* Revenue contribution progress slider */}
                        <div>
                          <div className="flex justify-between text-[9px] text-gray-400 font-medium">
                            <span>Gross Revenue Share</span>
                            <span className="font-mono font-bold">${region.revenue.toLocaleString()} ({region.revenueContribution}%)</span>
                          </div>
                          <div className="w-full bg-gray-200 dark:bg-zinc-800 h-1.5 rounded-full mt-1.5 overflow-hidden">
                            <motion.div
                              className="h-full rounded-full"
                              style={{ backgroundColor: colorConfig.fill }}
                              initial={{ width: 0 }}
                              animate={{ width: `${region.revenueContribution}%` }}
                              transition={{ duration: 1 }}
                            />
                          </div>
                        </div>

                        {/* Orders contribution progress slider */}
                        <div>
                          <div className="flex justify-between text-[9px] text-gray-400 font-medium">
                            <span>Overall Order Volume</span>
                            <span className="font-mono font-bold">{region.orders.toLocaleString()} orders ({region.orderContribution}%)</span>
                          </div>
                          <div className="w-full bg-gray-200 dark:bg-zinc-800 h-1.5 rounded-full mt-1.5 overflow-hidden">
                            <motion.div
                              className="h-full rounded-full"
                              style={{ backgroundColor: colorConfig.stroke }}
                              initial={{ width: 0 }}
                              animate={{ width: `${region.orderContribution}%` }}
                              transition={{ duration: 1, delay: 0.1 }}
                            />
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="mt-3.5 grid grid-cols-2 gap-2 border-t border-gray-100 dark:border-zinc-805/40 pt-2 text-[10.5px]">
                        <div>
                          <span className="text-[8.5px] text-gray-450 uppercase font-bold font-mono">Attributed Profit</span>
                          <p className="font-bold text-gray-900 dark:text-white font-mono">${region.revenue.toLocaleString()}</p>
                        </div>
                        <div>
                          <span className="text-[8.5px] text-gray-450 uppercase font-bold font-mono">Order volume</span>
                          <p className="font-bold text-gray-900 dark:text-white font-mono">{region.orders.toLocaleString()} checkout items</p>
                        </div>
                      </div>
                    )}

                  </div>
                );
              })}
            </div>
          </div>

          <div className="border-t border-gray-100 dark:border-zinc-800/80 pt-3 mt-4 text-[10px] text-gray-400 flex items-start gap-2">
            <Info className="h-4 w-4 text-indigo-500 shrink-0 mt-0.5" />
            <p>
              Click any region card above to apply geographical data filtering across all other reporting dashboards and system logs.
            </p>
          </div>
        </div>

      </div>

      {/* COMPARATIVE CHARTS FOR REGIONAL BREAKDOWNS */}
      <div className="p-5 rounded-2xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 flex flex-col text-left">
        <div>
          <h3 className="text-xs font-black tracking-widest text-indigo-650 dark:text-indigo-400 uppercase font-mono flex items-center gap-1.5">
            <Activity className="h-4.5 w-4.5 text-indigo-550 shrink-0" />
            <span>Localized Performance Metrics charts</span>
          </h3>
          <p className="text-[10px] text-gray-400 mt-0.5">Comparative layouts rendering Revenue performance vs. conversion rate metrics.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          
          {/* Chart A: Revenue Shares */}
          <div className="h-72 border border-gray-100 dark:border-zinc-850 p-4 rounded-xl bg-gray-55/10">
            <p className="text-[11px] font-black text-gray-550 dark:text-white font-mono mb-4 uppercase">Regional Revenue Comparisons ($)</p>
            <ResponsiveContainer width="100%" height="90%">
              <BarChart data={regionalDataWithContribution} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(128,128,128,0.06)" />
                <XAxis dataKey="name" style={{ fontSize: 9, fill: "#888", fontWeight: "bold" }} tickLine={false} />
                <YAxis style={{ fontSize: 9, fill: "#888" }} tickFormatter={(v) => `$${v.toLocaleString()}`} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(12, 12, 12, 0.95)",
                    border: "1px solid rgba(80, 80, 80, 0.15)",
                    borderRadius: 12,
                    fontSize: 10,
                    color: "#fff"
                  }}
                  formatter={(val: any) => [`$${val.toLocaleString()}`, "Regional Revenue"]}
                />
                <Bar dataKey="revenue" name="Revenue ($)" radius={[4, 4, 0, 0]}>
                  {regionalDataWithContribution.map((entry, index) => {
                    const matchedCfg = regionColors[entry.id as keyof typeof regionColors] || { fill: "#6366f1" };
                    return <Cell key={`cell-${index}`} fill={matchedCfg.fill} />;
                  })}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Chart B: Orders & Conversions */}
          <div className="h-72 border border-gray-100 dark:border-zinc-850 p-4 rounded-xl bg-gray-55/10">
            <p className="text-[11px] font-black text-gray-550 dark:text-white font-mono mb-4 uppercase">Orders volume vs Conversion Rates</p>
            <ResponsiveContainer width="100%" height="90%">
              <ComposedChart data={regionalDataWithContribution} margin={{ top: 15, right: -15, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(128,128,128,0.06)" />
                <XAxis dataKey="name" style={{ fontSize: 9, fill: "#888", fontWeight: "bold" }} tickLine={false} />
                <YAxis style={{ fontSize: 9, fill: "#888" }} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(12, 12, 12, 0.95)",
                    border: "1px solid rgba(80, 80, 80, 0.15)",
                    borderRadius: 12,
                    fontSize: 10,
                    color: "#fff"
                  }}
                  formatter={(val: any, name: string) => [name === "conversion" ? `${val}%` : val.toLocaleString(), name === "conversion" ? "Conversion rate" : "Orders count"]}
                />
                <Legend wrapperStyle={{ fontSize: 9 }} />
                <Bar dataKey="orders" name="Checkout Orders count" fill="#6366f1" barSize={35} radius={[3, 3, 0, 0]} />
                <Line type="monotone" dataKey="conversion" name="Conversion Ratio (%)" stroke="#ec4899" strokeWidth={3} dot={{ strokeWidth: 2, r: 4 }} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>

        </div>
      </div>

    </div>
  );
}
