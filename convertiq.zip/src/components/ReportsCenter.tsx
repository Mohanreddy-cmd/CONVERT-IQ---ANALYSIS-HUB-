import { useState } from "react";
import {
  FileText,
  Download,
  CheckCircle,
  FileSpreadsheet,
  AlertCircle,
  FileCode,
  Share2,
  Calendar,
  Layers,
  Sparkles,
  Smartphone,
  TrendingUp,
  ShoppingBag,
  LineChart,
  Grid,
  Users,
  Award,
  Palette,
  Eye,
  MessageSquare,
  HelpCircle
} from "lucide-react";
import { UnifiedMetrics, AIAnalysisResult, IngestedRecord, GlobalFilters } from "../types";
import { jsPDF } from "jspdf";
import * as XLSX from "xlsx";
import Papa from "papaparse";

interface ReportsCenterProps {
  metrics: UnifiedMetrics;
  insights: AIAnalysisResult;
  uploadedData?: IngestedRecord[];
  filters?: GlobalFilters;
  isSimulating?: boolean;
  chatHistory?: { sender: 'user' | 'assistant'; text: string; time: string }[];
}

export default function ReportsCenter({
  metrics,
  insights,
  uploadedData = [],
  filters,
  isSimulating = true,
  chatHistory = []
}: ReportsCenterProps) {
  const [downloadingFormat, setDownloadingFormat] = useState<string | null>(null);
  const [activeSection, setActiveSection] = useState<"summary" | "funnel" | "customer" | "marketing" | "product" | "master-dossier">("master-dossier");
  const [selectedTemplate, setSelectedTemplate] = useState<"cyan" | "indigo" | "mono">("cyan");
  const [notification, setNotification] = useState<{ title: string; desc: string; type: "success" | "warning" } | null>(null);

  // Trigger temporary notification banners
  const showBanner = (title: string, desc: string, type: "success" | "warning" = "success") => {
    setNotification({ title, desc, type });
    setTimeout(() => setNotification(null), 4500);
  };

  // 1. DYNAMIC EXCEL DOWNLOADING FUNCTION (.xlsx)
  const downloadExcelReport = () => {
    try {
      setDownloadingFormat("XLSX");
      
      setTimeout(() => {
        const wb = XLSX.utils.book_new();

        // Sheet 1: Executive Overview
        const overviewRows = [
          { "Metric Indicator Name": "Total Store Net Revenue", "Calculated Value": metrics.revenue, "Category": "Finance KPI" },
          { "Metric Indicator Name": "Total Final Orders Completed", "Calculated Value": metrics.orders, "Category": "Sales KPI" },
          { "Metric Indicator Name": "Average Order Value (AOV)", "Calculated Value": metrics.aov, "Category": "Sales KPI" },
          { "Metric Indicator Name": "Store-wide Conversion Rate (%)", "Calculated Value": metrics.conversionRate, "Category": "Funnel Effectiveness" },
          { "Metric Indicator Name": "Overall Shopping Cart Abandonment (%)", "Calculated Value": metrics.cartAbandonment, "Category": "Customer Leakage" },
          { "Metric Indicator Name": "Returning Loyalty Customer Share (%)", "Calculated Value": metrics.returningCustomerRate, "Category": "Engagement KPI" },
          { "Metric Indicator Name": "Reporting Date Context", "Calculated Value": new Date().toLocaleString(), "Category": "Audit Context" }
        ];
        const wsOverview = XLSX.utils.json_to_sheet(overviewRows);
        XLSX.utils.book_append_sheet(wb, wsOverview, "1. Executive Summary");

        // Sheet 2: Funnel Analysis
        const funnelRows = metrics.funnelData.map((f) => ({
          "Funnel Phase Stage": f.stage,
          "Active Sessions Count": f.value,
          "Conversion Progress Ratio (%)": f.percentage,
          "Dropoff Point Penalty (%)": f.dropoff,
          "Calculated Potential Revenue Loss ($)": f.revenueLeakage || Math.round(metrics.revenue * (f.dropoff / 100))
        }));
        const wsFunnel = XLSX.utils.json_to_sheet(funnelRows);
        XLSX.utils.book_append_sheet(wb, wsFunnel, "2. Checkout Funnel");

        // Sheet 3: Customer Insights (Retention Cohorts)
        const cohortRows = metrics.cohortData.map((c) => ({
          "Registration Cohort Group": c.cohort,
          "Beginning Pool Size": c.size,
          "Month 1 Retention (%)": c.m1,
          "Month 2 Retention (%)": c.m2,
          "Month 3 Retention (%)": c.m3,
          "Month 4 Retention (%)": c.m4,
          "Month 5 Retention (%)": c.m5
        }));
        const wsCohort = XLSX.utils.json_to_sheet(cohortRows);
        XLSX.utils.book_append_sheet(wb, wsCohort, "3. Customer Lifecycles");

        // Sheet 4: Marketing Insights (Traffic Performance)
        const marketingRows = metrics.channelPerformance.map((c) => ({
          "Acquisition Source Channel": c.channel,
          "Session Visitors Count": c.visitors,
          "Converted Purchases": c.orders,
          "Channel Conversion Index (%)": c.conversion,
          "Attributed Store Revenue ($)": c.revenue,
          "Ad Spent ROI Multiplier": c.roi
        }));
        const wsMarketing = XLSX.utils.json_to_sheet(marketingRows);
        XLSX.utils.book_append_sheet(wb, wsMarketing, "4. Marketing Performance");

        // Sheet 5: Product Insights (Catalog metrics)
        const productRows = metrics.productPerformance.map((p) => ({
          "Product Listing Title": p.name,
          "Detail Views Visits": p.views,
          "Cart Inserts Additions": p.cartInserts,
          "Checkout Conversions": p.orders,
          "Direct Product Revenue ($)": p.revenue,
          "Individual Conversion Rate (%)": p.conversion
        }));
        const wsProduct = XLSX.utils.json_to_sheet(productRows);
        XLSX.utils.book_append_sheet(wb, wsProduct, "5. Catalog Analytics");

        // Sheet 6: Genuine Raw Ingested Logs (Only visible if database exists)
        if (uploadedData && uploadedData.length > 0) {
          const rawFormattedRows = uploadedData.slice(0, 1500).map((r, itemIdx) => ({
            "Line #": itemIdx + 1,
            "Timestamp Date": r.timestamp,
            "Session Key": r.session_id,
            "Customer Persona key": r.user_id,
            "Product ID SKU": r.product_id,
            "Catalog Item Name": r.product_name,
            "Classification Segment": r.category,
            "Funnel Event Code": r.event_type,
            "Acquisition Source": r.traffic_source,
            "Access Hardware Type": r.device_type,
            "Country / Region Location": r.region,
            "Transaction Value Item ($)": r.revenue
          }));
          const wsRawLogs = XLSX.utils.json_to_sheet(rawFormattedRows);
          XLSX.utils.book_append_sheet(wb, wsRawLogs, "6. Uploaded Audit Logs");
        }

        // Output write
        XLSX.writeFile(wb, `ConvertIQ_Analytics_Package_${new Date().toISOString().slice(0, 10)}.xlsx`);
        setDownloadingFormat(null);
        showBanner(
          "Excel Workbook Extracted",
          `Full multi-sheet performance spreadsheet compiled: ${uploadedData.length > 0 ? uploadedData.length + " real logs parsed." : "100% dynamic simulation records applied."}`
        );
      }, 1000);
    } catch (err: any) {
      console.error(err);
      setDownloadingFormat(null);
      showBanner("Spreadsheet Error", "Failed to compile the active workbook parameters. Please try again.", "warning");
    }
  };

  // 2. DYNAMIC CSV DOWNLOADING FUNCTION (.csv)
  // Allows users to export the specific tab data, or if uploadedData exists, the entire raw CSV logs file.
  const downloadCSVExport = (tableType: "active-view" | "full-raw-logs") => {
    try {
      setDownloadingFormat("CSV");
      
      setTimeout(() => {
        let exportArray: any[] = [];
        let fileName = "ConvertIQ_Export.csv";

        if (tableType === "full-raw-logs" && uploadedData && uploadedData.length > 0) {
          exportArray = uploadedData;
          fileName = `Raw_Ingested_Store_Records_${new Date().toISOString().slice(0, 10)}.csv`;
        } else {
          // Export active viewport segment datasets
          if (activeSection === "summary") {
            exportArray = [
              { Metric: "Revenue", Value: metrics.revenue },
              { Metric: "Total Orders", Value: metrics.orders },
              { Metric: "AOV", Value: metrics.aov },
              { Metric: "Conversion Rate", Value: `${metrics.conversionRate}%` },
              { Metric: "Cart Abandonment", Value: `${metrics.cartAbandonment}%` },
              { Metric: "Returning Customer Rate", Value: `${metrics.returningCustomerRate}%` }
            ];
            fileName = "ConvertIQ_Executive_Metrics.csv";
          } else if (activeSection === "funnel") {
            exportArray = metrics.funnelData;
            fileName = "ConvertIQ_Funnel_Telemetry.csv";
          } else if (activeSection === "customer") {
            exportArray = metrics.cohortData;
            fileName = "ConvertIQ_Customer_Cohorts.csv";
          } else if (activeSection === "marketing") {
            exportArray = metrics.channelPerformance;
            fileName = "ConvertIQ_Marketing_Channel_ROI.csv";
          } else if (activeSection === "product") {
            exportArray = metrics.productPerformance;
            fileName = "ConvertIQ_Catalog_Performance.csv";
          }
        }

        const csvContent = Papa.unparse(exportArray);
        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", fileName);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        setDownloadingFormat(null);
        showBanner(
          "CSV Table Downloaded",
          `Export file [${fileName}] containing tabular operational parameters successfully parsed.`
        );
      }, 700);
    } catch (err) {
      setDownloadingFormat(null);
      showBanner("Extraction Block", "Could not assemble CSV columns from dynamic indices.", "warning");
    }
  };

  // 3. SECURE PDF WORKBOOK COMPILING FUNCTION (.pdf)
  const downloadPDFReport = () => {
    try {
      setDownloadingFormat("PDF");
      
      setTimeout(() => {
        const doc = new jsPDF({
          orientation: "portrait",
          unit: "mm",
          format: "a4" // 210mm Width x 297mm Height
        });

        // Determine Theme Palette
        let primaryColor = [6, 182, 212]; // Cyan
        let secondaryColor = [8, 145, 178]; // Deep Cyan
        if (selectedTemplate === "indigo") {
          primaryColor = [99, 102, 241]; // Indigo
          secondaryColor = [67, 56, 202]; // Deep Indigo
        } else if (selectedTemplate === "mono") {
          primaryColor = [39, 39, 42]; // Charcoal
          secondaryColor = [63, 63, 70]; // Off-charcoal
        }

        // Shared Page Header Decorator
        const decoratePageHeader = (sectionTitle: string, pageNum: number) => {
          // Main Corporate Header Banner
          doc.setFillColor(15, 23, 42); // slate-900 line banner
          doc.rect(0, 0, 210, 24, "F");

          // Left border accent line
          doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
          doc.rect(0, 0, 4, 24, "F");

          // Title
          doc.setTextColor(255, 255, 255);
          doc.setFont("helvetica", "bold");
          doc.setFontSize(10.5);
          doc.text("CONVERTIQ BUSINESS INTELLIGENCE SYSTEM", 12, 11);

          doc.setFont("helvetica", "normal");
          doc.setFontSize(7.5);
          doc.setTextColor(148, 163, 184); // slate-400
          doc.text(`ENTERPRISE OPERATIONAL PERFORMANCE REPORTS | ${filters?.dateRange ? `FILTER: ${filters.dateRange.toUpperCase()}` : "D30 SUMMARY"}`, 12, 16);

          // Right page count identifier
          doc.setTextColor(255, 255, 255);
          doc.setFont("helvetica", "bold");
          doc.setFontSize(8.5);
          doc.text(`PAGE ${pageNum} OF 5`, 185, 13);

          // Secondary Sub-Header section bar
          doc.setFillColor(241, 245, 249); // slate-100
          doc.rect(0, 24, 210, 9, "F");

          doc.setTextColor(71, 85, 105); // slate-600
          doc.setFont("helvetica", "bold");
          doc.setFontSize(8);
          doc.text(`REPORT BLOCK: ${sectionTitle.toUpperCase()}`, 12, 30);

          doc.setDrawColor(226, 232, 240); // slate-200
          doc.setLineWidth(0.3);
          doc.line(0, 33, 210, 33);
        };

        // Shared Footnote Decorator
        const decoratePageFooter = (yPos: number) => {
          doc.setDrawColor(241, 245, 249);
          doc.line(15, yPos, 195, yPos);
          doc.setFont("helvetica", "normal");
          doc.setFontSize(7);
          doc.setTextColor(148, 163, 184);
          doc.text("Information generated dynamically from store performance telemetry channels. Confidential & Proprietary.", 15, yPos + 4.5);
        };

        // ================= PAGE 1: EXECUTIVE & CONVERSION SUMMARY =================
        decoratePageHeader("Section A: Core Executive Performance", 1);
        let y = 44;

        // Big Display Heading
        doc.setTextColor(15, 23, 42);
        doc.setFontSize(17);
        doc.setFont("helvetica", "bold");
        doc.text("ConvertIQ Premium Store Audit", 15, y);
        y += 6.5;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(9.5);
        doc.setTextColor(71, 85, 105);
        doc.text("Executive performance dashboard compiling multi-channel revenue growth models and conversion indicators.", 15, y);
        y += 11;

        // Visual primary Accent Break line
        doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
        doc.rect(15, y, 180, 1.2, "F");
        y += 8;

        // KPI Matrix grid structure (6 dynamic indices)
        const kpis = [
          { label: "TOTAL RETRIEVED REVENUE", val: `$${metrics.revenue.toLocaleString()}`, color: primaryColor },
          { label: "TOTAL ORDERS COMPLETED", val: `${metrics.orders.toLocaleString()}`, color: [99, 102, 241] },
          { label: "AVERAGE ORDER VALUE (AOV)", val: `$${metrics.aov.toLocaleString()}`, color: [168, 85, 247] },
          { label: "CHECKOUT CONVERSION RATE", val: `${metrics.conversionRate}%`, color: [12, 175, 190] },
          { label: "CART ABANDONMENT RATE", val: `${metrics.cartAbandonment}%`, color: [244, 63, 94] },
          { label: "RETURNING LOYAL CUSTOMERS", val: `${metrics.returningCustomerRate}%`, color: [34, 197, 94] }
        ];

        doc.setLineWidth(0.25);
        doc.setDrawColor(226, 232, 240); // slate-200

        for (let i = 0; i < kpis.length; i++) {
          const col = i % 3;
          const row = Math.floor(i / 3);
          const xBox = 15 + col * 62;
          const yBox = y + row * 22;

          // Light background
          doc.setFillColor(250, 250, 250);
          doc.rect(xBox, yBox, 56, 17, "F");
          doc.rect(xBox, yBox, 56, 17, "S");

          // Left focus bar
          const cArray = kpis[i].color;
          doc.setFillColor(cArray[0], cArray[1], cArray[2]);
          doc.rect(xBox, yBox, 2, 17, "F");

          // Texts
          doc.setTextColor(148, 163, 184); // slate-400
          doc.setFont("helvetica", "bold");
          doc.setFontSize(6.5);
          doc.text(kpis[i].label, xBox + 4.5, yBox + 4.8);

          doc.setTextColor(15, 23, 42);
          doc.setFontSize(10.5);
          doc.setFont("helvetica", "bold");
          doc.text(kpis[i].val, xBox + 4.5, yBox + 12);
        }
        y += 48;

        // Executive Synthesis
        doc.setFont("helvetica", "bold");
        doc.setFontSize(9);
        doc.setTextColor(15, 23, 42);
        doc.text("EXECUTIVE PERFORMANCE ANALYSIS:", 15, y);
        y += 5.5;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(9);
        doc.setTextColor(51, 65, 85);

        const summaryPara = insights.executiveSummary || "Dynamic analysis computed successfully.";
        const wrappedSummary = doc.splitTextToSize(summaryPara, 180);
        doc.text(wrappedSummary, 15, y);
        y += wrappedSummary.length * 4.5 + 8;

        // Dynamic metrics-driven bullets
        doc.setFont("helvetica", "bold");
        doc.setFontSize(9);
        doc.setTextColor(15, 23, 42);
        doc.text("AUTOMATED SYSTEM OPTIMIZATION INSIGHTS:", 15, y);
        y += 6;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(8.5);

        const bulletInsights = [
          insights.revenueIncrInsight || `Revenue increased ${((metrics.revenue - metrics.revenue*0.88)/(metrics.revenue*0.88)*100).toFixed(1)}% due to checkout conversion stabilization.`,
          insights.deviceContrastInsight || "Mobile checkout pipelines display significant margin attrition.",
          insights.productLeverInsight || "High viewed catalog items display minor conversion friction."
        ];

        bulletInsights.forEach((bullet) => {
          doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
          doc.circle(18.5, y - 1, 1, "F");
          
          doc.setTextColor(51, 65, 85);
          const wrappedIn = doc.splitTextToSize(bullet, 172);
          doc.text(wrappedIn, 22, y);
          y += wrappedIn.length * 4.5 + 2.5;
        });

        // Add visual summary footer
        decoratePageFooter(280);

        // ================= PAGE 2: CONVERSION FUNNEL TELEMETRY =================
        doc.addPage();
        decoratePageHeader("Section B: Checkout Funnel Telemetry", 2);
        y = 44;

        doc.setFont("helvetica", "bold");
        doc.setFontSize(11);
        doc.setTextColor(15, 23, 42);
        doc.text("STAGE DROPOFF & MARGIN WEIGH-HOUSE ANALYSIS", 15, y);
        y += 5.5;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(9);
        doc.setTextColor(71, 85, 105);
        const funnelDesc = insights.conversionInsights || "Detailed drop-off funnel evaluating checkout stage leakages.";
        const wrappedFunnelDesc = doc.splitTextToSize(funnelDesc, 180);
        doc.text(wrappedFunnelDesc, 15, y);
        y += wrappedFunnelDesc.length * 4.5 + 8;

        // Funnel grid headers
        const fHeaders = ["FUNNEL PHASE DETAILED", "SESSIONS REGISTERED", "CUMULATIVE STICKY %", "DROPOFF RATE %", "POTENTIAL REVENUE LOSS ($)"];
        const fColWidths = [45, 34, 34, 34, 33];

        doc.setFillColor(15, 23, 42); // slate heading box
        doc.rect(15, y, 180, 8.5, "F");

        doc.setFont("helvetica", "bold");
        doc.setFontSize(8);
        doc.setTextColor(255, 255, 255);

        let curFX = 18;
        fHeaders.forEach((h, idx) => {
          doc.text(h, curFX, y + 5.8);
          curFX += fColWidths[idx];
        });
        y += 8.5;

        // Funnel rows
        metrics.funnelData.forEach((row, idx) => {
          if (idx % 2 === 1) {
            doc.setFillColor(248, 250, 252);
            doc.rect(15, y, 180, 8, "F");
          } else {
            doc.setDrawColor(241, 245, 249);
            doc.line(15, y + 8, 195, y + 8);
          }

          doc.setFont("helvetica", "normal");
          doc.setFontSize(8);
          doc.setTextColor(51, 65, 85);

          doc.text(row.stage, 18, y + 5.5);
          doc.text(row.value.toLocaleString(), 18 + fColWidths[0], y + 5.5);
          doc.text(`${row.percentage.toFixed(1)}%`, 18 + fColWidths[0] + fColWidths[1], y + 5.5);
          
          doc.setTextColor(row.dropoff > 50 ? 220 : 51, row.dropoff > 50 ? 38 : 65, row.dropoff > 50 ? 38 : 85);
          doc.text(`${row.dropoff.toFixed(1)}%`, 18 + fColWidths[0] + fColWidths[1] + fColWidths[2], y + 5.5);

          const leakage = row.revenueLeakage || Math.round(metrics.revenue * (row.dropoff / 100));
          doc.setTextColor(leakage > metrics.revenue * 0.1 ? 220 : 51, leakage > metrics.revenue * 0.1 ? 38 : 65, leakage > metrics.revenue * 0.1 ? 38 : 85);
          doc.text(`$${leakage.toLocaleString()}`, 18 + fColWidths[0] + fColWidths[1] + fColWidths[2] + fColWidths[3], y + 5.5);

          y += 8;
        });

        // Diagram Box simulating styled checkout funnel indicators
        y += 12;
        doc.setFillColor(248, 250, 252);
        doc.rect(15, y, 180, 26, "F");
        doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
        doc.setLineWidth(0.5);
        doc.rect(15, y, 180, 26, "S");

        doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
        doc.setFont("helvetica", "bold");
        doc.setFontSize(8.5);
        doc.text("PRIMARY FUNNEL RECOMMENDATION KEY:", 18, y + 5);

        doc.setFont("helvetica", "normal");
        doc.setFontSize(8);
        doc.setTextColor(100, 116, 139);
        const funnelFix = `Stage dropoffs reached highest values during intermediate checkout sections. Resolving forms bottlenecks could potentially recapture up to $${Math.round(metrics.revenue * 0.15).toLocaleString()} are currently leaking.`;
        const wrappedFunnelFix = doc.splitTextToSize(funnelFix, 172);
        doc.text(wrappedFunnelFix, 18, y + 10.5);

        decoratePageFooter(280);

        // ================= PAGE 3: CUSTOMER RETENTION LIFECYCLES =================
        doc.addPage();
        decoratePageHeader("Section C: Customer Retention & Lifecycles", 3);
        y = 44;

        doc.setFont("helvetica", "bold");
        doc.setFontSize(11);
        doc.setTextColor(15, 23, 42);
        doc.text("PRODUCT COHORT ANALYSIS & RETENTION REPORT", 15, y);
        y += 5.5;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(9);
        doc.setTextColor(71, 85, 105);
        const customerDesc = insights.customerJourneyInsights || "Cohort metrics profiling month-over-month loyalty, vip share indices and re-engagement campaigns efficacy.";
        const wrappedCustomerDesc = doc.splitTextToSize(customerDesc, 180);
        doc.text(wrappedCustomerDesc, 15, y);
        y += wrappedCustomerDesc.length * 4.5 + 8;

        // Cohort table headers
        const cHeaders = ["ACQUISITION MONTH", "RETENTION POOL", "MONTH 1", "MONTH 2", "MONTH 3", "MONTH 4", "MONTH 5"];
        const cColWidths = [32, 26, 21, 21, 21, 21, 21, 17];

        doc.setFillColor(15, 23, 42);
        doc.rect(15, y, 180, 8.5, "F");

        doc.setFont("helvetica", "bold");
        doc.setFontSize(8);
        doc.setTextColor(255, 255, 255);

        let curCX = 18;
        cHeaders.forEach((h, idx) => {
          doc.text(h, curCX, y + 5.8);
          curCX += cColWidths[idx];
        });
        y += 8.5;

        // Cohort rows
        metrics.cohortData.forEach((row, idx) => {
          if (idx % 2 === 1) {
            doc.setFillColor(248, 250, 252);
            doc.rect(15, y, 180, 8, "F");
          } else {
            doc.setDrawColor(241, 245, 249);
            doc.line(15, y + 8, 195, y + 8);
          }

          doc.setFont("helvetica", "normal");
          doc.setFontSize(8);
          doc.setTextColor(51, 65, 85);

          doc.text(row.cohort, 18, y + 5.5);
          doc.text(row.size.toLocaleString(), 18 + cColWidths[0], y + 5.5);
          
          doc.text(`${row.m1.toFixed(1)}%`, 18 + cColWidths[0] + cColWidths[1], y + 5.5);
          doc.text(`${row.m2.toFixed(1)}%`, 18 + cColWidths[0] + cColWidths[1] + cColWidths[2], y + 5.5);
          doc.text(`${row.m3.toFixed(1)}%`, 18 + cColWidths[0] + cColWidths[1] + cColWidths[2] + cColWidths[3], y + 5.5);
          doc.text(`${row.m4.toFixed(1)}%`, 18 + cColWidths[0] + cColWidths[1] + cColWidths[2] + cColWidths[3] + cColWidths[4], y + 5.5);
          doc.text(`${row.m5.toFixed(1)}%`, 18 + cColWidths[0] + cColWidths[1] + cColWidths[2] + cColWidths[3] + cColWidths[4] + cColWidths[5], y + 5.5);

          y += 8;
        });

        // Add highlight
        y += 12;
        doc.setFillColor(248, 250, 252);
        doc.rect(15, y, 180, 18, "F");
        doc.setDrawColor(226, 232, 240);
        doc.rect(15, y, 180, 18, "S");
        doc.setFillColor(99, 102, 241); // indigo badge
        doc.rect(15, y, 1.5, 18, "F");

        doc.setFont("helvetica", "bold");
        doc.setFontSize(8.5);
        doc.setTextColor(15, 23, 42);
        doc.text("LIFECYCLE RETENTIVITY SCORE:", 18, y + 5);

        doc.setFont("helvetica", "normal");
        doc.setFontSize(8);
        doc.setTextColor(71, 85, 105);
        doc.text(`Our general returning customer rate represents ${metrics.returningCustomerRate}% of incoming e-comm orders, indicating core catalog repeat loop effectiveness.`, 18, y + 11);

        decoratePageFooter(280);

        // ================= PAGE 4: MARKETING ACQUISITIONS =================
        doc.addPage();
        decoratePageHeader("Section D: Marketing Performance & ROI", 4);
        y = 44;

        doc.setFont("helvetica", "bold");
        doc.setFontSize(11);
        doc.setTextColor(15, 23, 42);
        doc.text("CHANNEL LEVEL REVENUE & RETURN-ON-AD-SPEND REPORT", 15, y);
        y += 5.5;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(9);
        doc.setTextColor(71, 85, 105);
        const marketingDesc = insights.marketingInsights || "Evaluating marketing channel allocation coefficients and comparative acquisition conversions.";
        const wrappedMarketingDesc = doc.splitTextToSize(marketingDesc, 180);
        doc.text(wrappedMarketingDesc, 15, y);
        y += wrappedMarketingDesc.length * 4.5 + 8;

        // Marketing table headers
        const mHeaders2 = ["ACQUISITION SOURCE", "VISITORS LOGGED", "ORDERS CONVERTED", "CONVERSION INDEX", "REVENUE ATTRIBUTED", "CHANNEL ROI"];
        const mColWidths2 = [42, 28, 28, 28, 30, 24];

        doc.setFillColor(15, 23, 42);
        doc.rect(15, y, 180, 8.5, "F");

        doc.setFont("helvetica", "bold");
        doc.setFontSize(8);
        doc.setTextColor(255, 255, 255);

        let curMX = 18;
        mHeaders2.forEach((h, idx) => {
          doc.text(h, curMX, y + 5.8);
          curMX += mColWidths2[idx];
        });
        y += 8.5;

        metrics.channelPerformance.forEach((row, idx) => {
          if (idx % 2 === 1) {
            doc.setFillColor(248, 250, 252);
            doc.rect(15, y, 180, 8, "F");
          } else {
            doc.setDrawColor(241, 245, 249);
            doc.line(15, y + 8, 195, y + 8);
          }

          doc.setFont("helvetica", "normal");
          doc.setFontSize(8);
          doc.setTextColor(51, 65, 85);

          doc.text(row.channel, 18, y + 5.5);
          doc.text(row.visitors.toLocaleString(), 18 + mColWidths2[0], y + 5.5);
          doc.text(row.orders.toLocaleString(), 18 + mColWidths2[0] + mColWidths2[1], y + 5.5);
          doc.text(`${row.conversion.toFixed(2)}%`, 18 + mColWidths2[0] + mColWidths2[1] + mColWidths2[2], y + 5.5);
          doc.text(`$${row.revenue.toLocaleString()}`, 18 + mColWidths2[0] + mColWidths2[1] + mColWidths2[2] + mColWidths2[3], y + 5.5);
          
          doc.setFont("helvetica", "bold");
          doc.setTextColor(row.roi > 3.0 ? 34 : 51, row.roi > 3.0 ? 197 : 65, row.roi > 3.0 ? 94 : 85);
          doc.text(`${row.roi.toFixed(1)}x`, 18 + mColWidths2[0] + mColWidths2[1] + mColWidths2[2] + mColWidths2[3] + mColWidths2[4], y + 5.5);
          doc.setFont("helvetica", "normal");
          doc.setTextColor(51, 65, 85);

          y += 8;
        });

        decoratePageFooter(280);

        // ================= PAGE 5: CATALOG PERFORMANCE & RECS =================
        doc.addPage();
        decoratePageHeader("Section E: Product Analytics & Core Growth Strategy", 5);
        y = 44;

        doc.setFont("helvetica", "bold");
        doc.setFontSize(11);
        doc.setTextColor(15, 23, 42);
        doc.text("ITEM LEVEL VIEW-TO-PURCHASE DIAGNOSTICS & THRESHOLDS", 15, y);
        y += 5.5;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(9);
        doc.setTextColor(71, 85, 105);
        const productDesc = insights.productInsights || "Catalog level detailed funnel metrics highlighting high conversion outliers and low performant display details.";
        const wrappedProductDesc = doc.splitTextToSize(productDesc, 180);
        doc.text(wrappedProductDesc, 15, y);
        y += wrappedProductDesc.length * 4.5 + 8;

        // Product table headers
        const pHeaders = ["CATALOG ITEM TITLE", "PAGE VIEWS", "CART INSERTS", "COMPLETED", "REVENUE ($)", "CONV INDEX %"];
        const pColWidths = [45, 26, 26, 26, 31, 26];

        doc.setFillColor(15, 23, 42);
        doc.rect(15, y, 180, 8.5, "F");

        doc.setFont("helvetica", "bold");
        doc.setFontSize(8);
        doc.setTextColor(255, 255, 255);

        let curPX = 18;
        pHeaders.forEach((h, idx) => {
          doc.text(h, curPX, y + 5.8);
          curPX += pColWidths[idx];
        });
        y += 8.5;

        metrics.productPerformance.forEach((row, idx) => {
          if (idx % 2 === 1) {
            doc.setFillColor(248, 250, 252);
            doc.rect(15, y, 180, 8, "F");
          } else {
            doc.setDrawColor(241, 245, 249);
            doc.line(15, y + 8, 195, y + 8);
          }

          doc.setFont("helvetica", "normal");
          doc.setFontSize(8);
          doc.setTextColor(51, 65, 85);

          const truncateName = row.name.length > 25 ? row.name.slice(0, 24) + "..." : row.name;
          doc.text(truncateName, 18, y + 5.5);
          doc.text(row.views.toLocaleString(), 18 + pColWidths[0], y + 5.5);
          doc.text(row.cartInserts.toLocaleString(), 18 + pColWidths[0] + pColWidths[1], y + 5.5);
          doc.text(row.orders.toLocaleString(), 18 + pColWidths[0] + pColWidths[1] + pColWidths[2], y + 5.5);
          doc.text(`$${row.revenue.toLocaleString()}`, 18 + pColWidths[0] + pColWidths[1] + pColWidths[2] + pColWidths[3], y + 5.5);

          doc.setFont("helvetica", "bold");
          doc.setTextColor(row.conversion < 2.0 ? 220 : 51, row.conversion < 2.0 ? 38 : 65, row.conversion < 2.0 ? 38 : 85);
          doc.text(`${row.conversion.toFixed(2)}%`, 18 + pColWidths[0] + pColWidths[1] + pColWidths[2] + pColWidths[3] + pColWidths[4], y + 5.5);
          doc.setFont("helvetica", "normal");
          doc.setTextColor(51, 65, 85);

          y += 8;
        });

        // Strategic Actions List
        y += 10;
        doc.setFont("helvetica", "bold");
        doc.setFontSize(9.5);
        doc.setTextColor(15, 23, 42);
        doc.text("IMMEDIATE REQUISITION PRIORITIES REGISTER:", 15, y);
        y += 6;

        const actionRecs = insights.recommendations && insights.recommendations.length > 0
          ? insights.recommendations.slice(0, 2)
          : [
              { title: "Optimize Mobile Checkout Conversion Flow", description: "Incorporate simplified mobile-friendly auth and single-button express checkouts." },
              { title: "Product display conversion audit", description: "Audit high-view items displaying below average indices to resolve price presentation leaks." }
            ];

        actionRecs.forEach((r, idx) => {
          doc.setFont("helvetica", "bold");
          doc.setFontSize(8.5);
          doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
          doc.text(`[REQUISITION 0${idx + 1}]: ${r.title.toUpperCase()}`, 15, y);
          y += 4.5;

          doc.setFont("helvetica", "normal");
          doc.setFontSize(8);
          doc.setTextColor(71, 85, 105);
          const wrappedAction = doc.splitTextToSize(r.description, 180);
          doc.text(wrappedAction, 15, y);
          y += wrappedAction.length * 4.5 + 4.5;
        });

        decoratePageFooter(280);

        // ================= PAGE 6: INTERACTIVE QA DIALOGUE LOG =================
        doc.addPage();
        decoratePageHeader("Section F: Interactive QA & FAQs Log", 6);
        y = 44;

        doc.setFont("helvetica", "bold");
        doc.setFontSize(11);
        doc.setTextColor(15, 23, 42);
        doc.text("CUSTOMER QUERY INTERACTION RESOLUTIONS REGISTER", 15, y);
        y += 6.5;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(9);
        doc.setTextColor(71, 85, 105);
        doc.text("Chronological log of AI-guided natural language questions asked during active session analysis.", 15, y);
        y += 10;

        // Visual primary Accent Break line
        doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
        doc.rect(15, y, 180, 1.2, "F");
        y += 8;

        if (chatHistory && chatHistory.length > 0) {
          chatHistory.slice(0, 6).forEach((chat, cIdx) => {
            if (y > 240) {
              decoratePageFooter(280);
              doc.addPage();
              decoratePageHeader("Section F: Interactive QA & FAQs Log (Cont.)", 6);
              y = 44;
            }

            // Chat outer card
            doc.setFillColor(250, 250, 250);
            doc.setDrawColor(226, 232, 240);
            doc.rect(15, y, 180, 28, "F");
            doc.rect(15, y, 180, 28, "S");

            // Left focus color based on sender
            if (chat.sender === "user") {
              doc.setFillColor(99, 102, 241); // Indigo for user
            } else {
              doc.setFillColor(6, 182, 212); // Cyan for AI
            }
            doc.rect(15, y, 1.5, 28, "F");

            // Text titles
            doc.setFont("helvetica", "bold");
            doc.setFontSize(7.5);
            doc.setTextColor(100, 116, 139);
            doc.text(`${chat.sender === "user" ? "USER QUESTION" : "CONVERTIQ CO-PILOT RESPONSE"} • ${chat.time}`, 19, y + 4.8);

            // Chat content text
            doc.setFont("helvetica", "normal");
            doc.setFontSize(8.5);
            doc.setTextColor(30, 41, 59);

            const wrappedText = doc.splitTextToSize(chat.text, 172);
            doc.text(wrappedText, 19, y + 10.5);

            y += 31;
          });
        } else {
          doc.setFont("helvetica", "italic");
          doc.setFontSize(9.5);
          doc.setTextColor(148, 163, 184);
          doc.text("No dynamic customer query actions executed during the current session.", 15, y);
          y += 10;

          // Standard FAQ helper box
          y += 10;
          doc.setFillColor(248, 250, 252);
          doc.rect(15, y, 180, 50, "F");
          doc.setDrawColor(226, 232, 240);
          doc.rect(15, y, 180, 50, "S");

          doc.setFont("helvetica", "bold");
          doc.setFontSize(9.5);
          doc.setTextColor(15, 23, 42);
          doc.text("Sample Core Questions Solved by ConvertIQ AI Logic:", 20, y + 6);

          const sampleQuestions = [
            "Q: Which customer segment generates the maximum average cart abandonment?",
            "Q: What combined purchase affinities represent our main upselling opportunities?",
            "Q: How will the net revenue trend look like under standard 15% mobile optimizations?",
            "Q: Where are the main regional checkout hurdles causing cart drop-offs?"
          ];

          doc.setFont("helvetica", "normal");
          doc.setFontSize(8);
          doc.setTextColor(71, 85, 105);
          sampleQuestions.forEach((sample, sIdx) => {
            doc.text(sample, 20, y + 14 + (sIdx * 8));
          });
        }

        decoratePageFooter(280);

        // SAVE FILE
        doc.save(`ConvertIQ_Executive_Report_${new Date().toISOString().slice(0, 10)}.pdf`);
        setDownloadingFormat(null);
        showBanner(
          "PDF Performance Review Generated",
          `A 6-page comprehensive e-commerce intelligence dossier has been compiled successfully. Template: ${selectedTemplate.toUpperCase()}`
        );
      }, 1500);
    } catch (err: any) {
      console.error(err);
      setDownloadingFormat(null);
      showBanner("PDF Processing Failed", "Encountered a compile block during client document generation.", "warning");
    }
  };

  // 4. DYNAMIC MICROSOFT WORD DOCUMENT EXPORT FUNCTION (.doc)
  const downloadWordReport = () => {
    try {
      setDownloadingFormat("DOC");
      setTimeout(() => {
        const dateStr = new Date().toLocaleDateString("en-US", { dateStyle: "long" });
        const prefText = filters?.dateRange ? `Date Context: ${filters.dateRange.toUpperCase()}` : "D30 Summary";
        
        const htmlContent = `
          <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
          <head>
            <title>ConvertIQ Executive Business Report</title>
            <style>
              body { font-family: 'Arial', sans-serif; color: #1e293b; line-height: 1.5; padding: 20px; }
              h1 { color: #0f172a; border-bottom: 2px solid #06b6d4; padding-bottom: 5px; font-size: 24px; }
              h2 { color: #1e3a8a; margin-top: 20px; border-bottom: 1px solid #e2e8f0; padding-bottom: 3px; font-size: 18px; }
              h3 { color: #0284c7; font-size: 14px; margin-top: 15px; }
              table { width: 100%; border-collapse: collapse; margin: 15px 0; }
              th { background-color: #0f172a; color: #ffffff; padding: 8px; text-align: left; font-size: 11px; }
              td { padding: 8px; border: 1px solid #cbd5e1; font-size: 10px; }
              tr:nth-child(even) { background-color: #f8fafc; }
              .kpi-container { padding: 12px; background-color: #f1f5f9; border-left: 4px solid #06b6d4; margin-bottom: 15px; }
              .recommendation-card { margin-top: 10px; padding: 10px; border: 1px solid #e2e8f0; border-radius: 6px; background-color: #fafafa; }
              .dialogue-item { margin-top: 8px; padding: 8px; border-radius: 6px; background-color: #f8fafc; border-left: 3px solid #6366f1; }
            </style>
          </head>
          <body>
            <h1>ConvertIQ Executive Business Report Dossier</h1>
            <p><strong>Generated on:</strong> ${dateStr} | <strong>Analytics Scope:</strong> ${prefText}</p>
            
            <h2>1. EXECUTIVE FINANCIALS & CONVERSION STATS</h2>
            <div class="kpi-container">
              <p>🟢 <strong>Total Revenue:</strong> $${metrics.revenue.toLocaleString()}</p>
              <p>📦 <strong>Total Completed Orders:</strong> ${metrics.orders.toLocaleString()}</p>
              <p>📈 <strong>Average Order Value (AOV):</strong> $${metrics.aov.toFixed(2)}</p>
              <p>🎯 <strong>Checkout Conversion Rate:</strong> ${metrics.conversionRate}%</p>
              <p>⚠️ <strong>Shopping Cart Abandonment:</strong> ${metrics.cartAbandonment}%</p>
              <p>👥 <strong>Returning Loyalty Rate:</strong> ${metrics.returningCustomerRate}%</p>
            </div>
            <p><strong>AI Executive Summary Insight:</strong> ${insights.executiveSummary}</p>
            
            <h2>2. DATABASE METRICS & EXPLORATORY DATA ANALYSIS (EDA)</h2>
            <h3>Geographic Regions Operational Share</h3>
            <table>
              <thead>
                <tr>
                  <th>Region Domain</th>
                  <th>Orders Logged</th>
                  <th>Attributed Sales ($)</th>
                  <th>Conversion Index</th>
                </tr>
              </thead>
              <tbody>
                ${metrics.regionPerformance.map(r => `
                  <tr>
                    <td><strong>${r.region}</strong></td>
                    <td>${r.orders.toLocaleString()}</td>
                    <td>$${r.revenue.toLocaleString()}</td>
                    <td>${r.conversion}%</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>

            <h3>Hardware Access Device Types Distributions</h3>
            <table>
              <thead>
                <tr>
                  <th>Device Category</th>
                  <th>Active Visitors</th>
                  <th>Orders Logged</th>
                  <th>Attributed Sales ($)</th>
                  <th>Conversion Index</th>
                </tr>
              </thead>
              <tbody>
                ${metrics.devicePerformance.map(d => `
                  <tr>
                    <td><strong>${d.device}</strong></td>
                    <td>${d.visitors.toLocaleString()}</td>
                    <td>${d.orders.toLocaleString()}</td>
                    <td>$${d.revenue.toLocaleString()}</td>
                    <td>${d.conversion}%</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>

            <h2>3. CHECKOUT STAGES DROPOFF FUNNEL</h2>
            <p><strong>Funnel Insight:</strong> ${insights.conversionInsights}</p>
            <table>
              <thead>
                <tr>
                  <th>Funnel Stage</th>
                  <th>Active Sessions</th>
                  <th>Progression Rate (%)</th>
                  <th>Dropoff Rate (%)</th>
                  <th>Estimated Revenue Leakage ($)</th>
                </tr>
              </thead>
              <tbody>
                ${metrics.funnelData.map(f => `
                  <tr>
                    <td><strong>${f.stage}</strong></td>
                    <td>${f.value.toLocaleString()}</td>
                    <td>${f.percentage}%</td>
                    <td>${f.dropoff}%</td>
                    <td>$${(f.revenueLeakage || Math.round(metrics.revenue * (f.dropoff / 100))).toLocaleString()}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>

            <h2>4. CUSTOMER JOURNEY COHORTS</h2>
            <p><strong>Retention Insight:</strong> ${insights.customerJourneyInsights}</p>
            <table>
              <thead>
                <tr>
                  <th>Cohort Group</th>
                  <th>Beginning Pool</th>
                  <th>Month 1</th>
                  <th>Month 2</th>
                  <th>Month 3</th>
                  <th>Month 4</th>
                  <th>Month 5</th>
                </tr>
              </thead>
              <tbody>
                ${metrics.cohortData.map(c => `
                  <tr>
                    <td><strong>${c.cohort}</strong></td>
                    <td>${c.size.toLocaleString()}</td>
                    <td>${c.m1}%</td>
                    <td>${c.m2}%</td>
                    <td>${c.m3}%</td>
                    <td>${c.m4}%</td>
                    <td>${c.m5}%</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>

            <h2>5. MARKETING CHANNEL ACQUISITIONS & ROI</h2>
            <p><strong>Marketing Channel Insight:</strong> ${insights.marketingInsights}</p>
            <table>
              <thead>
                <tr>
                  <th>Channel Source</th>
                  <th>Visitor Traffic</th>
                  <th>Orders Converted</th>
                  <th>Conversion Index (%)</th>
                  <th>Attributed Sales ($)</th>
                  <th>Estimated ROI Ratio</th>
                </tr>
              </thead>
              <tbody>
                ${metrics.channelPerformance.map(m => `
                  <tr>
                    <td><strong>${m.channel}</strong></td>
                    <td>${m.visitors.toLocaleString()}</td>
                    <td>${m.orders.toLocaleString()}</td>
                    <td>${m.conversion}%</td>
                    <td>$${m.revenue.toLocaleString()}</td>
                    <td><strong>${m.roi}x</strong></td>
                  </tr>
                `).join('')}
              </tbody>
            </table>

            <h2>6. ITEMS CATALOG CONVERSION AUDIT</h2>
            <p><strong>Catalog Insight:</strong> ${insights.productInsights}</p>
            <table>
              <thead>
                <tr>
                  <th>Catalog Listing</th>
                  <th>Views Visits</th>
                  <th>Cart Inserts</th>
                  <th>Checkouts</th>
                  <th>Direct Sales ($)</th>
                  <th>Conversion Rate (%)</th>
                </tr>
              </thead>
              <tbody>
                ${metrics.productPerformance.map(p => `
                  <tr>
                    <td><strong>${p.name}</strong></td>
                    <td>${p.views.toLocaleString()}</td>
                    <td>${p.cartInserts.toLocaleString()}</td>
                    <td>${p.orders.toLocaleString()}</td>
                    <td>$${p.revenue.toLocaleString()}</td>
                    <td>${p.conversion}%</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>

            <h2>7. ACTIONABLE RESOLUTIONS REGISTER</h2>
            ${insights.recommendations.map(r => `
              <div class="recommendation-card">
                <p><strong>[${r.priority.toUpperCase()} PRIORITY] ${r.title}</strong> - Impact: <strong>${r.impact}</strong></p>
                <p style="font-size: 11px; color: #475569; margin: 4px 0 0 0;">${r.description}</p>
              </div>
            `).join('')}

            <h2>8. SESSION INTERACTIVE CLIENT Q&A DIALOGUE LOG</h2>
            ${chatHistory && chatHistory.length > 0 ? chatHistory.map(h => `
              <div class="dialogue-item" style="border-left-color: ${h.sender === 'user' ? '#6366f1' : '#06b6d4'};">
                <p style="font-size: 10px; font-weight: bold; color: #475569; margin: 0 0 4px 0;">[${h.sender.toUpperCase()}] at ${h.time}</p>
                <p style="margin: 0; font-size: 11px;">${h.text}</p>
              </div>
            `).join('') : '<p>No customer query prompts logged during this session.</p>'}
            
            <hr />
            <p style="font-size: 10px; color: #94a3b8; text-align: center;">ConvertIQ Business Intelligence System - Confidential Operational Document</p>
          </body>
          </html>
        `;

        const blob = new Blob(['\ufeff' + htmlContent], { type: "application/msword" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `ConvertIQ_Executive_Report_${new Date().toISOString().slice(0, 10)}.doc`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        setDownloadingFormat(null);
        showBanner(
          "Word Report Compiled",
          "Comprehensive client-ready Microsoft Word summary dossier generated successfully."
        );
      }, 1000);
    } catch (err) {
      setDownloadingFormat(null);
      showBanner("Compilation Failed", "Word document generation encountered an encoding error.", "warning");
    }
  };

  // 5. TECHNICAL DEV WORKFLOW SYSTEM ARCHITECTURE DOCUMENTATION PDF EXPORT
  const downloadTechnicalBlueprintPDF = () => {
    try {
      setDownloadingFormat("BLUEPRINT-PDF");
      setTimeout(() => {
        const doc = new jsPDF();
        
        const decorateBlueprintPage = (title: string, pageNum: number) => {
          // Top branding ribbon header
          doc.setFillColor(15, 23, 42); // deep slate-900
          doc.rect(0, 0, 210, 15, "F");
          doc.setFillColor(6, 182, 212); // cyan-500 line
          doc.rect(0, 15, 210, 1.5, "F");
          
          doc.setFont("helvetica", "bold");
          doc.setFontSize(8.5);
          doc.setTextColor(255, 255, 255);
          doc.text("CONVERTIQ ENGINE SYSTEM ARCHITECTURE & MATHEMATICAL BLUEPRINT DIRECTORY", 12, 10);
          
          doc.setFont("helvetica", "bold");
          doc.setFontSize(8);
          doc.setTextColor(200, 200, 200);
          doc.text(`PAGE ${pageNum} OF 4`, 180, 10);
          
          // Bottom elegant border footer
          doc.setFillColor(248, 250, 252);
          doc.rect(0, 282, 210, 15, "F");
          doc.setDrawColor(226, 232, 240);
          doc.line(0, 282, 210, 282);
          
          doc.setFont("helvetica", "normal");
          doc.setFontSize(7.5);
          doc.setTextColor(148, 163, 184);
          doc.text("CONVERTIQ INTEL SYSTEMS • SYSTEM SPECIFICATION PROTOCOL REGISTER • STRICT DEVS ONLY", 12, 290);
        };

        // --- PAGE 1: INTRODUCTION & LAYPERSON DILEMMA PROBLEM ---
        decorateBlueprintPage("1. System Vision & Problem Statement", 1);
        let y = 35;
        
        doc.setFont("helvetica", "bold");
        doc.setFontSize(16);
        doc.setTextColor(15, 23, 42);
        doc.text("CONVERTIQ MASTER TECHNICAL SPECIFICATION", 12, y);
        y += 8;

        doc.setFont("helvetica", "bold");
        doc.setFontSize(9);
        doc.setTextColor(6, 182, 212);
        doc.text("THE COMPREHENSIVE INTELLIGENT CUSTOMER LIFECYCLE Spreadsheets AUDITOR", 12, y);
        y += 12;

        doc.setFont("helvetica", "bold");
        doc.setFontSize(11);
        doc.setTextColor(15, 23, 42);
        doc.text("1. THE EXECUTIVE PROBLEM STATEMENT", 12, y);
        y += 6;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(9);
        doc.setTextColor(71, 85, 105);
        const p1_p1 = "E-Commerce entrepreneurs are overwhelmed by massive raw traffic event tables yet starved of structured insights. Standard platforms (like Mixpanel) create code bottlenecks, demanding tracking installations, tedious configurations, and custom database queries. Merchant database spreadsheets exported from Shopify, Stripe, WooCommerce, or WooCommerce contain divergent schemas, invalid values, and inconsistent columns. Calculating and visualizing crucial insights—like checkout funnel drop-off leakages (in terms of dollar impact), recurring retention loyalty matrices, or Apriori basket association rules—forces non-technical merchants to write fragile spreadsheet code macros. In contrast, ConvertIQ provides a layperson fuzzy schema matching engine, a direct visual excel grid controller, and an interactive optimization tuner backed by the Gemini LLM to make direct sense of any dataset.";
        const wrappedP1_p1 = doc.splitTextToSize(p1_p1, 185);
        doc.text(wrappedP1_p1, 12, y);
        y += (wrappedP1_p1.length * 4.4) + 10;

        doc.setFont("helvetica", "bold");
        doc.setFontSize(11);
        doc.setTextColor(15, 23, 42);
        doc.text("2. INTEGRATED FRONTEND & BACKEND REPOSITORY PACKAGE DIRECTORY", 12, y);
        y += 6;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(8.5);
        doc.setTextColor(51, 65, 85);
        const stackList = [
          "• Main User Core Interface: React 19 + TypeScript, designed using functional hook-driven components.",
          "• Dynamic Document Exporter: jsPDF (v4.2.1) converting calculations directly into stakeholder-ready packages.",
          "• Workbook Compiler: XLSX (SheetJS) generating formatted spreadsheets with separated analytical pages.",
          "• Token Ingest parser: PapaParse (v5.5.3) providing layperson comma-separated mapping values.",
          "• Visual Charting coordinates: Recharts (v3.8.1) representing funnel progress bars, line trends, and device shares.",
          "• Server Pipeline: Node.js + Express (v4.21.2) hosting API gateways.",
          "• Core AI Cognition: Google Gemini SDK serving contextually grounded models based on client target loss input.",
          "• Responsive layout grid system: Tailwind CSS v4 paired with custom mobile-conscious dimensions.",
          "• Micro-Animations: Motion driving active dashboard tab cross-fades and transitions.",
          "• Graphics toolkit: Lucide React supplying standard vector vectors."
        ];
        stackList.forEach(line => {
          doc.text(line, 15, y);
          y += 5.5;
        });

        // --- PAGE 2: ANALYTICAL MATHEMATICS ---
        doc.addPage();
        decorateBlueprintPage("2. Core Mathematical Architecture", 2);
        y = 35;

        doc.setFont("helvetica", "bold");
        doc.setFontSize(13);
        doc.setTextColor(15, 23, 42);
        doc.text("3. CORE TECHNICAL EQUATIONS & SYSTEM ALGORITHMS", 12, y);
        y += 8;

        const mathItems = [
          { name: "Total Store Net Revenue ($)", formula: "Revenue = Sum of row values where Event = 'purchase'", desc: "Calculated client-side inside /src/services/metricsEngine.ts as an aggregated transaction sum." },
          { name: "Checkout Conversion Rate (CR)", formula: "CR (%) = (Count of Unique Purchase Sessions / All Unique Sessions) * 100", desc: "Computes active sessions rather than row counts to prevent inflation from multi-click events." },
          { name: "Average Order Value (AOV)", formula: "AOV = Total Net Sales Revenue / Total Completed Purchases count", desc: "Examines financial averages to model standard customer lifecycle capacities." },
          { name: "Shopping Cart Abandonment Rate", formula: "Abandonment (%) = (1 - (Sessions with Cart AND Purchase) / Sessions with Cart) * 100", desc: "Tracks leakage quotients, pointing out checkouts initiated but left unresolved." },
          { name: "Loyalty Return Customer Rate (%)", formula: "Loyalty (%) = (Unique Customers with > 1 Purchase / Unique Customers with >= 1)", desc: "Examines customer loyalty indexes based on unique client identity keys." }
        ];

        mathItems.forEach(item => {
          doc.setFont("helvetica", "bold");
          doc.setFontSize(9.5);
          doc.setTextColor(99, 102, 241);
          doc.text(`• ${item.name}`, 12, y);
          y += 4.5;
          
          doc.setFont("helvetica", "bold");
          doc.setFontSize(8.5);
          doc.setTextColor(15, 23, 42);
          doc.text(`  Formula: ${item.formula}`, 12, y);
          y += 4;

          doc.setFont("helvetica", "normal");
          doc.setFontSize(8.5);
          doc.setTextColor(100, 116, 139);
          const wrappedMDesc = doc.splitTextToSize(`Description: ${item.desc}`, 180);
          doc.text(wrappedMDesc, 12, y);
          y += (wrappedMDesc.length * 4) + 5;
        });

        // --- PAGE 3: COMPONENT LAYOUT ---
        doc.addPage();
        decorateBlueprintPage("3. Component Map & Architecture", 3);
        y = 35;

        doc.setFont("helvetica", "bold");
        doc.setFontSize(13);
        doc.setTextColor(15, 23, 42);
        doc.text("4. APP LEVEL FILE LAYOUTS & COMPONENT TEARDOWN", 12, y);
        y += 8;

        const compList = [
          { name: "App.tsx", desc: "The main state hub. Manages global filtering, date slices, and tab changes, passing datasets downward." },
          { name: "AboutPage.tsx", desc: "The upload zone. Houses fuzzy mapping columns, the user target preference selectors, and displays CSV head and tail tabular records." },
          { name: "DashboardHome.tsx", desc: "Visualizes sales indicators, line trend charts, and customized metric card blocks." },
          { name: "EDAHub.tsx", desc: "Groups bento-grid modules: Geographic distribution maps, device conversion percentages, marketing channel ROIs, and cohort loyalty grids." },
          { name: "CustomAnalysisPanel.tsx", desc: "Runs direct math engines: Apriori Association basket affinities, RFM customer matrix segmentation, and linear forecasts." },
          { name: "AIInsightsPanel.tsx", desc: "Floating chatbot sidebar. Queries the active database state, tracking user questions and logging session registry histories." },
          { name: "ReportsCenter.tsx", desc: "Compiles all calculations, Custom Q&As, and layouts into Executive PDF templates, multi-sheet Excel pages, and Word reports." }
        ];

        compList.forEach(comp => {
          doc.setFont("helvetica", "bold");
          doc.setFontSize(9.5);
          doc.setTextColor(6, 182, 212);
          doc.text(`📦 File: /src/components/${comp.name}`, 12, y);
          y += 4.5;

          doc.setFont("helvetica", "normal");
          doc.setFontSize(8.5);
          doc.setTextColor(51, 65, 85);
          const wrappedCompDesc = doc.splitTextToSize(comp.desc, 180);
          doc.text(wrappedCompDesc, 15, y);
          y += (wrappedCompDesc.length * 4) + 6;
        });

        // --- PAGE 4: PYTHON AUDIT SPECIFICATION ---
        doc.addPage();
        decorateBlueprintPage("4. Mathematical Python Validation Suite", 4);
        y = 35;

        doc.setFont("helvetica", "bold");
        doc.setFontSize(13);
        doc.setTextColor(15, 23, 42);
        doc.text("5. REAL-WORLD DATA VALIDATION VIA PYTHON PROGRAMMING", 12, y);
        y += 6;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(9);
        doc.setTextColor(71, 85, 105);
        const pyDesc = "Validate numerical indices or custom formulas on local hardware using the official Python code suite shown below. It utilizes the standard Pandas data manipulation libraries to confirm mathematical alignments across raw store transaction sheets down to the exact decimal point:";
        const wrappedPyDesc = doc.splitTextToSize(pyDesc, 185);
        doc.text(wrappedPyDesc, 12, y);
        y += (wrappedPyDesc.length * 4) + 6;

        // Draw python code lines
        const pyCodeLines = [
          "import pandas as pd",
          "import numpy as np",
          "",
          "# 1. Ingest Excel/CSV records",
          "df = pd.read_csv('uploaded_store_logs.csv')",
          "purchases = df[df['event_type'].str.strip().lower() == 'purchase']",
          "",
          "# 2. Compute Core Mathematics Formulas",
          "total_revenue = purchases['revenue'].sum()",
          "total_orders = len(purchases)",
          "aov = total_revenue / total_orders if total_orders > 0 else 0",
          "all_unique_sessions = df['session_id'].nunique()",
          "purchase_sessions = purchases['session_id'].nunique()",
          "conversion_rate = (purchase_sessions / all_unique_sessions) * 100",
          "",
          "# 3. Print verification audit metrics",
          "print(f'Total Revenue: ${total_revenue:,.2f}')",
          "print(f'Average Order Value (AOV): ${aov:.2f}')",
          "print(f'Store Checkout Conversion: {conversion_rate:.2f}%')"
        ];

        doc.setFillColor(30, 41, 59);
        doc.rect(12, y, 185, 95, "F");
        
        doc.setFont("courier", "bold");
        doc.setFontSize(7.5);
        doc.setTextColor(226, 232, 240);
        
        let codeY = y + 7;
        pyCodeLines.forEach(line => {
          doc.text(line, 16, codeY);
          codeY += 4.8;
        });

        doc.save(`ConvertIQ_Technical_System_Blueprint.pdf`);
        setDownloadingFormat(null);
        showBanner(
          "Technical Blueprint Downloaded",
          "A comprehensive 4-page developer blueprint and physical Python verification handbook generated successfully."
        );
      }, 1000);
    } catch (err: any) {
      console.error(err);
      setDownloadingFormat(null);
      showBanner("Technical Export Blocked", "PDF blueprint compilation encountered a fatal encoding error.", "warning");
    }
  };

  return (
    <div id="reports-center-root" className="space-y-6">
      
      {/* Page Title & Quick Download Triggers */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 bg-white dark:bg-zinc-900/50 p-6 rounded-2xl border border-gray-100 dark:border-zinc-800">
        <div>
          <span className="text-[10px] uppercase font-black text-xs tracking-wider text-cyan-600 dark:text-cyan-400 bg-cyan-500/10 px-2.5 py-1 rounded-full font-mono">
            Reporting Suite v2.2
          </span>
          <h2 className="text-xl font-extrabold text-gray-900 dark:text-white mt-2.5">
            ConvertIQ Corporate Report Center
          </h2>
          <p className="text-xs text-gray-500 dark:text-zinc-400 mt-1">
            Produce, review and download stakeholder-ready, dynamic summaries styled in corporate e-commerce report templates.
          </p>
        </div>

        {/* Global format export trigger buttons */}
        <div className="flex flex-wrap gap-2.5 pt-2 lg:pt-0">
          
          <button
            id="export-technical-blueprint-btn"
            onClick={downloadTechnicalBlueprintPDF}
            disabled={downloadingFormat !== null}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-indigo-200 dark:border-indigo-950/45 bg-indigo-50/45 dark:bg-indigo-950/15 text-indigo-700 dark:text-indigo-400 text-xs font-bold hover:bg-indigo-100 dark:hover:bg-indigo-950/25 transition-all outline-none disabled:opacity-40 cursor-pointer shadow-sm active:scale-95"
            title="Download the full A-Z Developer Blueprint and Verification Document as a formatted PDF"
          >
            <FileCode className="h-4 w-4 text-indigo-500" />
            <span>DOWNLOAD BLUEPRINT PDF</span>
          </button>

          <button
            id="export-pdf-indigo-btn"
            onClick={downloadPDFReport}
            disabled={downloadingFormat !== null}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-rose-200 dark:border-rose-950/30 bg-rose-50/45 dark:bg-rose-950/15 text-rose-700 dark:text-rose-400 text-xs font-bold hover:bg-rose-100 dark:hover:bg-rose-950/25 transition-all outline-none disabled:opacity-40 cursor-pointer shadow-sm active:scale-95"
            title="Download formatted multipage PDF analytics packet"
          >
            <Download className="h-4 w-4 text-rose-500" />
            <span>DOWNLOAD PDF REPORT</span>
          </button>

          <button
            id="export-doc-word-btn"
            onClick={downloadWordReport}
            disabled={downloadingFormat !== null}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-blue-200 dark:border-blue-950/30 bg-blue-50/45 dark:bg-blue-950/15 text-blue-700 dark:text-blue-400 text-xs font-bold hover:bg-blue-100 dark:hover:bg-blue-950/25 transition-all outline-none disabled:opacity-40 cursor-pointer shadow-sm active:scale-95"
            title="Download formatted Word reports document"
          >
            <Download className="h-4 w-4 text-blue-500" />
            <span>DOWNLOAD WORD (.DOC)</span>
          </button>

          <button
            id="export-xlsx-workbook-btn"
            onClick={downloadExcelReport}
            disabled={downloadingFormat !== null}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-emerald-200 dark:border-emerald-950/45 bg-emerald-50/45 dark:bg-emerald-950/15 text-emerald-700 dark:text-emerald-400 text-xs font-bold hover:bg-emerald-100 dark:hover:bg-emerald-950/25 transition-all outline-none disabled:opacity-40 cursor-pointer shadow-sm active:scale-95"
            title="Export full multisheet excel workbook"
          >
            <FileSpreadsheet className="h-4 w-4 text-emerald-500" />
            <span>EXPORT EXCEL WORKBOOK</span>
          </button>

          <button
            id="export-csv-direct-btn"
            onClick={() => downloadCSVExport("active-view")}
            disabled={downloadingFormat !== null}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-indigo-200 dark:border-indigo-950/45 bg-indigo-50/45 dark:bg-indigo-950/15 text-indigo-700 dark:text-indigo-400 text-xs font-bold hover:bg-indigo-100 dark:hover:bg-indigo-950/25 transition-all outline-none disabled:opacity-40 cursor-pointer shadow-sm active:scale-95"
            title="Download active segment data records"
          >
            <FileCode className="h-4 w-4 text-indigo-500" />
            <span>ACTIVE VIEW CSV</span>
          </button>

        </div>
      </div>

      {/* TEMPLATE SCHEME SELECTOR & DATASET STATS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Template styling selector */}
        <div className="p-4 bg-white dark:bg-zinc-900/50 rounded-2xl border border-gray-100 dark:border-zinc-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-slate-100 dark:bg-zinc-800 rounded-lg">
              <Palette className="h-4 w-4 text-cyan-600 dark:text-cyan-400 animate-pulse" />
            </div>
            <div>
              <h4 className="text-xs font-extrabold text-gray-900 dark:text-white">Professional PDF Template</h4>
              <p className="text-[10px] text-gray-500 dark:text-zinc-400">Toggle design presets used during layout generation</p>
            </div>
          </div>

          <div className="flex gap-1.5 bg-slate-50 dark:bg-zinc-950/50 p-1 rounded-xl border border-slate-100 dark:border-zinc-800">
            <button
              onClick={() => setSelectedTemplate("cyan")}
              className={`px-3 py-1 text-[10px] font-black rounded-lg transition-all ${
                selectedTemplate === "cyan"
                  ? "bg-cyan-500 text-white shadow-sm"
                  : "text-gray-500 dark:text-zinc-400 hover:bg-slate-100 dark:hover:bg-zinc-800"
              }`}
            >
              Cyan Modern
            </button>
            <button
              onClick={() => setSelectedTemplate("indigo")}
              className={`px-3 py-1 text-[10px] font-black rounded-lg transition-all ${
                selectedTemplate === "indigo"
                  ? "bg-indigo-500 text-white shadow-sm"
                  : "text-gray-500 dark:text-zinc-400 hover:bg-slate-100 dark:hover:bg-zinc-800"
              }`}
            >
              Classic Indigo
            </button>
            <button
              onClick={() => setSelectedTemplate("mono")}
              className={`px-3 py-1 text-[10px] font-black rounded-lg transition-all ${
                selectedTemplate === "mono"
                  ? "bg-zinc-700 text-white shadow-sm"
                  : "text-gray-500 dark:text-zinc-400 hover:bg-slate-100 dark:hover:bg-zinc-800"
              }`}
            >
              Slate Monochromatic
            </button>
          </div>
        </div>

        {/* Dataset source stats */}
        <div className="p-4 bg-white dark:bg-zinc-900/50 rounded-2xl border border-gray-100 dark:border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-slate-100 dark:bg-zinc-800 rounded-lg">
              <Calendar className="h-4 w-4 text-emerald-500" />
            </div>
            <div>
              <h4 className="text-xs font-extrabold text-gray-900 dark:text-white">Active Database Source</h4>
              <p className="text-[10px] text-gray-500 dark:text-zinc-400">
                {uploadedData && uploadedData.length > 0 
                  ? `Authenticated Upload: ${uploadedData.length.toLocaleString()} total transactional records`
                  : "Synthesized Store Engine Mode (Static fallback enabled)"}
              </p>
            </div>
          </div>

          {uploadedData && uploadedData.length > 0 && (
            <button
              onClick={() => downloadCSVExport("full-raw-logs")}
              className="flex items-center gap-1 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 p-2 py-1.5 rounded-xl text-[10px] font-black tracking-wide border border-emerald-500/20"
              title="Download the entire parsed database CSV file as uploaded"
            >
              <Download className="h-3 w-3" />
              <span>RAW LOGS ({uploadedData.length})</span>
            </button>
          )}
        </div>

      </div>

      {/* COMPILATION RUNNING INDICATOR */}
      {downloadingFormat && (
        <div className="p-4 rounded-xl bg-gray-50 dark:bg-zinc-900 border border-gray-200 dark:border-zinc-805 flex items-center gap-3 text-xs animate-pulse">
          <div className="h-4 w-4 rounded-full border-2 border-cyan-500/20 border-t-cyan-500 animate-spin" />
          <span className="text-gray-600 dark:text-zinc-300 font-medium">
            Transforming calculations... Packaging dynamic {downloadingFormat} report data structure matching enterprise styling rules...
          </span>
        </div>
      )}

      {/* NOTIFICATION TOAST OVERLAYS */}
      {notification && (
        <div className={`p-4 rounded-xl border flex gap-3 text-xs font-sans animate-fadeIn transition-all duration-300 ${
          notification.type === "success" 
            ? "bg-slate-900 text-white border-zinc-800 shadow-xl"
            : "bg-amber-50 border-amber-200 text-amber-900"
        }`}>
          {notification.type === "success" ? (
            <CheckCircle className="h-5 w-5 text-emerald-400 mt-0.5 shrink-0" />
          ) : (
            <AlertCircle className="h-5 w-5 text-amber-500 mt-0.5 shrink-0" />
          )}
          <div>
            <strong className="font-extrabold text-xs">{notification.title}</strong>
            <p className="text-[10px] mt-0.5 text-gray-300 dark:text-zinc-400">{notification.desc}</p>
          </div>
        </div>
      )}

      {/* DETAILED SECTION PORTAL EXPLORER (PAGE INTEGRATED PREVIEWS) */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Active view selectors rail */}
        <div className="lg:col-span-1 space-y-2.5">
          <div className="bg-white dark:bg-zinc-900/50 p-4 rounded-2xl border border-gray-100 dark:border-zinc-800 space-y-3">
            <h3 className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase tracking-wider font-mono">
              Report Section Previews
            </h3>
            
            <div className="flex flex-col gap-1.5">
              <button
                onClick={() => setActiveSection("master-dossier")}
                className={`p-3 rounded-xl text-left text-xs font-bold transition-all flex items-center gap-2.5 ${
                  activeSection === "master-dossier"
                    ? "bg-gradient-to-r from-cyan-500/15 to-indigo-500/15 border border-cyan-500/30 text-cyan-600 dark:text-cyan-400"
                    : "hover:bg-slate-50 dark:hover:bg-zinc-900 border border-transparent text-gray-700 dark:text-zinc-300"
                }`}
              >
                <Award className="h-4 w-4 shrink-0 text-cyan-500 animate-pulse" />
                <span className="truncate">⭐ Corporate Master Dossier (A-Z)</span>
              </button>

              <button
                onClick={() => setActiveSection("summary")}
                className={`p-3 rounded-xl text-left text-xs font-bold transition-all flex items-center gap-2.5 ${
                  activeSection === "summary"
                    ? "bg-cyan-500/10 border border-cyan-500/30 text-cyan-600 dark:text-cyan-400"
                    : "hover:bg-slate-50 dark:hover:bg-zinc-900 border border-transparent text-gray-700 dark:text-zinc-300"
                }`}
              >
                <TrendingUp className="h-4 w-4 shrink-0 text-cyan-500" />
                <span className="truncate">Executive KPI Audit</span>
              </button>

              <button
                onClick={() => setActiveSection("funnel")}
                className={`p-3 rounded-xl text-left text-xs font-bold transition-all flex items-center gap-2.5 ${
                  activeSection === "funnel"
                    ? "bg-cyan-500/10 border border-cyan-500/30 text-cyan-600 dark:text-cyan-400"
                    : "hover:bg-slate-50 dark:hover:bg-zinc-900 border border-transparent text-gray-700 dark:text-zinc-300"
                }`}
              >
                <LineChart className="h-4 w-4 shrink-0 text-cyan-500" />
                <span className="truncate">Funnel Telemetry Analysis</span>
              </button>

              <button
                onClick={() => setActiveSection("customer")}
                className={`p-3 rounded-xl text-left text-xs font-bold transition-all flex items-center gap-2.5 ${
                  activeSection === "customer"
                    ? "bg-cyan-500/10 border border-cyan-500/30 text-cyan-600 dark:text-cyan-400"
                    : "hover:bg-slate-50 dark:hover:bg-zinc-900 border border-transparent text-gray-700 dark:text-zinc-300"
                }`}
              >
                <Users className="h-4 w-4 shrink-0 text-cyan-500" />
                <span className="truncate">Customer Cohorts Insights</span>
              </button>

              <button
                onClick={() => setActiveSection("marketing")}
                className={`p-3 rounded-xl text-left text-xs font-bold transition-all flex items-center gap-2.5 ${
                  activeSection === "marketing"
                    ? "bg-cyan-500/10 border border-cyan-500/30 text-cyan-600 dark:text-cyan-400"
                    : "hover:bg-slate-50 dark:hover:bg-zinc-900 border border-transparent text-gray-700 dark:text-zinc-300"
                }`}
              >
                <Award className="h-4 w-4 shrink-0 text-cyan-500" />
                <span className="truncate">Marketing Channels ROI</span>
              </button>

              <button
                onClick={() => setActiveSection("product")}
                className={`p-3 rounded-xl text-left text-xs font-bold transition-all flex items-center gap-2.5 ${
                  activeSection === "product"
                    ? "bg-cyan-500/10 border border-cyan-500/30 text-cyan-600 dark:text-cyan-400"
                    : "hover:bg-slate-50 dark:hover:bg-zinc-900 border border-transparent text-gray-700 dark:text-zinc-300"
                }`}
              >
                <ShoppingBag className="h-4 w-4 shrink-0 text-cyan-500" />
                <span className="truncate">Product Level Conversions</span>
              </button>
            </div>
          </div>

          {/* Quick download card info */}
          <div className="bg-slate-55 dark:bg-zinc-900/30 p-4 border border-gray-150 dark:border-zinc-800 rounded-2xl select-none">
            <h4 className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest font-mono">Dossier Assembly Information</h4>
            <p className="text-[10px] text-gray-500 dark:text-zinc-400 leading-normal mt-1.5">
              Exports assemble 6 fully independent analytical pages, compiling transactional records, customized prompts/calculations, and your active dialogue queries in one package.
            </p>
          </div>
        </div>

        {/* Dynamic section display viewport render */}
        {/* Dynamic section display viewport render */}
        <div className="lg:col-span-3 p-6 rounded-2xl border border-gray-100 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 space-y-6">
          
          {/* Corporate Master Dossier (A-Z) Live compilations */}
          {activeSection === "master-dossier" && (
            <div className="space-y-6 animate-fadeIn">
              
              {/* Header block with visual outline */}
              <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 border-b border-gray-150 dark:border-zinc-805 pb-4">
                <div>
                  <span className="text-[10px] font-black tracking-widest text-indigo-600 dark:text-indigo-400 bg-indigo-500/10 px-2.5 py-1 rounded-full font-mono uppercase">
                    Unified Executive Intelligence Dossier
                  </span>
                  <h3 className="text-base font-extrabold text-gray-950 dark:text-white mt-1.5">
                    Spreadsheet A-to-Z Complete Master Compilation
                  </h3>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={downloadPDFReport}
                    className="flex items-center gap-1.5 bg-gradient-to-r from-red-500 to-rose-600 text-white font-extrabold text-[10px] px-3.5 py-1.5 rounded-xl shadow cursor-pointer select-none hover:opacity-95"
                    title="Export formatted 6-page corporate PDF"
                  >
                    <Download className="h-3 w-3" />
                    <span>EXPORT 6-PAGE PDF</span>
                  </button>
                  <button
                    onClick={downloadWordReport}
                    className="flex items-center gap-1.5 bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-extrabold text-[10px] px-3.5 py-1.5 rounded-xl shadow cursor-pointer select-none hover:opacity-95"
                    title="Export formatted Word report summary"
                  >
                    <Download className="h-3 w-3" />
                    <span>EXPORT MS WORD</span>
                  </button>
                </div>
              </div>

              {/* High levels summary paragraph */}
              <div id="master-executive-abstract-card" className="p-4 bg-gradient-to-tr from-indigo-50/45 to-cyan-50/15 dark:from-zinc-900 dark:to-zinc-950/20 rounded-2xl border border-indigo-100/40 dark:border-zinc-800">
                <div className="flex gap-2.5 items-start">
                  <div className="h-9 w-9 bg-indigo-500/10 text-indigo-500 rounded-xl flex items-center justify-center shrink-0">
                    <Award className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-gray-900 dark:text-zinc-200">Corporate Dossier Abstract</h4>
                    <p className="text-xs text-gray-600 dark:text-zinc-400 mt-1 leading-relaxed">
                      {insights.executiveSummary}
                    </p>
                  </div>
                </div>
              </div>

              {/* Bento Grid Analytics Outline */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                
                {/* Outliner block */}
                <div className="sm:col-span-2 space-y-3 bg-slate-50/50 dark:bg-zinc-950/20 p-4 rounded-xl border border-slate-100 dark:border-zinc-805">
                  <h4 className="text-xs font-extrabold text-gray-900 dark:text-white flex items-center gap-2">
                    <FileSpreadsheet className="h-4 w-4 text-cyan-600 dark:text-cyan-400" />
                    <span>Report Structure & Compiled Sections Outline (A-Z)</span>
                  </h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px] pt-1">
                    <div className="flex items-center gap-2 text-gray-700 dark:text-zinc-350 p-1.5 bg-white dark:bg-zinc-900/60 rounded-lg border border-gray-100 dark:border-zinc-800">
                      <div className="h-5 w-5 rounded bg-cyan-500/15 text-cyan-600 text-center text-[10px] font-mono font-black flex items-center justify-center">A</div>
                      <span>Financial & Conversion Auditing KPIs</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-700 dark:text-zinc-350 p-1.5 bg-white dark:bg-zinc-900/60 rounded-lg border border-gray-100 dark:border-zinc-800">
                      <div className="h-5 w-5 rounded bg-cyan-500/15 text-cyan-600 text-center text-[10px] font-mono font-black flex items-center justify-center">B</div>
                      <span>EDA Traffic shares (Regions & Devices)</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-700 dark:text-zinc-350 p-1.5 bg-white dark:bg-zinc-900/60 rounded-lg border border-gray-100 dark:border-zinc-800">
                      <div className="h-5 w-5 rounded bg-cyan-500/15 text-cyan-600 text-center text-[10px] font-mono font-black flex items-center justify-center">C</div>
                      <span>Checkout Progression Funnel Telemetry</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-700 dark:text-zinc-355 p-1.5 bg-white dark:bg-zinc-900/60 rounded-lg border border-gray-100 dark:border-zinc-800">
                      <div className="h-5 w-5 rounded bg-cyan-500/15 text-cyan-600 text-center text-[10px] font-mono font-black flex items-center justify-center">D</div>
                      <span>VIP Cohorts Loyalty Retention Matrix</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-700 dark:text-zinc-355 p-1.5 bg-white dark:bg-zinc-900/60 rounded-lg border border-gray-100 dark:border-zinc-800">
                      <div className="h-5 w-5 rounded bg-cyan-500/15 text-cyan-600 text-center text-[10px] font-mono font-black flex items-center justify-center">E</div>
                      <span>Marketing Channels Acquisition shares & ROI</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-700 dark:text-zinc-355 p-1.5 bg-white dark:bg-zinc-900/60 rounded-lg border border-gray-100 dark:border-zinc-800">
                      <div className="h-5 w-5 rounded bg-cyan-500/15 text-cyan-600 text-center text-[10px] font-mono font-black flex items-center justify-center">F</div>
                      <span>Client Q&As Interaction Registry</span>
                    </div>
                  </div>
                </div>

                {/* Score / Status Card widgets */}
                <div className="bg-slate-55 dark:bg-zinc-950/20 p-4 rounded-xl border border-slate-100 dark:border-zinc-805 flex flex-col justify-between">
                  <div>
                    <h4 className="text-[10px] font-bold tracking-wider text-gray-400 dark:text-zinc-500 uppercase font-mono animate-pulse">Dossier Scoring Health</h4>
                    <p className="text-xl font-black mt-2 text-emerald-600 dark:text-emerald-400">96.8 / 100</p>
                    <p className="text-[10px] text-gray-500 dark:text-zinc-400 mt-1 leading-normal">
                      Based on conversion stability, VIP loyalty coefficients and data purity index.
                    </p>
                  </div>
                  <div className="border-t border-gray-200 dark:border-zinc-800 pt-2 mt-2 text-[10px] flex justify-between text-gray-400 font-mono">
                    <span>SECTIONS: 6</span>
                    <span>PAGES: 6</span>
                  </div>
                </div>

              </div>

              {/* SECTION F PREVIEW: Session Interactive Client Q&As dialogue logs */}
              <div className="p-4 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-850 rounded-xl space-y-4">
                
                <div className="flex justify-between items-center border-b border-gray-100 dark:border-zinc-800 pb-2.5">
                  <h4 className="text-xs font-black text-gray-900 dark:text-zinc-150 flex items-center gap-1.5">
                    <MessageSquare className="h-4.5 w-4.5 text-indigo-500" />
                    <span>Section F: Client Interactive Q&As Dialogue Log</span>
                  </h4>
                  <span className="text-[9px] uppercase font-mono px-2 py-0.5 rounded bg-indigo-500/5 border border-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-bold">
                    {chatHistory.length} Prompt Transactions logged
                  </span>
                </div>

                <p className="text-xs text-gray-500 dark:text-zinc-400 leading-relaxed">
                  The compiled corporate dossier automatically captures every business query, custom formula calculation, and natural language question you posed during your session for immediate executive presentation.
                </p>

                {chatHistory.length > 0 ? (
                  <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1.5 scrollbar-thin">
                    {chatHistory.map((chat, cIdx) => (
                      <div 
                        key={cIdx} 
                        className={`p-3 rounded-xl border flex flex-col gap-1 transition-all ${
                          chat.sender === "user" 
                            ? "bg-slate-50/65 dark:bg-zinc-950/20 border-l-[3px] border-l-indigo-500 border-gray-150 dark:border-zinc-800" 
                            : "bg-cyan-500/5 dark:bg-cyan-950/10 border-l-[3px] border-l-cyan-400 border-cyan-500/10 dark:border-zinc-850"
                        }`}
                      >
                        <div className="flex justify-between text-[9px] font-mono text-gray-400 dark:text-zinc-500 font-bold text-[8px]">
                          <span>{chat.sender === "user" ? "USER PROMPT" : "AI CO-PILOT RESPONSE"}</span>
                          <span>{chat.time}</span>
                        </div>
                        <p className="text-xs text-gray-800 dark:text-zinc-200 whitespace-pre-line leading-relaxed">
                          {chat.text}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-6 bg-slate-55 dark:bg-zinc-950/10 rounded-xl border border-dashed border-gray-200 dark:border-zinc-805 text-center space-y-2">
                    <HelpCircle className="h-6 w-6 text-indigo-400 mx-auto animate-bounce" />
                    <p className="text-xs text-gray-500 dark:text-zinc-400 font-bold">No custom client queries prompted yet during this session</p>
                    <p className="text-[10.5px] text-gray-400 dark:text-zinc-500 max-w-sm mx-auto leading-normal">
                      Any questions and answers processed while querying the <strong>AI Genius Optimizer</strong> or the floating <strong>Co-Pilot Sidebar</strong> are captured and appended to Section F automatically.
                    </p>
                  </div>
                )}
              </div>

              {/* Dynamic EDA distribution shares in Dossier preview */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Geographic shares preview */}
                <div className="p-4 bg-slate-50/50 dark:bg-zinc-950/20 rounded-xl border border-slate-100 dark:border-zinc-805 space-y-3">
                  <h4 className="text-xs font-black text-gray-900 dark:text-zinc-150 uppercase tracking-widest font-mono text-cyan-600 dark:text-cyan-400">
                    🌍 Region-wise Sales Performance
                  </h4>
                  <div className="overflow-x-auto text-[11px]">
                    <table className="w-full text-left font-sans">
                      <thead>
                        <tr className="text-gray-400 text-[10px] uppercase font-mono border-b border-gray-200 dark:border-zinc-800">
                          <th className="pb-1.5">Region</th>
                          <th className="pb-1.5 text-center">Orders</th>
                          <th className="pb-1.5 text-right">Revenue</th>
                          <th className="pb-1.5 text-right">Conv.</th>
                        </tr>
                      </thead>
                      <tbody>
                        {metrics.regionPerformance.map((r, rIdx) => (
                          <tr key={rIdx} className="border-b border-gray-100/50 dark:border-zinc-805/30 hover:bg-white dark:hover:bg-zinc-900/40">
                            <td className="py-1.5 font-bold">{r.region}</td>
                            <td className="py-1.5 text-center font-mono">{r.orders.toLocaleString()}</td>
                            <td className="py-1.5 text-right font-mono font-bold">${r.revenue.toLocaleString()}</td>
                            <td className="py-1.5 text-right font-mono text-cyan-600 dark:text-cyan-400">{r.conversion}%</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Hardware device shares preview */}
                <div className="p-4 bg-slate-50/50 dark:bg-zinc-950/20 rounded-xl border border-slate-100 dark:border-zinc-805 space-y-3">
                  <h4 className="text-xs font-black text-gray-900 dark:text-zinc-150 uppercase tracking-widest font-mono text-indigo-600 dark:text-indigo-400">
                    💻 Device acquisitions & traffic shares
                  </h4>
                  <div className="overflow-x-auto text-[11px]">
                    <table className="w-full text-left font-sans">
                      <thead>
                        <tr className="text-gray-400 text-[10px] uppercase font-mono border-b border-gray-200 dark:border-zinc-800">
                          <th className="pb-1.5">Device</th>
                          <th className="pb-1.5 text-center">Visitors</th>
                          <th className="pb-1.5 text-right">Sales</th>
                          <th className="pb-1.5 text-right">Conv. %</th>
                        </tr>
                      </thead>
                      <tbody>
                        {metrics.devicePerformance.map((d, dIdx) => (
                          <tr key={dIdx} className="border-b border-gray-100/50 dark:border-zinc-805/30 hover:bg-white dark:hover:bg-zinc-900/40">
                            <td className="py-1.5 font-bold">{d.device}</td>
                            <td className="py-1.5 text-center font-mono">{d.visitors.toLocaleString()}</td>
                            <td className="py-1.5 text-right font-mono font-bold">${d.revenue.toLocaleString()}</td>
                            <td className="py-1.5 text-right font-mono text-indigo-600 dark:text-indigo-400">{d.conversion}%</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* Executive KPI summary preview */}
          {activeSection === "summary" && (
            <div className="space-y-4 animate-fadeIn">
              <div className="flex justify-between items-center border-b border-gray-50 dark:border-zinc-805 pb-3">
                <span className="text-[11px] font-extrabold text-cyan-600 dark:text-cyan-400 uppercase tracking-widest font-mono">
                  SECTION A PREVIEW: Executive Summary
                </span>
                <span className="text-[9px] text-gray-400 font-mono">Live calculation logs</span>
              </div>

              <div id="summary-section-container" className="p-4 bg-slate-50 dark:bg-zinc-950/20 rounded-xl border border-slate-100 dark:border-zinc-800 flex items-start gap-3">
                <Sparkles className="h-5 w-5 text-cyan-500 shrink-0 mt-0.5 animate-pulse" />
                <div>
                  <h4 className="text-xs font-bold text-gray-900 dark:text-white">AI Synthesis Paragraph</h4>
                  <p className="text-xs text-gray-600 dark:text-zinc-300 leading-relaxed mt-2">
                    {insights.executiveSummary}
                  </p>
                </div>
              </div>

              {/* KPI blocks summary page view */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5 pt-2">
                <div className="p-3 bg-slate-50/50 dark:bg-zinc-950/20 rounded-xl border border-slate-100 dark:border-zinc-805">
                  <span className="text-[9px] uppercase tracking-wider text-gray-400 dark:text-zinc-500 font-mono">Gross Store Net Revenue</span>
                  <p className="text-sm font-extrabold text-gray-900 dark:text-white mt-1">${metrics.revenue.toLocaleString()}</p>
                </div>
                <div className="p-3 bg-slate-50/50 dark:bg-zinc-950/20 rounded-xl border border-slate-100 dark:border-zinc-805">
                  <span className="text-[9px] uppercase tracking-wider text-gray-400 dark:text-zinc-500 font-mono">Completed Conversions</span>
                  <p className="text-sm font-extrabold text-gray-900 dark:text-white mt-1">{metrics.orders.toLocaleString()}</p>
                </div>
                <div className="p-3 bg-slate-50/50 dark:bg-zinc-950/20 rounded-xl border border-slate-100 dark:border-zinc-805">
                  <span className="text-[9px] uppercase tracking-wider text-gray-400 dark:text-zinc-500 font-mono">Average Order Value (AOV)</span>
                  <p className="text-sm font-extrabold text-gray-900 dark:text-white mt-1">${metrics.aov.toFixed(2)}</p>
                </div>
                <div className="p-3 bg-slate-50/50 dark:bg-zinc-950/20 rounded-xl border border-slate-100 dark:border-zinc-805">
                  <span className="text-[9px] uppercase tracking-wider text-gray-400 dark:text-zinc-500 font-mono">Primary Conversion Rate</span>
                  <p className="text-sm font-extrabold text-gray-900 dark:text-white mt-1">{metrics.conversionRate}%</p>
                </div>
                <div className="p-3 bg-slate-50/50 dark:bg-zinc-950/20 rounded-xl border border-slate-100 dark:border-zinc-805">
                  <span className="text-[9px] uppercase tracking-wider text-gray-400 dark:text-zinc-500 font-mono">Cart Abandonment Index</span>
                  <p className="text-sm font-extrabold text-gray-900 dark:text-white mt-1">{metrics.cartAbandonment}%</p>
                </div>
                <div className="p-3 bg-slate-50/50 dark:bg-zinc-950/20 rounded-xl border border-slate-100 dark:border-zinc-805">
                  <span className="text-[9px] uppercase tracking-wider text-gray-400 dark:text-zinc-500 font-mono">Cohort Returns VIP Share</span>
                  <p className="text-sm font-extrabold text-gray-900 dark:text-white mt-1">{metrics.returningCustomerRate}%</p>
                </div>
              </div>

              {/* Show metrics correlation card */}
              <div className="p-4 bg-cyan-500/5 dark:bg-cyan-950/5 rounded-xl border border-cyan-500/20">
                <h4 className="text-xs font-extrabold text-cyan-600 dark:text-cyan-400 mb-1 flex items-center gap-1.5">
                  <TrendingUp className="h-4.5 w-4.5 text-cyan-500" />
                  <span>Calculated Correlation Formula Key:</span>
                </h4>
                <p className="text-xs text-gray-600 dark:text-zinc-300 leading-normal">
                  {insights.revenueIncrInsight || "Revenue grew significantly this session."}
                </p>
              </div>
            </div>
          )}

          {/* Funnel Telemetry checkouts stage preview */}
          {activeSection === "funnel" && (
            <div className="space-y-4 animate-fadeIn">
              <div className="flex justify-between items-center border-b border-gray-50 dark:border-zinc-805 pb-3">
                <span className="text-[11px] font-extrabold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest font-mono">
                  SECTION B PREVIEW: Funnel Analysis Table
                </span>
                <span className="text-[9px] text-gray-400 font-mono">{metrics.funnelData.length} checkpoints computed</span>
              </div>

              <div id="funnel-section-container" className="p-4 bg-slate-50 dark:bg-zinc-950/20 rounded-xl border border-slate-100 dark:border-zinc-800">
                <p className="text-xs text-gray-600 dark:text-zinc-300 leading-relaxed">
                  {insights.conversionInsights || "Analyzing core multi-stage shopper conversion thresholds."}
                </p>
              </div>

              {/* Table rendering on preview */}
              <div className="overflow-x-auto">
                <table id="funnel-telemetry-preview-table" className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-zinc-800 text-gray-400 dark:text-zinc-500 uppercase tracking-wider font-mono">
                      <th className="py-2">Stage Name</th>
                      <th className="py-2">Visitor Sessions</th>
                      <th className="py-2 text-center">Progress %</th>
                      <th className="py-2 text-center">Dropoff %</th>
                      <th className="py-2 text-right">Potential Leakage</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-zinc-805/50">
                    {metrics.funnelData.map((stage, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/50 dark:hover:bg-zinc-950/10">
                        <td className="py-2.5 font-bold text-gray-900 dark:text-zinc-150">{stage.stage}</td>
                        <td className="py-2.5">{stage.value.toLocaleString()}</td>
                        <td className="py-2.5 text-center font-mono">{stage.percentage}%</td>
                        <td className="py-2.5 text-center text-rose-500 font-mono">{stage.dropoff}%</td>
                        <td className="py-2.5 text-right font-mono text-gray-900 dark:text-white font-bold">
                          ${(stage.revenueLeakage || Math.round(metrics.revenue * (stage.dropoff / 100))).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Customer Cohort previews */}
          {activeSection === "customer" && (
            <div className="space-y-4 animate-fadeIn">
              <div className="flex justify-between items-center border-b border-gray-50 dark:border-zinc-805 pb-3">
                <span className="text-[11px] font-extrabold text-purple-600 dark:text-purple-400 uppercase tracking-widest font-mono">
                  SECTION C PREVIEW: Customer Loyalty & Cohorts Matrix
                </span>
                <span className="text-[9px] text-gray-400 font-mono">Retention benchmarks</span>
              </div>

              <div id="customer-section-container" className="p-4 bg-slate-50 dark:bg-zinc-950/20 rounded-xl border border-slate-100 dark:border-zinc-800">
                <p className="text-xs text-gray-600 dark:text-zinc-300 leading-relaxed">
                  {insights.customerJourneyInsights || "Cohort returns stabilized at Month 3, representing a solid VIP loop."}
                </p>
              </div>

              {/* Table rendering on preview */}
              <div className="overflow-x-auto">
                <table id="cohort-retention-preview-table" className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-zinc-800 text-gray-400 dark:text-zinc-500 uppercase tracking-wider font-mono">
                      <th className="py-2">Cohort Month</th>
                      <th className="py-2">Pool Size</th>
                      <th className="py-2 text-center">Month 1</th>
                      <th className="py-2 text-center">Month 2</th>
                      <th className="py-2 text-center">Month 3</th>
                      <th className="py-2 text-center">Month 4</th>
                      <th className="py-2 text-center">Month 5</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-zinc-805/50">
                    {metrics.cohortData.map((cohort, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/50 dark:hover:bg-zinc-950/10">
                        <td className="py-2.5 font-bold text-gray-900 dark:text-zinc-150">{cohort.cohort}</td>
                        <td className="py-2.5 font-mono">{cohort.size.toLocaleString()}</td>
                        <td className="py-2.5 text-center font-mono">{cohort.m1}%</td>
                        <td className="py-2.5 text-center font-mono">{cohort.m2}%</td>
                        <td className="py-2.5 text-center font-mono text-cyan-600 dark:text-cyan-400 font-bold">{cohort.m3}%</td>
                        <td className="py-2.5 text-center font-mono">{cohort.m4}%</td>
                        <td className="py-2.5 text-center font-mono">{cohort.m5}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Marketing Acquisitions ROI preview */}
          {activeSection === "marketing" && (
            <div className="space-y-4 animate-fadeIn">
              <div className="flex justify-between items-center border-b border-gray-50 dark:border-zinc-805 pb-3">
                <span className="text-[11px] font-extrabold text-teal-600 dark:text-teal-400 uppercase tracking-widest font-mono">
                  SECTION D PREVIEW: Marketing Acquisitions Channels ROI
                </span>
                <span className="text-[9px] text-gray-400 font-mono">Yield benchmarks</span>
              </div>

              <div id="marketing-section-container" className="p-4 bg-slate-50 dark:bg-zinc-950/20 rounded-xl border border-slate-100 dark:border-zinc-800">
                <p className="text-xs text-gray-600 dark:text-zinc-300 leading-relaxed">
                  {insights.marketingInsights || "Evaluating channels conversion indices and organic ROI parameters."}
                </p>
              </div>

              {/* Table rendering on preview */}
              <div className="overflow-x-auto">
                <table id="marketing-performance-preview-table" className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-zinc-800 text-gray-400 dark:text-zinc-500 uppercase tracking-wider font-mono">
                      <th className="py-2">Source Channel</th>
                      <th className="py-2">Traffic Users</th>
                      <th className="py-2">Orders Made</th>
                      <th className="py-2 text-center">Conversion %</th>
                      <th className="py-2 text-right">Attributed Revenue</th>
                      <th className="py-4 text-right">Ad Spend ROI</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-zinc-805/50">
                    {metrics.channelPerformance.map((source, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/50 dark:hover:bg-zinc-950/10">
                        <td className="py-2.5 font-bold text-gray-900 dark:text-zinc-150">{source.channel}</td>
                        <td className="py-2.5">{source.visitors.toLocaleString()}</td>
                        <td className="py-2.5">{source.orders.toLocaleString()}</td>
                        <td className="py-2.5 text-center font-mono">{source.conversion}%</td>
                        <td className="py-2.5 text-right font-mono">${source.revenue.toLocaleString()}</td>
                        <td className="py-2.5 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400">{source.roi}x</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Product conversions preview */}
          {activeSection === "product" && (
            <div className="space-y-4 animate-fadeIn">
              <div className="flex justify-between items-center border-b border-gray-50 dark:border-zinc-805 pb-3">
                <span className="text-[11px] font-extrabold text-amber-600 dark:text-amber-400 uppercase tracking-widest font-mono">
                  SECTION E PREVIEW: Product Conversion Analytics
                </span>
                <span className="text-[9px] text-gray-400 font-mono">Catalog listing parameters</span>
              </div>

              <div id="product-section-container" className="p-4 bg-slate-50 dark:bg-zinc-950/20 rounded-xl border border-slate-100 dark:border-zinc-800">
                <p className="text-xs text-gray-600 dark:text-zinc-300 leading-relaxed">
                  {insights.productInsights || "Reviewing product-specific view metrics and transaction conversions."}
                </p>
              </div>

              {/* Highlight Product lever friction alert info */}
              <div className="p-4 bg-rose-500/5 rounded-xl border border-rose-500/20 text-xs flex gap-2">
                <AlertCircle className="h-4.5 w-4.5 text-rose-500 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-rose-600 dark:text-rose-400 font-bold">Catalog Friction Highlight:</strong>
                  <p className="mt-1 text-gray-600 dark:text-zinc-300 leading-normal">
                    {insights.productLeverInsight || "Some items are displaying high page views but lag in checkout progression."}
                  </p>
                </div>
              </div>

              {/* Table rendering on preview */}
              <div className="overflow-x-auto">
                <table id="product-performance-preview-table" className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-zinc-800 text-gray-400 dark:text-zinc-500 uppercase tracking-wider font-mono">
                      <th className="py-2">Item Name SKU</th>
                      <th className="py-2 text-center">Display Views</th>
                      <th className="py-2 text-center">Cart Inserts</th>
                      <th className="py-2 text-center">Purchased</th>
                      <th className="py-2 text-right">Attributed Sales</th>
                      <th className="py-2 text-right">Conversion Index</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-zinc-805/50">
                    {metrics.productPerformance.map((item, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/50 dark:hover:bg-zinc-950/10">
                        <td className="py-2.5 font-bold text-gray-900 dark:text-zinc-150">{item.name}</td>
                        <td className="py-2.5 text-center font-mono">{item.views.toLocaleString()}</td>
                        <td className="py-2.5 text-center font-mono">{item.cartInserts.toLocaleString()}</td>
                        <td className="py-2.5 text-center font-mono">{item.orders.toLocaleString()}</td>
                        <td className="py-2.5 text-right font-mono">${item.revenue.toLocaleString()}</td>
                        <td className="py-2.5 text-right font-mono font-bold text-amber-500">{item.conversion}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

        </div>
      </div>

    </div>
  );
}
