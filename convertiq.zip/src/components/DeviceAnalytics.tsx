import { useState, useMemo } from "react";
import {
  Monitor,
  Smartphone,
  Tablet,
  TrendingUp,
  TrendingDown,
  Info,
  X,
  SlidersHorizontal,
  DollarSign,
  Activity,
  Award,
  Layers,
  ArrowRight,
  TrendingUp as TrendingUpIcon,
  ShoppingCart
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  Line,
  ComposedChart
} from "recharts";
import { motion, AnimatePresence } from "motion/react";
import { IngestedRecord, GlobalFilters, UnifiedMetrics } from "../types";

interface DeviceAnalyticsProps {
  metrics: UnifiedMetrics;
  filters: GlobalFilters;
  setFilters: (filters: GlobalFilters) => void;
  isSimulating: boolean;
  uploadedData?: IngestedRecord[];
}

const mapToCoreDevice = (dev: string): "Desktop" | "Mobile" | "Tablet" => {
  const d = (dev || "").toLowerCase();
  if (d.includes("desk") || d.includes("pc") || d.includes("window") || d.includes("mac")) return "Desktop";
  if (d.includes("mob") || d.includes("phone") || d.includes("android") || d.includes("ios")) return "Mobile";
  if (d.includes("tab") || d.includes("ipad")) return "Tablet";
  return "Desktop"; // Default fallback
};

export default function DeviceAnalytics({
  metrics,
  filters,
  setFilters,
  isSimulating,
  uploadedData = []
}: DeviceAnalyticsProps) {
  const [activeChartType, setActiveChartType] = useState<"trafficRevenue" | "conversionEfficiency" | "shareBreakdown">("trafficRevenue");

  const deviceIcons = {
    Desktop: Monitor,
    Mobile: Smartphone,
    Tablet: Tablet
  };

  const deviceColors = {
    Desktop: { fill: "#4f46e5", stroke: "#818cf8", bg: "rgba(79, 70, 229, 0.1)", ring: "ring-indigo-500/20", border: "border-indigo-100 dark:border-indigo-900/30", text: "text-indigo-600 dark:text-indigo-400" },
    Mobile: { fill: "#0891b2", stroke: "#22d3ee", bg: "rgba(8, 145, 178, 0.1)", ring: "ring-cyan-500/20", border: "border-cyan-100 dark:border-cyan-900/30", text: "text-cyan-600 dark:text-cyan-400" },
    Tablet: { fill: "#ec4899", stroke: "#f472b6", bg: "rgba(236, 72, 153, 0.1)", ring: "ring-pink-500/20", border: "border-pink-100 dark:border-pink-900/30", text: "text-pink-600 dark:text-pink-400" }
  };

  // 1. Core Data Stream processing pipeline
  const computedDevicesData = useMemo(() => {
    // If lives logs are uploaded, compute on-the-fly dynamically to maintain 100% precision
    if (!isSimulating && uploadedData && uploadedData.length > 0) {
      const recordsToUse = uploadedData.filter(v => {
        // Date range evaluation
        const recordTime = new Date(v.timestamp).getTime();
        const timestamps = uploadedData.map(r => new Date(r.timestamp).getTime()).filter(t => !isNaN(t));
        const latestTime = timestamps.length > 0 ? timestamps.reduce((max, t) => t > max ? t : max, timestamps[0]) : Date.now();
        const daysLimit = filters.dateRange === "7d" ? 7 : filters.dateRange === "90d" ? 90 : 30;
        const milliLimit = daysLimit * 24 * 60 * 60 * 1000;

        if (isNaN(recordTime) || latestTime - recordTime > milliLimit) return false;

        // Apply region metrics cross filters
        if (filters.region !== "all" && v.region) {
          const r1 = v.region.toLowerCase();
          const r2 = filters.region.toLowerCase();
          if (!r1.includes(r2) && !r2.includes(r1)) return false;
        }

        // Apply product catalog cross filters
        if (filters.product !== "all" && v.product_name) {
          const p1 = v.product_name.toLowerCase();
          const filterP = filters.product.toLowerCase();
          if (!p1.includes(filterP)) return false;
        }

        // Apply Traffic campaign cross filters
        if (filters.channel !== "all" && v.traffic_source) {
          if (v.traffic_source.toLowerCase() !== filters.channel.toLowerCase()) return false;
        }

        return true;
      });

      // Group records into bins
      const bins: Record<"Desktop" | "Mobile" | "Tablet", IngestedRecord[]> = {
        Desktop: [],
        Mobile: [],
        Tablet: []
      };

      recordsToUse.forEach(rec => {
        const devKey = mapToCoreDevice(rec.device_type);
        bins[devKey].push(rec);
      });

      return (Object.keys(bins) as Array<keyof typeof bins>).map(dName => {
        const binRecs = bins[dName];
        const sessions = new Set(binRecs.map(r => r.session_id)).size;
        const purchaseRecs = binRecs.filter(r => r.event_type === "purchase");
        const orders = purchaseRecs.length;
        const revenue = purchaseRecs.reduce((sum, r) => sum + r.revenue, 0);
        const conversion = sessions > 0 ? parseFloat(((orders / sessions) * 100).toFixed(2)) : 0;

        // Extra details for thoroughness: AOV & cart cancellation
        const cartSessions = new Set(binRecs.filter(v => v.event_type === "cart").map(x => x.session_id)).size;
        const purchaseSessions = new Set(purchaseRecs.map(y => y.session_id)).size;
        const abandonment = cartSessions > 0 ? parseFloat((Math.max(0, 1 - (purchaseSessions / cartSessions)) * 100).toFixed(1)) : 0;

        return {
          device: dName,
          visitors: sessions,
          orders,
          conversion: isNaN(conversion) ? 0 : conversion,
          revenue: Math.round(revenue),
          aov: orders > 0 ? parseFloat((revenue / orders).toFixed(1)) : 0,
          abandonment
        };
      });
    }

    // In Simulation mode, pull directly from the parsed metrics schema returned from demo records
    const rawMockPerf = metrics.devicePerformance || [];
    const defaults = {
      Desktop: { visitors: 0, orders: 0, conversionSum: 0, count: 0, revenue: 0, cartAbandonedAvg: 58.2 },
      Mobile: { visitors: 0, orders: 0, conversionSum: 0, count: 0, revenue: 0, cartAbandonedAvg: 74.5 },
      Tablet: { visitors: 0, orders: 0, conversionSum: 0, count: 0, revenue: 0, cartAbandonedAvg: 65.8 }
    };

    rawMockPerf.forEach(p => {
      const mapped = mapToCoreDevice(p.device);
      defaults[mapped].visitors += p.visitors || 0;
      defaults[mapped].orders += p.orders || 0;
      defaults[mapped].conversionSum += p.conversion || 0;
      defaults[mapped].revenue += p.revenue || 0;
      defaults[mapped].count += 1;
    });

    return (Object.keys(defaults) as Array<keyof typeof defaults>).map(dName => {
      const def = defaults[dName];
      return {
        device: dName,
        visitors: def.visitors,
        orders: def.orders,
        conversion: def.count > 0 ? parseFloat((def.conversionSum / def.count).toFixed(2)) : 0,
        revenue: def.revenue,
        aov: def.orders > 0 ? parseFloat((def.revenue / def.orders).toFixed(1)) : 0,
        abandonment: def.cartAbandonedAvg
      };
    });
  }, [isSimulating, uploadedData, metrics.devicePerformance, filters]);

  // Aggregate values
  const totalDeviceSessions = useMemo(() => computedDevicesData.reduce((sum, d) => sum + d.visitors, 0), [computedDevicesData]);
  const totalDeviceRevenue = useMemo(() => computedDevicesData.reduce((sum, d) => sum + d.revenue, 0), [computedDevicesData]);
  const totalDeviceOrders = useMemo(() => computedDevicesData.reduce((sum, d) => sum + d.orders, 0), [computedDevicesData]);

  // Append contribution factors
  const deviceDataWithPercentage = useMemo(() => {
    return computedDevicesData.map(d => ({
      ...d,
      sessionsContribution: totalDeviceSessions > 0 ? parseFloat(((d.visitors / totalDeviceSessions) * 100).toFixed(1)) : 0,
      revenueContribution: totalDeviceRevenue > 0 ? parseFloat(((d.revenue / totalDeviceRevenue) * 100).toFixed(1)) : 0,
      ordersContribution: totalDeviceOrders > 0 ? parseFloat(((d.orders / totalDeviceOrders) * 100).toFixed(1)) : 0
    })).sort((a, b) => b.revenue - a.revenue);
  }, [computedDevicesData, totalDeviceSessions, totalDeviceRevenue, totalDeviceOrders]);

  // Metrics highlights
  const topDeviceByRevenue = useMemo(() => {
    return [...deviceDataWithPercentage].sort((a, b) => b.revenue - a.revenue)[0];
  }, [deviceDataWithPercentage]);

  const topDeviceByTraffic = useMemo(() => {
    return [...deviceDataWithPercentage].sort((a, b) => b.visitors - a.visitors)[0];
  }, [deviceDataWithPercentage]);

  // Handle toggling device filters cross-filtering hook
  const toggleDeviceFilter = (deviceKey: string) => {
    const newDeviceValue = filters.device.toLowerCase() === deviceKey.toLowerCase() ? "all" : deviceKey;
    setFilters({
      ...filters,
      device: newDeviceValue
    });
  };

  return (
    <div id="device-analytics-view" className="space-y-6">
      
      {/* Visual Header Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-gray-150 dark:border-zinc-850 pb-5 text-left">
        <div>
          <h2 className="text-xl font-extrabold text-gray-900 dark:text-white flex items-center gap-2 tracking-tight block">
            <Monitor className="h-5.5 w-5.5 text-indigo-505 bg-indigo-500/10 text-indigo-550 p-0.5 rounded-lg shrink-0" />
            <span>Device Platforms Analytics</span>
          </h2>
          <p className="text-xs text-gray-500 dark:text-zinc-400 mt-1 leading-normal">
            Analyze absolute user sessions, orders volumes, checkout conversion levels, and cart retention parameters segmented by Desktop, Mobiles, and Tablets.
          </p>
        </div>

        {/* Global Filter Indicator */}
        <div className="flex items-center gap-2">
          {filters.device !== "all" && (
            <button
              onClick={() => setFilters({ ...filters, device: "all" })}
              className="text-[10px] bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 px-2.5 py-1 rounded-full flex items-center gap-1 hover:bg-indigo-500/20 transition-all font-bold"
            >
              <span>Platform filter: {filters.device}</span>
              <X className="h-3 w-3" />
            </button>
          )}

          <span className={`text-[10px] uppercase tracking-wider font-extrabold px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-xs border ${
            isSimulating
              ? "bg-amber-500/10 text-amber-650 dark:text-amber-400 border-amber-500/20"
              : "bg-emerald-500/10 text-emerald-650 dark:text-emerald-400 border-emerald-500/20"
          }`}>
            <span className={`h-2 w-2 rounded-full ${isSimulating ? "bg-amber-500 animate-pulse" : "bg-emerald-500"}`} />
            <span>{isSimulating ? "Demo Device Sim" : "Log Ingestion Model Streams"}</span>
          </span>
        </div>
      </div>

      {/* Dynamic HEURISTIC CRITICAL COMPARATIVE CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-left">
        {/* Highlight 1: Revenue Outperformer */}
        {topDeviceByRevenue && (
          <div className="p-4.5 rounded-2xl border border-indigo-500/15 dark:border-indigo-950/60 bg-indigo-500/[0.03] flex items-start gap-4">
            <div className="p-3 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-xl">
              <Award className="h-5.5 w-5.5" />
            </div>
            <div className="space-y-1">
              <span className="text-[9px] uppercase font-black font-mono tracking-widest text-indigo-505 dark:text-indigo-400">Capital Standard</span>
              <h4 className="text-sm font-extrabold text-gray-900 dark:text-white">
                {topDeviceByRevenue.device} Platforms lead capital margins with {topDeviceByRevenue.revenueContribution}% share.
              </h4>
              <p className="text-[11px] text-gray-500">
                Attributing <strong>${topDeviceByRevenue.revenue.toLocaleString()}</strong> in gross revenues spanned across <strong>{topDeviceByRevenue.orders.toLocaleString()}</strong> orders.
              </p>
            </div>
          </div>
        )}

        {/* Highlight 2: Funnel Leakage Warning */}
        {useMemo(() => {
          const mobileObj = deviceDataWithPercentage.find(x => x.device === "Mobile");
          if (!mobileObj) return null;
          const leakageGap = Math.round(mobileObj.sessionsContribution - mobileObj.revenueContribution);
          const needsFix = leakageGap > 5;

          return (
            <div className={`p-4.5 rounded-2xl border flex items-start gap-4 ${
              needsFix
                ? "border-rose-500/15 dark:border-rose-950 bg-rose-500/[0.03]"
                : "border-gray-200/50 dark:border-zinc-850 bg-gray-50/20"
            }`}>
              <div className={`p-3 rounded-xl ${needsFix ? "bg-rose-500/10 text-rose-550" : "bg-cyan-500/10 text-cyan-500"}`}>
                <ShoppingCart className="h-5.5 w-5.5" />
              </div>
              <div className="space-y-1">
                <span className={`text-[9px] uppercase font-black font-mono tracking-widest ${needsFix ? "text-rose-500" : "text-cyan-505"}`}>
                  {needsFix ? "CR SLIPPAGE ALERT" : "STABLE FLOWS"}
                </span>
                <h4 className="text-sm font-extrabold text-gray-900 dark:text-white">
                  {needsFix ? `Mobile yields ${mobileObj.sessionsContribution}% visitors but only ${mobileObj.revenueContribution}% margins.` : "Mobile and mobile conversion metrics optimal."}
                </h4>
                <p className="text-[11px] text-gray-500">
                  Mobile conversion rates sit at <strong>{mobileObj.conversion}%</strong> compared to tablet/desktops. This denotes layout bottleneck friction.
                </p>
              </div>
            </div>
          );
        }, [deviceDataWithPercentage])}
      </div>

      {/* THREE-CARD PLATFORM COMPARATORS (allowing cross-filtering) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
        {deviceDataWithPercentage.map((item) => {
          const Icon = deviceIcons[item.device as keyof typeof deviceIcons] || Smartphone;
          const colors = deviceColors[item.device as keyof typeof deviceColors];
          const isFilteringThis = filters.device.toLowerCase() === item.device.toLowerCase();

          return (
            <div
              key={item.device}
              onClick={() => toggleDeviceFilter(item.device)}
              className={`p-5 rounded-2xl border transition-all cursor-pointer select-none flex flex-col justify-between ${
                isFilteringThis
                  ? "bg-slate-50 dark:bg-zinc-900/60 border-indigo-500 ring-2 ring-indigo-500/10 shadow-lg scale-[1.01]"
                  : "border-gray-200/60 dark:border-zinc-850 bg-white dark:bg-zinc-900/40 hover:bg-gray-55/60 dark:hover:bg-zinc-850/30 shadow-xs"
              }`}
            >
              <div>
                <div className="flex justify-between items-start">
                  <div className={`p-3 rounded-xl ${colors.bg} ${colors.text}`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  
                  {isFilteringThis ? (
                    <span className="text-[8px] bg-indigo-650 text-white truncate font-mono uppercase tracking-wider font-extrabold px-2 py-0.5 rounded-full shadow-xs">
                      Active Filter
                    </span>
                  ) : (
                    <span className="text-[9.5px] font-mono text-gray-400 font-bold bg-gray-50 dark:bg-zinc-850 px-2.5 py-1 rounded">
                      {item.sessionsContribution}% share
                    </span>
                  )}
                </div>

                <h3 className="text-[17px] font-extrabold text-gray-900 dark:text-white mt-4 flex items-center gap-2">
                  <span>{item.device} Channel</span>
                </h3>
                <p className="text-[10px] text-gray-400">Total sessions tracked: <strong>{item.visitors.toLocaleString()} visits</strong></p>

                <div className="grid grid-cols-2 gap-3 mt-6 border-t border-gray-100 dark:border-zinc-850/60 pt-4 text-xs">
                  <div>
                    <span className="text-[9px] text-gray-400 block font-mono uppercase font-black">Revenue Captured</span>
                    <p className="text-base font-extrabold text-gray-900 dark:text-white font-mono mt-0.5">${item.revenue.toLocaleString()}</p>
                    <span className="text-[9.5px] text-gray-400 block font-light">{item.revenueContribution}% of aggregate profit</span>
                  </div>

                  <div>
                    <span className="text-[9px] text-gray-400 block font-mono uppercase font-black">Conversion Speed</span>
                    <p className="text-base font-extrabold text-indigo-600 dark:text-indigo-400 font-mono mt-0.5">{item.conversion}% CR</p>
                    <span className="text-[9.5px] text-gray-405 block font-light">Abandonment: {item.abandonment}%</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between mt-5 border-t border-gray-100 dark:border-zinc-850/30 pt-3 text-[10px] text-indigo-600 dark:text-indigo-400 font-bold">
                <span>{isFilteringThis ? "Reset default view" : "Filter other stats on this platform"}</span>
                <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
              </div>
            </div>
          );
        })}
      </div>

      {/* COMPARATIVE INTERACTIVE CHART PLATFORM */}
      <div className="p-5 rounded-2xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 flex flex-col text-left">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-gray-150 dark:border-zinc-805 pb-4">
          <div>
            <h3 className="text-xs font-black tracking-widest text-indigo-650 dark:text-indigo-400 uppercase font-mono flex items-center gap-1.5">
              <Activity className="h-4.5 w-4.5 text-indigo-550 shrink-0" />
              <span>Comparative Platform Graphs</span>
            </h3>
            <p className="text-[10px] text-gray-400 mt-0.5">Visually benchmark device metrics, volume contributions, and conversion rates.</p>
          </div>

          <div className="flex bg-gray-100 dark:bg-zinc-850 p-0.5 rounded-lg border border-gray-200/50 dark:border-zinc-800 text-[10px] font-bold">
            <button
              onClick={() => setActiveChartType("trafficRevenue")}
              className={`px-3 py-1.5 rounded-md transition-all ${
                activeChartType === "trafficRevenue"
                  ? "bg-indigo-600 text-white font-extrabold shadow-sm"
                  : "text-gray-500 hover:text-gray-950 dark:text-zinc-400"
              }`}
            >
              Traffic vs Revenue Split
            </button>
            <button
              onClick={() => setActiveChartType("conversionEfficiency")}
              className={`px-3 py-1.5 rounded-md transition-all ${
                activeChartType === "conversionEfficiency"
                  ? "bg-indigo-600 text-white font-extrabold shadow-sm"
                  : "text-gray-500 hover:text-gray-950 dark:text-zinc-400"
              }`}
            >
              Conversion Efficiency (%)
            </button>
            <button
              onClick={() => setActiveChartType("shareBreakdown")}
              className={`px-3 py-1.5 rounded-md transition-all ${
                activeChartType === "shareBreakdown"
                  ? "bg-indigo-600 text-white font-extrabold shadow-sm"
                  : "text-gray-500 hover:text-gray-950 dark:text-zinc-400"
              }`}
            >
              Platform Revenue shares
            </button>
          </div>
        </div>

        {/* Dynamic Recharts canvas rendering */}
        <div className="h-72 mt-6">
          {activeChartType === "trafficRevenue" ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={deviceDataWithPercentage} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(128,128,128,0.06)" />
                <XAxis dataKey="device" style={{ fontSize: 10, fill: "#888", fontWeight: "bold" }} tickLine={false} />
                <YAxis style={{ fontSize: 9, fill: "#888" }} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(12, 12, 12, 0.95)",
                    border: "1px solid rgba(80, 80, 80, 0.15)",
                    borderRadius: 12,
                    fontSize: 10,
                    color: "#fff"
                  }}
                  formatter={(val: any, name: string) => [
                    name === "revenue" ? `$${val.toLocaleString()}` : val.toLocaleString(),
                    name === "revenue" ? "Revenue captured" : "Sessions volume"
                  ]}
                />
                <Legend wrapperStyle={{ fontSize: 9 }} />
                <Bar dataKey="visitors" name="Platform Traffic Sessions" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="revenue" name="Platform Revenue Gross ($)" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : activeChartType === "conversionEfficiency" ? (
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={deviceDataWithPercentage} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(128,128,128,0.06)" />
                <XAxis dataKey="device" style={{ fontSize: 10, fill: "#888", fontWeight: "bold" }} tickLine={false} />
                <YAxis style={{ fontSize: 9, fill: "#888" }} label={{ value: 'Percentage (%)', angle: -90, position: 'insideLeft', offset: -10, style: { fontSize: 8, fill: '#aaa' } }} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(12, 12, 12, 0.95)",
                    border: "1px solid rgba(80, 80, 80, 0.15)",
                    borderRadius: 12,
                    fontSize: 10,
                    color: "#fff"
                  }}
                  formatter={(val: any, name: string) => [`${val}%`, name === "conversion" ? "Conversion rate (CR%)" : "Abandonment (ATC Dropoff%)"]}
                />
                <Legend wrapperStyle={{ fontSize: 9 }} />
                <Bar dataKey="conversion" name="Average Platform CR (%)" fill="#6366f1" barSize={35} radius={[4, 4, 0, 0]} />
                <Line type="monotone" dataKey="abandonment" name="Cart abandonment rate (%)" stroke="#ec4899" strokeWidth={3} dot={{ strokeWidth: 2, r: 4 }} />
              </ComposedChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full w-full flex flex-col md:flex-row items-center justify-around gap-4">
              <div className="w-full md:w-1/2 h-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={deviceDataWithPercentage}
                      cx="50%"
                      cy="50%"
                      innerRadius={65}
                      outerRadius={95}
                      paddingAngle={4}
                      dataKey="revenue"
                    >
                      {deviceDataWithPercentage.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={deviceColors[entry.device as keyof typeof deviceColors].fill} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "rgba(12, 12, 12, 0.95)",
                        border: "1px solid rgba(80, 80, 80, 0.15)",
                        borderRadius: 12,
                        fontSize: 10,
                        color: "#fff"
                      }}
                      formatter={(val: any) => [`$${val.toLocaleString()}`, "Share Revenue"]}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              {/* Pie description values block */}
              <div className="w-full md:w-1/3 space-y-3">
                <p className="text-[11px] uppercase font-black tracking-wider text-gray-400 font-mono">Platform Revenue Breakdown</p>
                <div className="divide-y divide-gray-100 dark:divide-zinc-800">
                  {deviceDataWithPercentage.map(entry => (
                    <div key={entry.device} className="py-2 flex justify-between items-center text-xs">
                      <div className="flex items-center gap-2">
                        <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: deviceColors[entry.device as keyof typeof deviceColors].fill }} />
                        <span className="font-extrabold text-gray-800 dark:text-zinc-200">{entry.device}</span>
                      </div>
                      <div className="text-right font-mono font-bold text-gray-950 dark:text-white">
                        <span>${entry.revenue.toLocaleString()}</span>
                        <span className="text-[10px] text-gray-400 block font-normal">{entry.revenueContribution}% share</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

    </div>
  );
}
