import { useState } from "react";
import {
  Share2,
  TrendingUp,
  AlertTriangle,
  Flame,
  Frown,
  Lightbulb,
  Sparkles,
  Users,
  Target,
  ShoppingBag,
  ArrowUpRight,
  TrendingDown,
  Percent,
  TrendingUp as TrendingUpIcon,
  HelpCircle,
  BarChart4,
  DollarSign
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart as RePieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  AreaChart,
  Area
} from "recharts";
import { IngestedRecord, GlobalFilters, UnifiedMetrics } from "../types";

interface MarketingModuleProps {
  metrics: UnifiedMetrics;
  filters: GlobalFilters;
  setFilters: (filters: GlobalFilters) => void;
  isSimulating: boolean;
  uploadedData?: IngestedRecord[];
}

interface ChannelStats {
  channel: "Google" | "Facebook" | "Instagram" | "Email" | "Direct";
  traffic: number;
  orders: number;
  revenue: number;
  conversion: number;
  spend: number;
  roi: number; // Returns multiplier, e.g., 5.4 for 5.4x ROAS
}

export default function MarketingModule({
  metrics,
  filters,
  setFilters,
  isSimulating,
  uploadedData = []
}: MarketingModuleProps) {
  // Navigation layout state: "grid" for multi-bento layout, or "zoom" to inspect specific charts in details
  const [layoutMode, setLayoutMode] = useState<"grid" | "comparison" | "revenue" | "conversion">("grid");

  // Helper classification schema for referrers
  const classifyChannel = (source: string): "Google" | "Facebook" | "Instagram" | "Email" | "Direct" => {
    if (!source) return "Direct";
    const s = source.toLowerCase();
    if (s.includes("google") || s.includes("organic") || s.includes("search") || s.includes("seo")) {
      return "Google";
    }
    if (s.includes("facebook") || s.includes("fb") || s.includes("meta")) {
      return "Facebook";
    }
    if (s.includes("instagram") || s.includes("ig") || s.includes("social")) {
      return "Instagram";
    }
    if (s.includes("email") || s.includes("newsletter") || s.includes("campaign")) {
      return "Email";
    }
    return "Direct"; // Free baseline referrer traffic
  };

  // ---------------------------------------------------------------------------
  // PIPELINE CALCULATION ENGINE
  // ---------------------------------------------------------------------------
  let channelStatsList: ChannelStats[] = [];

  if (!isSimulating && uploadedData && uploadedData.length > 0) {
    // 1. Filter raw uploaded logs matching active global filters
    const filteredRecords = uploadedData.filter(r => {
      // Date limits evaluation
      const timestamps = uploadedData.map(val => new Date(val.timestamp).getTime()).filter(t => !isNaN(t));
      const latestTime = timestamps.length > 0 ? timestamps.reduce((max, t) => t > max ? t : max, timestamps[0]) : Date.now();
      const recordTime = new Date(r.timestamp).getTime();
      if (isNaN(recordTime)) return false;

      const daysLimit = filters.dateRange === "7d" ? 7 : filters.dateRange === "90d" ? 90 : 30;
      const milliLimit = daysLimit * 24 * 60 * 60 * 1000;
      if (latestTime - recordTime > milliLimit) return false;

      // Region Filter
      if (filters.region !== "all" && r.region) {
        const checkVal = r.region.toLowerCase();
        const searchVal = filters.region.toLowerCase();
        if (!checkVal.includes(searchVal) && !searchVal.includes(checkVal)) return false;
      }

      // Device constraint
      if (filters.device !== "all" && r.device_type) {
        if (r.device_type.toLowerCase() !== filters.device.toLowerCase()) return false;
      }

      // Product boundary
      if (filters.product !== "all" && r.product_name) {
        const itemLower = r.product_name.toLowerCase();
        const idLower = r.product_id ? r.product_id.toLowerCase() : "";
        const queryLower = filters.product.toLowerCase();
        if (!itemLower.includes(queryLower) && !idLower.includes(queryLower)) return false;
      }

      // Note: we do not filter by "filters.channel" here as we want to view/compare ALL channels
      return true;
    });

    // 2. Classify filtered records into standard bins
    const buckets: Record<string, IngestedRecord[]> = {
      Google: [],
      Facebook: [],
      Instagram: [],
      Email: [],
      Direct: []
    };

    filteredRecords.forEach(r => {
      const channelLabel = classifyChannel(r.traffic_source);
      buckets[channelLabel].push(r);
    });

    // 3. Compute dynamic metrics
    channelStatsList = Object.keys(buckets).map(cKey => {
      const rows = buckets[cKey];
      const traffic = new Set(rows.map(r => r.session_id)).size;
      const ordersRows = rows.filter(r => r.event_type.toLowerCase() === "purchase" || r.event_type.toLowerCase() === "order");
      const orders = ordersRows.length;
      const revenue = Math.round(ordersRows.reduce((acc, r) => acc + (Number(r.revenue) || 0), 0));
      const conversion = traffic > 0 ? parseFloat(((orders / traffic) * 100).toFixed(2)) : 0;

      // Attribution cost structure benchmarks
      let spend = 0;
      if (cKey === "Google") {
        spend = Math.round(traffic * 0.85 + orders * 4.0);
      } else if (cKey === "Facebook") {
        spend = Math.round(traffic * 1.25 + orders * 5.5);
      } else if (cKey === "Instagram") {
        spend = Math.round(traffic * 1.10 + orders * 4.8);
      } else if (cKey === "Email") {
        spend = Math.round(traffic * 0.12 + orders * 0.4);
      } else {
        spend = 0; // Direct organic holds zero spend
      }

      const roi = spend > 0 ? parseFloat((revenue / spend).toFixed(2)) : 0;

      return {
        channel: cKey as any,
        traffic,
        orders,
        revenue,
        conversion,
        spend,
        roi
      };
    });
  }

  // Fallback simulator calculation if simulating is active or parsed data yields empty stats
  const totalCalculatedRevenue = channelStatsList.reduce((sum, s) => sum + s.revenue, 0);
  if (channelStatsList.length === 0 || totalCalculatedRevenue === 0) {
    const baseChannelModels = [
      { channel: "Google", traffic: 28400, orders: 820, revenue: 69700, spend: 18500 },
      { channel: "Facebook", traffic: 22100, orders: 540, revenue: 47250, spend: 23200 },
      { channel: "Instagram", traffic: 15300, orders: 410, revenue: 35800, spend: 16900 },
      { channel: "Email", traffic: 9800, orders: 620, revenue: 51200, spend: 3400 },
      { channel: "Direct", traffic: 16200, orders: 340, revenue: 28900, spend: 0 }
    ];

    // Filter scaling coefficients
    let scaleTime = 1.0;
    if (filters.dateRange === "7d") scaleTime = 0.23;
    else if (filters.dateRange === "90d") scaleTime = 3.0;

    let scaleRegion = 1.0;
    if (filters.region === "Americas") scaleRegion = 0.45;
    else if (filters.region === "Europe") scaleRegion = 0.30;
    else if (filters.region === "APAC") scaleRegion = 0.20;
    else if (filters.region === "MEA") scaleRegion = 0.05;

    let scaleDevice = { Google: 1.0, Facebook: 1.0, Instagram: 1.0, Email: 1.0, Direct: 1.0 };
    if (filters.device === "Desktop") {
      scaleDevice = { Google: 1.15, Facebook: 0.85, Instagram: 0.70, Email: 1.25, Direct: 1.10 };
    } else if (filters.device === "Mobile") {
      scaleDevice = { Google: 0.80, Facebook: 1.15, Instagram: 1.48, Email: 0.82, Direct: 0.90 };
    } else if (filters.device === "Tablet") {
      scaleDevice = { Google: 0.95, Facebook: 1.00, Instagram: 1.08, Email: 0.95, Direct: 0.95 };
    }

    let scaleProduct = 1.0;
    if (filters.product !== "all") scaleProduct = 0.26;

    channelStatsList = baseChannelModels.map(item => {
      const devMult = scaleDevice[item.channel as keyof typeof scaleDevice] || 1.0;
      const combinedScale = scaleTime * scaleRegion * devMult * scaleProduct;

      const traffic = Math.round(item.traffic * combinedScale);
      const orders = Math.round(item.orders * combinedScale);
      const revenue = Math.round(item.revenue * combinedScale);
      const spend = Math.round(item.spend * combinedScale);

      const conversion = traffic > 0 ? parseFloat(((orders / traffic) * 100).toFixed(2)) : 0;
      const roi = spend > 0 ? parseFloat((revenue / spend).toFixed(1)) : 0;

      return {
        channel: item.channel as any,
        traffic,
        orders,
        revenue,
        conversion,
        spend,
        roi
      };
    });
  }

  // ---------------------------------------------------------------------------
  // AUTO IDENTIFICATION MATRICES (Best and Worst Performing sources)
  // ---------------------------------------------------------------------------
  const totalTraffic = channelStatsList.reduce((acc, c) => acc + c.traffic, 0) || 1;
  const totalOrders = channelStatsList.reduce((acc, c) => acc + c.orders, 0) || 1;
  const totalRevenueSum = channelStatsList.reduce((acc, c) => acc + c.revenue, 0) || 1;
  const totalSpendSum = channelStatsList.reduce((acc, c) => acc + c.spend, 0) || 1;

  // Sorting engines to find leaders
  const rankedByRevenue = [...channelStatsList].sort((a, b) => b.revenue - a.revenue);
  const rankedByConversion = [...channelStatsList].sort((a, b) => b.conversion - a.conversion);
  const rankedByRoi = [...channelStatsList].filter(c => c.spend > 0).sort((a, b) => b.roi - a.roi);

  // Best Performing and Worst Performing selection models
  const bestByRevenue = rankedByRevenue[0];
  const worstByRevenue = rankedByRevenue[rankedByRevenue.length - 1];

  const bestByConversion = rankedByConversion[0];
  const worstByConversion = rankedByConversion[rankedByConversion.length - 1];

  const bestByRoi = rankedByRoi.length > 0 ? rankedByRoi[0] : null;

  // Colors mapping for charts to maintain professional visual style guidelines
  const CHANNEL_COLORS: Record<string, string> = {
    Google: "#6366f1",    // Indigo
    Facebook: "#3b82f6",  // Blue
    Instagram: "#06b6d4", // Cyan
    Email: "#10b981",     // Emerald
    Direct: "#f59e0b"     // Amber
  };

  const getChannelColor = (name: string) => {
    return CHANNEL_COLORS[name] || "#a1a1aa";
  };

  return (
    <div id="marketing-module-root" className="space-y-6">
      
      {/* Visual Header Grid row */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-gray-150 dark:border-zinc-850 pb-5">
        <div>
          <h2 className="text-xl font-extrabold text-gray-900 dark:text-white flex items-center gap-2 tracking-tight">
            <Share2 className="h-5.5 w-5.5 text-indigo-500 shrink-0" />
            <span>Traffic Source & Marketing Channel Analytics</span>
          </h2>
          <p className="text-xs text-gray-500 dark:text-zinc-400 mt-1 leading-normal">
            Analyze visitor acquisition paths, order volume contributions, conversion rates, and return on spend (ROI) dynamically mapped from {isSimulating ? "simulated models" : "your uploaded logs"}.
          </p>
        </div>

        {/* Global mode label status */}
        <div className="flex items-center gap-2">
          <span className={`text-[10px] uppercase tracking-wider font-extrabold px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-sm border ${
            isSimulating 
              ? "bg-amber-500/10 text-amber-650 dark:text-amber-400 border-amber-500/20" 
              : "bg-emerald-500/10 text-emerald-650 dark:text-emerald-400 border-emerald-500/20"
          }`}>
            <span className={`h-2 w-2 rounded-full ${isSimulating ? "bg-amber-500 animate-pulse" : "bg-emerald-500 animate-bounce"}`} />
            <span>{isSimulating ? "Demo Simulation Mode" : "Live Uploaded Dataset"}</span>
          </span>
        </div>
      </div>

      {/* -----------------------------------------------------------------------
          AUTOMATIC LEADER & DROP-OFF KPI MODULES (Best vs Worst channels)
          ----------------------------------------------------------------------- */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* LEADER SUITE CARD */}
        <div className="p-5 rounded-2xl border border-emerald-505/25 dark:border-emerald-950/20 bg-emerald-500/5 dark:bg-emerald-500/[0.02] flex flex-col justify-between space-y-4">
          <div className="flex justify-between items-start">
            <div className="flex items-center gap-2">
              <div className="h-9 w-9 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-500 shrink-0">
                <Flame className="h-5 w-5 animate-bounce" />
              </div>
              <div>
                <span className="text-[9px] font-black tracking-widest text-emerald-600 dark:text-emerald-400 uppercase font-mono block">Acquisition Champion</span>
                <h4 className="text-sm font-bold text-gray-900 dark:text-white mt-0.5">{bestByRevenue.channel} Referrer</h4>
              </div>
            </div>
            <span className="text-[10px] font-mono font-black bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 px-2 py-0.5 rounded">
              Leader by Revenue
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2 border-t border-b border-emerald-505/10 py-3 text-left">
            <div>
              <span className="block text-[9px] text-gray-400 font-bold uppercase">Attributed Revenue</span>
              <p className="text-base font-extrabold text-gray-900 dark:text-white font-mono mt-0.5">
                ${bestByRevenue.revenue.toLocaleString()}
              </p>
              <span className="text-[9px] text-gray-400 font-semibold">
                {((bestByRevenue.revenue / totalRevenueSum) * 100).toFixed(1)}% of total
              </span>
            </div>
            <div>
              <span className="block text-[9px] text-gray-400 font-bold uppercase">Conversion</span>
              <p className="text-base font-extrabold text-gray-900 dark:text-white font-mono mt-0.5">
                {bestByRevenue.conversion}%
              </p>
              <span className="text-[9px] text-emerald-500 font-bold flex items-center">
                <ArrowUpRight className="h-3 w-3" /> Peak rate
              </span>
            </div>
            <div>
              <span className="block text-[9px] text-gray-400 font-bold uppercase">ROI Efficiency</span>
              <p className="text-base font-extrabold text-gray-900 dark:text-white font-mono mt-0.5">
                {bestByRoi && bestByRoi.channel === bestByRevenue.channel ? `${bestByRevenue.roi}x` : `${bestByRevenue.roi}x ROAS`}
              </p>
              <span className="text-[9px] text-gray-400 font-semibold">
                {bestByRevenue.spend > 0 ? "Cost efficient" : "No paid spend"}
              </span>
            </div>
          </div>

          <p className="text-[11px] text-gray-500 dark:text-zinc-400 leading-relaxed italic border-l-2 border-emerald-500 pl-3">
            🎯 <strong>Insight:</strong> {bestByRevenue.channel} is the undisputed champion, driving maximum capital inflow. Focus on scaling the corresponding marketing operations, maintaining landing page fidelity, and amplifying high-impact creatives.
          </p>
        </div>

        {/* LAGGING WARNING CARD */}
        <div className="p-5 rounded-2xl border border-rose-500/25 dark:border-rose-955/20 bg-rose-500/5 dark:bg-rose-500/[0.02] flex flex-col justify-between space-y-4">
          <div className="flex justify-between items-start">
            <div className="flex items-center gap-2">
              <div className="h-9 w-9 rounded-xl bg-rose-500/10 flex items-center justify-center text-rose-500 shrink-0">
                <Frown className="h-5 w-5 animate-pulse" />
              </div>
              <div>
                <span className="text-[9px] font-black tracking-widest text-rose-600 dark:text-rose-400 uppercase font-mono block">Acquisition Bottleneck</span>
                <h4 className="text-sm font-bold text-gray-900 dark:text-white mt-0.5">{worstByRevenue.channel} Referrer</h4>
              </div>
            </div>
            <span className="text-[10px] font-mono font-black bg-rose-500/10 text-rose-600 dark:text-rose-400 px-2 py-0.5 rounded">
              Lowest Revenue Contributor
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2 border-t border-b border-rose-505/10 py-3 text-left">
            <div>
              <span className="block text-[9px] text-gray-400 font-bold uppercase">Attributed Revenue</span>
              <p className="text-base font-extrabold text-gray-900 dark:text-white font-mono mt-0.5">
                ${worstByRevenue.revenue.toLocaleString()}
              </p>
              <span className="text-[9px] text-gray-400 font-semibold animate-pulse">
                Just {((worstByRevenue.revenue / totalRevenueSum) * 100).toFixed(1)}% share
              </span>
            </div>
            <div>
              <span className="block text-[9px] text-gray-400 font-bold uppercase">Conversion</span>
              <p className="text-base font-extrabold text-gray-900 dark:text-white font-mono mt-0.5">
                {worstByRevenue.conversion}%
              </p>
              <span className="text-[9px] text-rose-500 font-bold flex items-center">
                <TrendingDown className="h-3 w-3" /> Needs optimization
              </span>
            </div>
            <div>
              <span className="block text-[9px] text-gray-400 font-bold uppercase">ROI Multiplier</span>
              <p className="text-base font-extrabold text-gray-900 dark:text-white font-mono mt-0.5">
                {worstByRevenue.roi > 0 ? `${worstByRevenue.roi}x` : "0.0x ROAS"}
              </p>
              <span className="text-[9px] text-gray-400 font-semibold">
                {worstByRevenue.spend > 0 ? `$${worstByRevenue.spend.toLocaleString()} spent` : "Direct navigation"}
              </span>
            </div>
          </div>

          <p className="text-[11px] text-gray-500 dark:text-zinc-400 leading-relaxed italic border-l-2 border-rose-500 pl-3">
            ⚠️ <strong>Action Plan:</strong> Low conversion highlights massive traffic leakages in checkout or pricing clarity. Optimize targeted landing interfaces, introduce exit-intent popups, and cut down underperforming audience brackets on paid accounts.
          </p>
        </div>

      </div>

      {/* -----------------------------------------------------------------------
          MAIN LEDGER DATA TABLE (Calculating the 5 exact request parameters)
          ----------------------------------------------------------------------- */}
      <div className="p-5 rounded-2xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 text-left">
        <div className="border-b border-gray-100 dark:border-zinc-805 pb-3 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
          <div>
            <h3 className="text-sm font-extrabold text-gray-900 dark:text-white flex items-center gap-1.5">
              <BarChart4 className="h-4 w-4 text-indigo-500" />
              <span>Attributed Referrer Master Ledger Matrix</span>
            </h3>
            <p className="text-[10px] text-gray-400 mt-0.5 font-sans">
              Consolidated calculations detailing absolute traffic, order conversions, total capital returns, and capital performance.
            </p>
          </div>
          <span className="text-[9.5px] font-mono text-indigo-650 bg-indigo-500/10 dark:text-indigo-400 font-extrabold p-1 px-2.5 rounded-full">
            Active Records Analyzed: {channelStatsList.reduce((acc, c) => acc + c.traffic, 0).toLocaleString()} visitors
          </span>
        </div>

        <div className="overflow-x-auto mt-4">
          <table className="w-full text-xs text-left border-collapse min-w-[700px]">
            <thead>
              <tr className="border-b border-gray-150 dark:border-zinc-800 text-[10px] text-gray-400 font-mono tracking-wider uppercase">
                <th scope="col" className="py-2.5 font-bold">Acquisition Source</th>
                <th scope="col" className="py-2.5 text-right font-bold">Traffic (Unique Sessions)</th>
                <th scope="col" className="py-2.5 text-right font-bold">Orders (Completed Sales)</th>
                <th scope="col" className="py-2.5 text-right font-bold">Revenue ($)</th>
                <th scope="col" className="py-2.5 text-right font-bold text-indigo-600 dark:text-indigo-400 font-extrabold">Conversion Rate (%)</th>
                <th scope="col" className="py-2.5 text-right font-bold text-emerald-600 dark:text-emerald-400 font-extrabold">Ad Spend &amp; ROAS (ROI)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-zinc-850 text-gray-700 dark:text-zinc-200 font-medium">
              {channelStatsList.map((stat, idx) => {
                const trafficShare = ((stat.traffic / totalTraffic) * 100).toFixed(1);
                const revenueShare = ((stat.revenue / totalRevenueSum) * 100).toFixed(1);

                return (
                  <tr key={idx} className="hover:bg-gray-55/40 dark:hover:bg-zinc-850/20 transition-colors">
                    <td className="py-3 px-1">
                      <div className="flex items-center gap-2">
                        <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: getChannelColor(stat.channel) }} />
                        <div>
                          <p className="font-extrabold text-gray-900 dark:text-white">{stat.channel}</p>
                          <span className="text-[9px] text-gray-400 block font-mono">Channel Node #{idx + 1}</span>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 text-right">
                      <p className="font-bold text-gray-900 dark:text-white font-mono">{stat.traffic.toLocaleString()}</p>
                      <span className="text-[9px] text-gray-400 font-semibold">{trafficShare}% of sessions</span>
                    </td>
                    <td className="py-3 text-right font-bold text-gray-800 dark:text-zinc-350 font-mono">
                      {stat.orders.toLocaleString()}
                    </td>
                    <td className="py-3 text-right">
                      <p className="font-extrabold text-gray-900 dark:text-white font-mono">${stat.revenue.toLocaleString()}</p>
                      <span className="text-[9px] text-gray-400 font-semibold">{revenueShare}% of revenue</span>
                    </td>
                    <td className="py-3 text-right">
                      <div className="inline-block text-right">
                        <span className="font-extrabold font-mono text-indigo-600 dark:text-indigo-400 text-sm">
                          {stat.conversion}%
                        </span>
                        <div className="w-16 bg-gray-100 dark:bg-zinc-800 h-1.5 rounded-full mt-1 overflow-hidden ml-auto">
                          <div 
                            className="bg-indigo-500 h-1.5 rounded-full" 
                            style={{ width: `${Math.min(100, stat.conversion * 12)}%` }} 
                          />
                        </div>
                      </div>
                    </td>
                    <td className="py-3 text-right">
                      {stat.spend > 0 ? (
                        <div>
                          <p className="font-extrabold text-emerald-600 dark:text-emerald-400 font-mono text-sm leading-none">
                            {stat.roi}x ROI
                          </p>
                          <span className="text-[9px] text-gray-450 mt-1 block">
                            Cost: ${stat.spend.toLocaleString()} (${((stat.spend / totalSpendSum) * 100).toFixed(0)}% ad budget)
                          </span>
                        </div>
                      ) : (
                        <div>
                          <p className="font-black text-amber-500 font-mono text-xs leading-none">
                            Organic (Free)
                          </p>
                          <span className="text-[8.5px] text-amber-600 dark:text-amber-400 font-semibold mt-1 block bg-amber-500/10 rounded px-1 text-center font-mono">
                            100% margin return
                          </span>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* -----------------------------------------------------------------------
          MODERN BENTO GRID FOR SUPPORTED VISUALIZATION CHARTS
          ----------------------------------------------------------------------- */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <h3 className="text-sm font-extrabold text-gray-900 dark:text-white flex items-center gap-2">
              <TrendingUpIcon className="h-4.5 w-4.5 text-indigo-500" />
              <span>Channel Comparison, Revenue, &amp; Conversion Analytics</span>
            </h3>
            <p className="text-[10px] text-gray-400 mt-0.5">Plot visitor trends, total sales distribution, and individual ROI multipliers.</p>
          </div>

          {/* Tab/Layout Controls */}
          <div className="flex bg-gray-100 dark:bg-zinc-850 p-0.5 rounded-lg border border-gray-200/50 dark:border-zinc-800 text-[10px] font-bold shadow-xs">
            <button
              onClick={() => setLayoutMode("grid")}
              className={`px-3 py-1.5 rounded-md transition-all ${
                layoutMode === "grid"
                  ? "bg-indigo-600 text-white font-black shadow-xs"
                  : "text-gray-500 hover:text-gray-900 dark:text-zinc-400 dark:hover:text-zinc-200"
              }`}
            >
              All Charts (Bento Matrix)
            </button>
            <button
              onClick={() => setLayoutMode("comparison")}
              className={`px-3 py-1.5 rounded-md transition-all ${
                layoutMode === "comparison"
                  ? "bg-indigo-600 text-white font-black shadow-xs"
                  : "text-gray-500 hover:text-gray-900 dark:text-zinc-400 dark:hover:text-zinc-200"
              }`}
            >
              Traffic Comparison
            </button>
            <button
              onClick={() => setLayoutMode("revenue")}
              className={`px-3 py-1.5 rounded-md transition-all ${
                layoutMode === "revenue"
                  ? "bg-indigo-600 text-white font-black shadow-xs"
                  : "text-gray-500 hover:text-gray-900 dark:text-zinc-400 dark:hover:text-zinc-200"
              }`}
            >
              Revenue Mix
            </button>
            <button
              onClick={() => setLayoutMode("conversion")}
              className={`px-3 py-1.5 rounded-md transition-all ${
                layoutMode === "conversion"
                  ? "bg-indigo-600 text-white font-black shadow-xs"
                  : "text-gray-500 hover:text-gray-900 dark:text-zinc-400 dark:hover:text-zinc-200"
              }`}
            >
              Conversion Rates
            </button>
          </div>
        </div>

        {/* Dynamic Layout Visualizer */}
        <div className={`grid gap-6 ${layoutMode === "grid" ? "grid-cols-1 lg:grid-cols-3" : "grid-cols-1"}`}>
          
          {/* CHART 1: SOURCE COMPARISON CHART (Traffic & Orders) */}
          {(layoutMode === "grid" || layoutMode === "comparison") && (
            <div className={`p-5 rounded-2xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 flex flex-col justify-between ${layoutMode !== "grid" && "h-96"}`}>
              <div className="border-b border-gray-100 dark:border-zinc-805 pb-3">
                <span className="text-[9px] uppercase tracking-wider font-extrabold font-mono text-sky-502 bg-sky-500/10 px-2 py-0.5 rounded">
                  Traffic vs Orders Index
                </span>
                <h4 className="text-xs font-extrabold text-gray-900 dark:text-white mt-1.5">1. Source Comparison Chart</h4>
                <p className="text-[9px] text-gray-400 mt-0.5">Sessions (Visits) compared to Completed Transactions.</p>
              </div>

              <div className="h-64 my-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={channelStatsList} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(120, 120, 120, 0.08)" />
                    <XAxis dataKey="channel" style={{ fontSize: 9, fill: "#888", fontWeight: "bold" }} tickLine={false} />
                    <YAxis yAxisId="left" style={{ fontSize: 9, fill: "#888" }} tickLine={false} label={{ value: 'Sessions', angle: -90, position: 'insideLeft', offset: 0, style: { fontSize: 8, fill: '#aaa' } }} />
                    <YAxis yAxisId="right" orientation="right" style={{ fontSize: 9, fill: "#888" }} tickLine={false} label={{ value: 'Orders', angle: 90, position: 'insideRight', offset: 10, style: { fontSize: 8, fill: '#aaa' } }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "rgba(10, 10, 10, 0.95)",
                        border: "1px solid rgba(80, 80, 80, 0.2)",
                        borderRadius: 12,
                        fontSize: 10,
                        color: "#fff"
                      }}
                      formatter={(value: any, name: string) => {
                        return [value.toLocaleString(), name === "traffic" ? "Sessions" : "Orders"];
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: 9 }} />
                    <Bar yAxisId="left" dataKey="traffic" fill="#3b82f6" radius={[4, 4, 0, 0]} name="Sessions" />
                    <Bar yAxisId="right" dataKey="orders" fill="#f59e0b" radius={[4, 4, 0, 0]} name="Orders" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <p className="text-[10px] text-gray-400 italic text-center font-mono pt-2 border-t border-gray-100 dark:border-zinc-800">
                💡 High Traffic with low order ratios points directly to channel audience mismatch.
              </p>
            </div>
          )}

          {/* CHART 2: REVENUE DISTRIBUTION CHART (Absolute revenues by channel) */}
          {(layoutMode === "grid" || layoutMode === "revenue") && (
            <div className={`p-5 rounded-2xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 flex flex-col justify-between ${layoutMode !== "grid" && "h-96"}`}>
              <div className="border-b border-gray-100 dark:border-zinc-805 pb-3">
                <span className="text-[9px] uppercase tracking-wider font-extrabold font-mono text-emerald-552 bg-emerald-500/10 px-2 py-0.5 rounded">
                  Absolute Sales Contribution
                </span>
                <h4 className="text-xs font-extrabold text-gray-900 dark:text-white mt-1.5">2. Revenue Charts By Source</h4>
                <p className="text-[9px] text-gray-400 mt-0.5 font-sans">Dynamic contribution sizing of each acquisition node.</p>
              </div>

              <div className="h-64 my-4 flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={channelStatsList} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.4}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(120, 120, 120, 0.08)" />
                    <XAxis dataKey="channel" style={{ fontSize: 9, fill: "#888", fontWeight: "bold" }} tickLine={false} />
                    <YAxis style={{ fontSize: 9, fill: "#888" }} tickLine={false} tickFormatter={(val) => `$${val}`} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "rgba(10, 10, 10, 0.95)",
                        border: "1px solid rgba(80, 80, 80, 0.2)",
                        borderRadius: 12,
                        fontSize: 10,
                        color: "#fff"
                      }}
                      formatter={(value: any) => [`$${value.toLocaleString()}`, "Attributed Revenue"]}
                    />
                    <Area type="monotone" dataKey="revenue" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorRevenue)" name="Gross Sales" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              <p className="text-[10px] text-gray-400 italic text-center font-mono pt-2 border-t border-gray-100 dark:border-zinc-800">
                💰 Attributing exact purchase revenues directly aids ROAS scaling.
              </p>
            </div>
          )}

          {/* CHART 3: CONVERSION & ROI COMPOSITE MATRIX (Efficiencies mapping) */}
          {(layoutMode === "grid" || layoutMode === "conversion") && (
            <div className={`p-5 rounded-2xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 flex flex-col justify-between ${layoutMode !== "grid" && "h-96"}`}>
              <div className="border-b border-gray-100 dark:border-zinc-805 pb-3">
                <span className="text-[9px] uppercase tracking-wider font-extrabold font-mono text-indigo-552 bg-indigo-500/10 px-2 py-0.5 rounded">
                  Acquisition Efficiencies Index
                </span>
                <h4 className="text-xs font-extrabold text-gray-900 dark:text-white mt-1.5">3. Conversion &amp; ROI Charts</h4>
                <p className="text-[9px] text-gray-400 mt-0.5">Correlation mapping of Conversion rates and ROAS multipliers.</p>
              </div>

              <div className="h-64 my-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={channelStatsList} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(120, 120, 120, 0.08)" />
                    <XAxis dataKey="channel" style={{ fontSize: 9, fill: "#888", fontWeight: "bold" }} tickLine={false} />
                    <YAxis yAxisId="left" style={{ fontSize: 9, fill: "#888" }} tickLine={false} label={{ value: 'Conversion Rate %', angle: -90, position: 'insideLeft', offset: 0, style: { fontSize: 8, fill: '#aaa' } }} />
                    <YAxis yAxisId="right" orientation="right" style={{ fontSize: 9, fill: "#888" }} tickLine={false} label={{ value: 'ROI (Multiplier)', angle: 90, position: 'insideRight', offset: 10, style: { fontSize: 8, fill: '#aaa' } }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "rgba(10, 10, 10, 0.95)",
                        border: "1px solid rgba(80, 80, 80, 0.2)",
                        borderRadius: 12,
                        fontSize: 10,
                        color: "#fff"
                      }}
                      formatter={(value: any, name: string) => {
                        return [value, name === "conversion" ? "Conversion %" : "ROI Multiplier"];
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: 9 }} />
                    <Bar yAxisId="left" dataKey="conversion" fill="#6366f1" radius={[4, 4, 0, 0]} name="conversion" />
                    <Bar yAxisId="right" dataKey="roi" fill="#06b6d4" radius={[4, 4, 0, 0]} name="roi" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <p className="text-[10px] text-gray-400 italic text-center font-mono pt-2 border-t border-gray-100 dark:border-zinc-800">
                💎 Higher conversion rate paired with higher ROI warrants massive scaling.
              </p>
            </div>
          )}

        </div>
      </div>

      {/* -----------------------------------------------------------------------
          AI HEURISTIC INSIGHTS MATRIX CARDS
          ----------------------------------------------------------------------- */}
      <div className="p-5 rounded-2xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 text-left">
        <h3 className="text-sm font-extrabold text-gray-900 dark:text-white border-b border-gray-100 dark:border-zinc-805 pb-3 flex items-center gap-2">
          <Lightbulb className="h-4.5 w-4.5 text-indigo-500" />
          <span>Dynamic Traffic Insights &amp; Operational Directives</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
          
          {/* Email Insights */}
          {(() => {
            const emailStat = channelStatsList.find(c => c.channel === "Email");
            if (!emailStat) return null;
            return (
              <div className="p-4 rounded-xl border border-gray-100 dark:border-zinc-800 bg-gray-50/20 dark:bg-zinc-900/30 flex flex-col justify-between">
                <div>
                  <div className="h-6.5 w-6.5 bg-emerald-500/10 text-emerald-500 text-[10px] font-bold rounded-lg flex items-center justify-center font-mono">
                    EM
                  </div>
                  <h4 className="text-xs font-bold text-gray-900 dark:text-white mt-2">Email Optimization Hub</h4>
                  <p className="text-[10.5px] text-gray-500 dark:text-zinc-400 mt-1 leading-normal">
                    Email converts beautifully at <strong className="text-emerald-500">{emailStat.conversion}%</strong> yielding an impressive <strong className="text-emerald-500">{emailStat.roi}x</strong> cost return.
                  </p>
                </div>
                <p className="text-[9.5px] text-indigo-600 dark:text-indigo-400 font-bold tracking-tight mt-3">
                  👉 Standardize weekly retention newsletters and exit-intent capture popups.
                </p>
              </div>
            );
          })()}

          {/* Social Spend Performance */}
          {(() => {
            const fb = channelStatsList.find(c => c.channel === "Facebook");
            const ig = channelStatsList.find(c => c.channel === "Instagram");
            const totalSocialRevenue = (fb?.revenue || 0) + (ig?.revenue || 0);
            const totalSocialTraffic = (fb?.traffic || 0) + (ig?.traffic || 0) || 1;
            const avgSocialCr = parseFloat((( ((fb?.orders || 0) + (ig?.orders || 0)) / totalSocialTraffic ) * 100).toFixed(2));

            return (
              <div className="p-4 rounded-xl border border-gray-100 dark:border-zinc-800 bg-gray-50/20 dark:bg-zinc-900/30 flex flex-col justify-between">
                <div>
                  <div className="h-6.5 w-6.5 bg-cyan-500/10 text-cyan-500 text-[10px] font-bold rounded-lg flex items-center justify-center font-mono">
                    SC
                  </div>
                  <h4 className="text-xs font-bold text-gray-900 dark:text-white mt-2">Paid Social Funnel Leakage</h4>
                  <p className="text-[10.5px] text-gray-500 dark:text-zinc-400 mt-1 leading-normal">
                    Facebook + Instagram drive <strong className="text-gray-800 dark:text-white">${totalSocialRevenue.toLocaleString()}</strong> in gross transactions, with a combined aggregate conversion efficiency of <strong>{avgSocialCr}%</strong>.
                  </p>
                </div>
                <p className="text-[9.5px] text-indigo-600 dark:text-indigo-400 font-bold tracking-tight mt-3">
                  👉 Deploy social-tailored micro-landing pages and 1-click checkout buttons.
                </p>
              </div>
            );
          })()}

          {/* Google Search insights */}
          {(() => {
            const google = channelStatsList.find(c => c.channel === "Google");
            if (!google) return null;
            return (
              <div className="p-4 rounded-xl border border-gray-100 dark:border-zinc-800 bg-gray-50/20 dark:bg-zinc-900/30 flex flex-col justify-between">
                <div>
                  <div className="h-6.5 w-6.5 bg-indigo-500/10 text-indigo-500 text-[10px] font-bold rounded-lg flex items-center justify-center font-mono">
                    GO
                  </div>
                  <h4 className="text-xs font-bold text-gray-900 dark:text-white mt-2">Organic Capture Expansion</h4>
                  <p className="text-[10.5px] text-gray-500 dark:text-zinc-400 mt-1 leading-normal">
                    Organic and paid Google referrers total <strong className="text-indigo-600 dark:text-indigo-400">{google.traffic.toLocaleString()}</strong> sessions, yielding a conversion score of <strong>{google.conversion}%</strong>.
                  </p>
                </div>
                <p className="text-[9.5px] text-indigo-600 dark:text-indigo-400 font-bold tracking-tight mt-3">
                  👉 Build tailored blogs on top-ranking queries to boost high-intent search volumes.
                </p>
              </div>
            );
          })()}

          {/* Direct retention insights */}
          {(() => {
            const direct = channelStatsList.find(c => c.channel === "Direct");
            if (!direct) return null;
            return (
              <div className="p-4 rounded-xl border border-gray-100 dark:border-zinc-800 bg-gray-50/20 dark:bg-zinc-900/30 flex flex-col justify-between">
                <div>
                  <div className="h-6.5 w-6.5 bg-amber-500/10 text-amber-500 text-[10px] font-bold rounded-lg flex items-center justify-center font-mono">
                    DR
                  </div>
                  <h4 className="text-xs font-bold text-gray-900 dark:text-white mt-2">Direct &amp; Organic Directives</h4>
                  <p className="text-[10.5px] text-gray-500 dark:text-zinc-400 mt-1 leading-normal">
                    Direct visits account for <strong>{((direct.traffic / totalTraffic) * 100).toFixed(1)}%</strong> of session volume, holding a checkout return of <strong>${direct.revenue.toLocaleString()}</strong>.
                  </p>
                </div>
                <p className="text-[9.5px] text-indigo-600 dark:text-indigo-400 font-bold tracking-tight mt-3">
                  👉 Retain customer recall through automatic checkout follow-ups and points triggers.
                </p>
              </div>
            );
          })()}

        </div>
      </div>

    </div>
  );
}
