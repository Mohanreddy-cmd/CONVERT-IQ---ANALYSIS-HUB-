import { useState, useEffect } from "react";
import {
  TrendingUp,
  AlertTriangle,
  DollarSign,
  ArrowRight,
  TrendingDown,
  ShoppingBag,
  Smartphone,
  Lightbulb,
  Filter,
  Calendar,
  Globe,
  Monitor,
  Layers,
  ArrowDownRight,
  Sparkles,
  RefreshCw
} from "lucide-react";
import { UnifiedMetrics, GlobalFilters, IngestedRecord } from "../types";
import CartAbandonmentIntelligence from "./CartAbandonmentIntelligence";

interface ConversionAnalyticsProps {
  metrics: UnifiedMetrics;
  filters: GlobalFilters;
  setFilters: (filters: GlobalFilters) => void;
  isSimulating: boolean;
  uploadedData: IngestedRecord[];
}

export default function ConversionAnalytics({
  metrics,
  filters,
  setFilters,
  isSimulating,
  uploadedData
}: ConversionAnalyticsProps) {
  const [activeSubTab, setActiveSubTab] = useState<"funnel" | "abandonment">("funnel");
  const [activeRecommendationIndex, setActiveRecommendationIndex] = useState(0);
  const [plotlyLoaded, setPlotlyLoaded] = useState(false);
  const [isChartRendering, setIsChartRendering] = useState(false);

  // Custom filter options for funnel controls
  const dateOptions = [
    { value: "30d", label: "Last 30 Days" },
    { value: "7d", label: "Last 7 Days" },
    { value: "90d", label: "Last 90 Days" }
  ];

  const deviceOptions = [
    { value: "all", label: "All Devices" },
    { value: "Desktop", label: "Desktop Key Terminals" },
    { value: "Mobile", label: "Mobile Browsers" },
    { value: "Tablet", label: "Tablet Displays" }
  ];

  const productOptions = [
    { value: "all", label: "All Catalog Products" },
    { value: "Starlight Pro", label: "Starlight Pro Headphones" },
    { value: "Aura Leather", label: "Aura Leather Bag" },
    { value: "Sonic Wave", label: "Sonic Wave Speakers" },
    { value: "Titan Fit", label: "Titan Fit Smartwatch" }
  ];

  const channelOptions = [
    { value: "all", label: "All Referral Sources" },
    { value: "Google Organic", label: "Google Organic Search" },
    { value: "Meta Social", label: "Meta Advertisements" },
    { value: "Influencer", label: "Instagram Influencers" },
    { value: "Email Campaign", label: "Klaviyo Newsletters" }
  ];

  // Dynamic calculations based on metrics
  const totalSessions = metrics.funnelData && metrics.funnelData[0] ? metrics.funnelData[0].value : 0;
  const totalPurchases = metrics.funnelData && metrics.funnelData[metrics.funnelData.length - 1] 
    ? metrics.funnelData[metrics.funnelData.length - 1].value 
    : 0;

  const funnelConversionRate = totalSessions > 0 
    ? parseFloat(((totalPurchases / totalSessions) * 100).toFixed(2)) 
    : 0;

  // Aggregate total theoretical revenue leakage across all stages
  const totalLeakage = metrics.funnelData 
    ? metrics.funnelData.reduce((sum, item) => sum + (item.revenueLeakage || 0), 0) 
    : 0;

  // Detect the bottleneck stage (highest drop-off rate)
  let maxDropoffStage = "Product Views";
  let maxDropoffValue = 0;
  if (metrics.funnelData && metrics.funnelData.length > 0) {
    metrics.funnelData.forEach((st, idx) => {
      if (idx > 0 && st.dropoff > maxDropoffValue) {
        maxDropoffValue = st.dropoff;
        maxDropoffStage = st.stage;
      }
    });
  }

  // Load Plotly CDN Dynamically
  useEffect(() => {
    if ((window as any).Plotly) {
      setPlotlyLoaded(true);
      return;
    }

    setIsChartRendering(true);
    const script = document.createElement("script");
    script.src = "https://cdn.plot.ly/plotly-2.24.1.min.js";
    script.async = true;
    script.onload = () => {
      setPlotlyLoaded(true);
      setIsChartRendering(false);
    };
    script.onerror = () => {
      console.error("Failed to load Plotly script from official CDN.");
      setIsChartRendering(false);
    };
    document.head.appendChild(script);
  }, []);

  // Draw/Redraw Plotly Funnel Chart on metric updates, filters or DOM changes
  useEffect(() => {
    if (!plotlyLoaded || !metrics.funnelData || metrics.funnelData.length === 0) return;

    const isDark = document.documentElement.classList.contains("dark");

    const stages = [...metrics.funnelData].map(f => f.stage).reverse();
    const values = [...metrics.funnelData].map(f => f.value).reverse();

    const trace = {
      type: 'funnel',
      y: stages,
      x: values,
      textinfo: "value+percent initial",
      hoverinfo: "x+percent previous+percent initial",
      marker: {
        color: ["#6366f1", "#4f46e5", "#2563eb", "#0ea5e9", "#06b6d5"],
        line: {
          width: [1, 1, 1, 1, 1],
          color: isDark ? "#18181b" : "#ffffff"
        }
      },
      connector: {
        fillcolor: isDark ? "rgba(63, 63, 70, 0.15)" : "rgba(228, 228, 231, 0.4)",
        line: { color: isDark ? "rgba(113, 113, 122, 0.3)" : "rgba(161, 161, 170, 0.3)", width: 1 }
      }
    };

    const layout = {
      margin: { l: 140, r: 35, b: 25, t: 15 },
      paper_bgcolor: 'transparent',
      plot_bgcolor: 'transparent',
      font: {
        color: isDark ? '#cbd5e1' : '#374151',
        family: 'Inter, system-ui, sans-serif',
        size: 10
      },
      showlegend: false,
      autosize: true
    };

    const config = {
      responsive: true,
      displayModeBar: false
    };

    const plotElement = document.getElementById('plotly-funnel-canvas');
    if (plotElement && (window as any).Plotly) {
      try {
        (window as any).Plotly.newPlot('plotly-funnel-canvas', [trace], layout, config);
      } catch (err) {
        console.error("Plotly error generating funnel plot:", err);
      }
    }

    const handleResize = () => {
      const el = document.getElementById('plotly-funnel-canvas');
      if (el && (window as any).Plotly) {
        (window as any).Plotly.Plots.resize(el);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [plotlyLoaded, metrics.funnelData, filters]);

  // Product leakage list (simulated baseline adjusted dynamically if product filter matches)
  const productLeakers = [
    { name: "Aura Leather Messenger Bag", rate: "78.4%", cashAbandoned: Math.round(totalLeakage * 0.45) },
    { name: "Starlight Pro Wireless Headphones", rate: "54.2%", cashAbandoned: Math.round(totalLeakage * 0.28) },
    { name: "Titan Fit Waterproof Smartwatch", rate: "48.1%", cashAbandoned: Math.round(totalLeakage * 0.18) }
  ].filter(prod => {
    if (filters.product === "all") return true;
    return prod.name.toLowerCase().includes(filters.product.toLowerCase());
  });

  const dynamicDirectives = [
    {
      title: "Optimizing the Checkout Gateway",
      impact: "+5.4% Checkout Conversion Boost",
      cost: "Zero core capital requirements",
      guide: "Our funnel data shows that surprising taxes or added shipping costs are driving high drop-offs before checkout is completed. Upfront flat-rate visibility resolves this."
    },
    {
      title: "Implement One-Click Mobile Payment Methods",
      impact: "+18.2% Mobile conversion scaling",
      cost: "Easy payment gateway SDK integration",
      guide: "Mobile terminals hold high session volume but feature lower conversion rates. Integrating digital wallets (Apple Pay, Google Pay) bypasses tedious card inputs."
    }
  ];

  const formatCurrency = (val: number) => {
    if (val >= 1000000) return `$${(val / 1000000).toFixed(2)}M`;
    if (val >= 1000) return `$${(val / 1000).toFixed(1)}k`;
    return `$${val.toLocaleString()}`;
  };

  return (
    <div id="conversion-analytics-root" className="space-y-6">
      
      {/* 1. Header and Explanation */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-gray-150 dark:border-zinc-800/80 pb-4">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <Layers className="h-5 w-5 text-indigo-500" />
            Conversion & Cart Intelligence
          </h2>
          <p className="text-xs text-gray-500 dark:text-zinc-400 mt-1">
            Track user checkouts, identify drop-off leakages, and explore active cart abandonment diagnostics.
          </p>
        </div>

        {/* Dynamic sub tab controllers */}
        <div className="flex bg-gray-100 dark:bg-zinc-900 p-1 rounded-xl text-xs font-semibold self-stretch md:self-auto shadow-xs border border-gray-200/30 dark:border-zinc-800">
          <button
            onClick={() => setActiveSubTab("funnel")}
            className={`flex items-center gap-2 p-2 px-4 rounded-lg transition-all ${
              activeSubTab === "funnel"
                ? "bg-white dark:bg-zinc-800 text-indigo-600 dark:text-cyan-400 font-bold shadow-xs"
                : "text-gray-500 dark:text-zinc-400 hover:text-gray-800 dark:hover:text-zinc-200"
            }`}
          >
            <Layers className="h-4 w-4" />
            <span>Interactive Funnel</span>
          </button>
          <button
            onClick={() => setActiveSubTab("abandonment")}
            className={`flex items-center gap-2 p-2 px-4 rounded-lg transition-all ${
              activeSubTab === "abandonment"
                ? "bg-white dark:bg-zinc-800 text-indigo-655 dark:text-cyan-400 font-bold shadow-xs"
                : "text-gray-500 dark:text-zinc-400 hover:text-gray-800 dark:hover:text-zinc-200"
            }`}
          >
            <TrendingDown className="h-4 w-4 text-rose-500" />
            <span>Cart Abandonment Intel</span>
          </button>
        </div>
      </div>

      {activeSubTab === "funnel" ? (
        <>
          {/* 2. Interactive Filter Bar */}
          <div className="p-4 rounded-xl bg-white dark:bg-zinc-900 border border-gray-200/50 dark:border-zinc-800 space-y-3 shadow-xs">
            <div className="flex items-center gap-2 text-[10px] font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
              <Filter className="h-3.5 w-3.5" />
              <span>Interactive Funnel Filters</span>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
              {/* Date Selector */}
              <div>
                <label className="block text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase mb-1">Date Interval</label>
                <select
                  id="funnel-filter-date"
                  value={filters.dateRange}
                  onChange={(e) => setFilters({ ...filters, dateRange: e.target.value })}
                  className="w-full text-xs font-semibold rounded-xl bg-gray-50 border border-gray-200 dark:border-zinc-850 dark:bg-zinc-850 p-2 text-gray-700 dark:text-zinc-200 focus:outline-none focus:border-indigo-500 transition-colors"
                >
                  {dateOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </div>

              {/* Product Selector */}
              <div>
                <label className="block text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase mb-1">Catalog Node</label>
                <select
                  id="funnel-filter-product"
                  value={filters.product}
                  onChange={(e) => setFilters({ ...filters, product: e.target.value })}
                  className="w-full text-xs font-semibold rounded-xl bg-gray-50 border border-gray-200 dark:border-zinc-850 dark:bg-zinc-850 p-2 text-gray-700 dark:text-zinc-200 focus:outline-none focus:border-indigo-500 transition-colors"
                >
                  {productOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </div>

              {/* Traffic Source Selector */}
              <div>
                <label className="block text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase mb-1">Acquisition Source</label>
                <select
                  id="funnel-filter-channel"
                  value={filters.channel}
                  onChange={(e) => setFilters({ ...filters, channel: e.target.value })}
                  className="w-full text-xs font-semibold rounded-xl bg-gray-50 border border-gray-200 dark:border-zinc-850 dark:bg-zinc-850 p-2 text-gray-700 dark:text-zinc-200 focus:outline-none focus:border-indigo-500 transition-colors"
                >
                  {channelOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </div>

              {/* Device Type Selector */}
              <div>
                <label className="block text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase mb-1">Traffic Terminal</label>
                <select
                  id="funnel-filter-device"
                  value={filters.device}
                  onChange={(e) => setFilters({ ...filters, device: e.target.value })}
                  className="w-full text-xs font-semibold rounded-xl bg-gray-50 border border-gray-200 dark:border-zinc-850 dark:bg-zinc-850 p-2 text-gray-700 dark:text-zinc-200 focus:outline-none focus:border-indigo-500 transition-colors"
                >
                  {deviceOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </div>
            </div>
          </div>

          {/* 3. Executive KPI Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Full Funnel Conversion Rate */}
            <div className="p-4 rounded-xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-wider block">Global Journey Conversion</span>
                <p className="text-2xl font-black text-indigo-600 dark:text-indigo-400 tracking-tight mt-1">{funnelConversionRate}%</p>
              </div>
              <p className="text-[10px] text-gray-400 mt-2">
                Net session-to-purchase completion percentage.
              </p>
            </div>

            {/* Estimated Volume Leakage */}
            <div className="p-4 rounded-xl border border-rose-200/40 dark:border-rose-950/20 bg-rose-55/15 dark:bg-rose-950/5 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-bold text-rose-600 dark:text-rose-450 uppercase tracking-wider block">Theoretical Leakage Loss</span>
                <p className="text-2xl font-black text-rose-500 tracking-tight mt-1">{formatCurrency(totalLeakage)}</p>
              </div>
              <p className="text-[10px] text-gray-455 dark:text-zinc-500 mt-2">
                Sum of total unconverted session drop-offs valued at AOV (${metrics.aov.toFixed(1)}).
              </p>
            </div>

            {/* Maximum Drop-off Stage */}
            <div className="p-4 rounded-xl border border-amber-200/40 dark:border-amber-950/20 bg-amber-55/15 dark:bg-amber-950/5 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-bold text-amber-600 dark:text-amber-450 uppercase tracking-wider block font-medium">Critical Funnel Bottleneck</span>
                <p className="text-base font-black text-gray-800 dark:text-zinc-200 mt-1 leading-tight">{maxDropoffStage}</p>
              </div>
              <div className="flex justify-between items-center mt-2">
                <span className="text-[10px] text-amber-555 font-bold font-mono">{maxDropoffValue}% Drop</span>
                <span className="text-[9px] text-gray-400 uppercase font-semibold">Highest friction stage</span>
              </div>
            </div>

            {/* Reclaimable Retention Goal */}
            <div className="p-4 rounded-xl border border-emerald-250/30 dark:border-emerald-950/25 bg-emerald-55/15 dark:bg-emerald-950/5 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-450 uppercase tracking-wider block">15% Optimization Recovery</span>
                <p className="text-2xl font-black text-emerald-600 dark:text-emerald-450 mt-1">{formatCurrency(totalLeakage * 0.15)}</p>
              </div>
              <p className="text-[10px] text-gray-400 mt-2">
                Recapturing 15% of cart/checkout friction yields this lost capital.
              </p>
            </div>
          </div>

          {/* 4. Plotly Map & Directives Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Interactive Plotly Funnel Chart (2 Columns) */}
            <div className="lg:col-span-2 p-5 rounded-2xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 flex flex-col justify-between">
              <div className="border-b border-gray-100 dark:border-zinc-800/80 pb-3 flex justify-between items-center">
                <div>
                  <h3 className="text-sm font-bold text-gray-900 dark:text-white">Active Conversion Funnel (Plotly Trace)</h3>
                  <p className="text-[10px] text-gray-400 mt-0.5">Horizontal funnel trace documenting traffic scaling through to successful customer purchases.</p>
                </div>
                
                {isChartRendering && (
                  <span className="text-[10px] font-mono text-gray-400 flex items-center gap-1">
                    <RefreshCw className="h-3 w-3 animate-spin text-indigo-500" />
                    Rendering...
                  </span>
                )}
              </div>

              <div className="my-2 relative overflow-hidden flex items-center justify-center min-h-[320px]">
                {/* The Plotly canvas target */}
                <div id="plotly-funnel-canvas" className="w-full h-80 min-h-[320px]" />
                
                {/* Fallback loader when CDN is slow */}
                {!plotlyLoaded && (
                  <div className="absolute inset-0 bg-white/70 dark:bg-zinc-900/70 flex flex-col items-center justify-center gap-2">
                    <RefreshCw className="h-8 w-8 animate-spin text-indigo-500" />
                    <span className="text-[11px] font-bold text-gray-500 dark:text-zinc-400 font-mono">Loading plot libraries...</span>
                  </div>
                )}
              </div>

              <p className="text-[9.5px] text-gray-400 italic text-center font-mono">
                * Use standard hover to inspect detailed step-to-step drop-offs, cumulative conversion, and counts.
              </p>
            </div>

            {/* Side Panel Recommendations and Lost Opportunities (1 Column) */}
            <div className="space-y-6">
              
              {/* Detailed Product Leakage Losses */}
              <div className="p-4 rounded-xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 text-left">
                <h3 className="text-xs font-black text-gray-955 dark:text-white border-b border-gray-150 dark:border-zinc-800/80 pb-3 flex items-center gap-2">
                  <ShoppingBag className="h-4 w-4 text-rose-500" />
                  <span>Catalog Ingestion Leaks</span>
                </h3>

                <div className="mt-3 space-y-3.5">
                  {productLeakers.length > 0 ? (
                    productLeakers.slice(0, 4).map((pro, pIdx) => (
                      <div key={pIdx} className="flex justify-between items-center text-xs">
                        <div className="min-w-0 pr-2">
                          <p className="font-semibold text-gray-800 dark:text-zinc-200 truncate">{pro.name}</p>
                          <span className="text-[10px] text-gray-400">Calculated Drop Loss: <strong className="font-bold text-rose-500">{formatCurrency(pro.cashAbandoned)}</strong></span>
                        </div>
                        <span className="text-[10px] shrink-0 font-bold text-rose-500 bg-rose-500/10 px-2 py-0.5 rounded font-mono">
                          {pro.rate} abandon
                        </span>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-4 text-[11px] text-gray-400">
                      No leakages matched for filter "{filters.product}".
                    </div>
                  )}
                </div>
              </div>

              {/* Interactive Conversion Directives */}
              <div className="p-4 rounded-xl border border-indigo-200/55 dark:border-indigo-900/40 bg-gradient-to-br from-indigo-50/10 to-transparent dark:from-indigo-950/10 dark:to-transparent text-left">
                <div className="flex justify-between items-center border-b border-gray-150 dark:border-zinc-800 pb-3">
                  <h3 className="text-xs font-black text-indigo-700 dark:text-indigo-400 flex items-center gap-1.5 uppercase tracking-wider">
                    <Lightbulb className="h-4 w-4 text-indigo-505" />
                    <span>Smart directive</span>
                  </h3>
                  <div className="flex gap-1.5">
                    <button
                      onClick={() => setActiveRecommendationIndex(0)}
                      className={`h-2 w-2 rounded-full transition-all ${activeRecommendationIndex === 0 ? "bg-indigo-500 w-3.5" : "bg-gray-300 dark:bg-zinc-700"}`}
                    />
                    <button
                      onClick={() => setActiveRecommendationIndex(1)}
                      className={`h-2 w-2 rounded-full transition-all ${activeRecommendationIndex === 1 ? "bg-indigo-500 w-3.5" : "bg-gray-300 dark:bg-zinc-700"}`}
                    />
                  </div>
                </div>

                <div className="mt-3 space-y-2">
                  <p className="text-xs font-bold text-gray-900 dark:text-zinc-100">
                    {dynamicDirectives[activeRecommendationIndex].title}
                  </p>
                  <div className="inline-flex items-center gap-1 p-0.5 px-2 rounded-full bg-emerald-500/10 text-[9.5px] text-emerald-600 dark:text-emerald-450 font-bold font-mono">
                    Est Impact: {dynamicDirectives[activeRecommendationIndex].impact}
                  </div>
                  <p className="text-[11px] text-gray-500 dark:text-zinc-400 leading-relaxed mt-2 p-2.5 rounded-xl bg-gray-50 dark:bg-zinc-850/60 border border-gray-100 dark:border-zinc-800">
                    {dynamicDirectives[activeRecommendationIndex].guide}
                  </p>
                </div>
              </div>

            </div>

          </div>

          {/* 5. In-Depth Funnel Counts and Metrics Grid Ledger */}
          <div className="p-5 rounded-2xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 text-left">
            <div className="border-b border-gray-150 dark:border-zinc-800 pb-3">
              <h3 className="text-sm font-bold text-gray-900 dark:text-white">Granular Funnel Ledger</h3>
              <p className="text-[10px] text-gray-400 mt-0.5 font-mono">Detailed mathematical breakdown showcasing the customer journey through sequence steps.</p>
            </div>

            <div className="mt-4 overflow-x-auto">
              <table className="w-full text-xs text-left text-gray-500 dark:text-zinc-400">
                <thead className="text-[10px] font-black uppercase text-gray-400 dark:text-zinc-500 border-b border-gray-150 dark:border-zinc-800">
                  <tr>
                    <th scope="col" className="py-3 px-2">Customer Stage</th>
                    <th scope="col" className="py-3 px-2 text-right">Interactive Ingestion Count</th>
                    <th scope="col" className="py-3 px-2 text-right">Cumulative Conversion</th>
                    <th scope="col" className="py-3 px-2 text-right">Step-to-Step Dropoff</th>
                    <th scope="col" className="py-3 px-2 text-right">Estimated Opportunity Leakage</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-150 dark:divide-zinc-800/80 font-medium">
                  {metrics.funnelData && metrics.funnelData.map((item, index) => {
                    const isFirst = index === 0;
                    return (
                      <tr key={index} className="hover:bg-gray-55/40 dark:hover:bg-zinc-850/15 transition-colors">
                        <td className="py-3 px-2 font-bold text-gray-950 dark:text-white flex items-center gap-1.5">
                          <div className="h-2 w-2 rounded-full" style={{
                            backgroundColor: ["#06b6d4", "#0ea5e9", "#2563eb", "#4f46e5", "#6366f1"][index % 5]
                          }} />
                          <span>{item.stage}</span>
                        </td>
                        <td className="py-3 px-2 text-right font-bold text-gray-900 dark:text-zinc-100 font-mono">
                          {item.value.toLocaleString()}
                        </td>
                        <td className="py-3 px-2 text-right font-bold font-mono">
                          <span className="text-indigo-600 dark:text-indigo-400">{item.percentage}%</span>
                          <span className="text-[10px] text-gray-400 block font-normal">of initial traffic</span>
                        </td>
                        <td className="py-3 px-2 text-right font-bold font-mono">
                          {isFirst ? (
                            <span className="text-gray-400 font-normal">--</span>
                          ) : (
                            <div>
                              <span className="text-rose-500">{item.dropoff}% drop</span>
                              <span className="text-[10px] text-gray-400 block font-normal">from previous step</span>
                            </div>
                          )}
                        </td>
                        <td className="py-3 px-2 text-right font-bold text-rose-500 font-mono">
                          {isFirst || item.revenueLeakage === 0 ? (
                            <span className="text-gray-400 font-normal">--</span>
                          ) : (
                            <div>
                              <span>{formatCurrency(item.revenueLeakage || 0)}</span>
                              <span className="text-[9.5px] text-gray-400 block font-normal">lost potential value</span>
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        <CartAbandonmentIntelligence
          metrics={metrics}
          filters={filters}
          isSimulating={isSimulating}
          uploadedData={uploadedData}
        />
      )}

    </div>
  );
}
