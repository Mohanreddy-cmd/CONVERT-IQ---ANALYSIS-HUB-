import { useState, useMemo } from "react";
import {
  TrendingUp,
  ShoppingBag,
  Percent,
  DollarSign,
  Users,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  Sparkles,
  Search,
  FileSpreadsheet,
  Grid3X3,
  Sliders,
  Filter,
  CheckCircle,
  HelpCircle,
  Clock,
  Layers,
  ArrowRight,
  Database
} from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from "recharts";
import { UnifiedMetrics, GlobalFilters, IngestedRecord } from "../types";

interface DashboardHomeProps {
  metrics: UnifiedMetrics;
  filters: GlobalFilters;
  setFilters: (filters: GlobalFilters) => void;
  uploadedData: IngestedRecord[];
  isSimulating: boolean;
  onSelectPreset?: () => void;
}

export default function DashboardHome({
  metrics,
  filters,
  setFilters,
  uploadedData,
  isSimulating,
  onSelectPreset
}: DashboardHomeProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [eventFilter, setEventFilter] = useState<string>("all");

  // Obtain sheet preview rows: from uploadedData, or active simulated logs
  const getSheetRows = (): IngestedRecord[] => {
    if (uploadedData && uploadedData.length > 0) {
      return uploadedData;
    }
    // Fallback: Generate mock records so preview is never dry or blank!
    const fallbackRows: IngestedRecord[] = [];
    const products = ["Starlight Pro Wireless Headphones", "Aura Leather Messenger Bag", "Sonic Wave Waterproof Speaker", "Titan Fit Smartwatch", "Nova Bamboo Keyboard"];
    const categories = ["Electronics", "Accessories", "Electronics", "Lifestyle", "Office"];
    const devices = ["Desktop", "Mobile", "Tablet"];
    const channels = ["Google Organic", "Meta Social Ads", "Email Campaign", "Influencer Referral", "Direct"];
    const regions = ["North Americas", "European Union", "Asia Pacific", "Middle East & Africa"];
    const events = ["view", "cart", "checkout", "purchase"];

    for (let i = 0; i < 40; i++) {
      const pIdx = i % products.length;
      const isPurchase = events[i % events.length] === "purchase";
      const date = new Date();
      date.setMinutes(date.getMinutes() - i * 14);

      fallbackRows.push({
        timestamp: date.toISOString(),
        user_id: `usr_${101 + (i % 23)}`,
        session_id: `sess_602${5 + (i % 11)}`,
        product_id: `p_00${pIdx + 1}`,
        product_name: products[pIdx],
        category: categories[pIdx],
        event_type: events[i % events.length],
        traffic_source: channels[i % channels.length],
        device_type: devices[i % devices.length],
        region: regions[i % regions.length],
        revenue: isPurchase ? (65 + (i * 12) % 150) : 0
      });
    }
    return fallbackRows;
  };

  const sheetRows = getSheetRows();

  // --- START MINI GOOGLE ANALYTICS STATES & CALCULATIONS ---
  const [gaTab, setGaTab] = useState<"join" | "set" | "union" | "distinct" | "studio">("join");
  const [joinType, setJoinType] = useState<"inner" | "left">("left");
  const [joinTable, setJoinTable] = useState<"demographics" | "campaigns">("demographics");
  
  const [setA, setSetA] = useState<"all" | "cart_adders" | "purchasers">("cart_adders");
  const [setB, setSetB] = useState<"mobile" | "vip" | "organic">("mobile");
  const [selectedSetResultType, setSelectedSetResultType] = useState<"intersection" | "union" | "difference">("intersection");
  
  const [unionType, setUnionType] = useState<"all" | "distinct">("all");
  
  const [distinctDimension, setDistinctDimension] = useState<"region" | "device_type" | "traffic_source" | "category">("region");
  const [distinctMetric, setDistinctMetric] = useState<"user_id" | "session_id" | "product_id">("user_id");

  // Chart Studio States
  const [studioX, setStudioX] = useState<"device_type" | "region" | "traffic_source" | "category">("region");
  const [studioY, setStudioY] = useState<"revenue" | "ordersCount" | "distinctUsersCount">("revenue");
  const [studioChartType, setStudioChartType] = useState<"bar" | "line" | "area" | "pie">("bar");

  // --- START MINI-GA HIGH-FIDELITY DATA PIPELINES ---
  // 1. Relational Joins: Merges sheet log transactions with third-party customer tables
  const joinedResults = useMemo(() => {
    const leftRows = sheetRows.slice(0, 50); // limit rows for clean performance rendering
    const demographicsDict: Record<string, { tier: string; ageRange: string; segment: string }> = {
      "usr_101": { tier: "VIP Double Diamond", ageRange: "25-34", segment: "Tech Enthusiast" },
      "usr_102": { tier: "Premium Loyalty", ageRange: "35-44", segment: "Family Shopper" },
      "usr_103": { tier: "VIP Double Diamond", ageRange: "45-54", segment: "Luxury Collector" },
      "usr_104": { tier: "Standard", ageRange: "18-24", segment: "Student Budget" },
      "usr_105": { tier: "Standard", ageRange: "25-34", segment: "Tech Enthusiast" },
      "usr_106": { tier: "Premium Loyalty", ageRange: "35-44", segment: "Trend Follower" },
      "usr_107": { tier: "VIP Double Diamond", ageRange: "25-34", segment: "Luxury Collector" },
      "usr_108": { tier: "Guest Tier", ageRange: "18-24", segment: "Impulse Buyer" },
      "usr_109": { tier: "Standard", ageRange: "45-54", segment: "Gardening Hobbyist" },
      "usr_110": { tier: "Premium Loyalty", ageRange: "25-34", segment: "Tech Enthusiast" },
    };

    const campaignCostsDict: Record<string, { campaignName: string; adSpend: number; costPerClick: number; leadManager: string }> = {
      "Google Organic": { campaignName: "SEO Evergreen Brand", adSpend: 0, costPerClick: 0.00, leadManager: "Sarah Green" },
      "Meta Social Ads": { campaignName: "Meta Lookalike Retargeting V4", adSpend: 1200, costPerClick: 1.15, leadManager: "Alex Rivera" },
      "Email Campaign": { campaignName: "Abandoned Basket Retention", adSpend: 350, costPerClick: 0.12, leadManager: "Diana Prince" },
      "Influencer Referral": { campaignName: "Spring Lifestyle Buzz", adSpend: 4500, costPerClick: 2.40, leadManager: "Taylor S." },
      "Direct": { campaignName: "Direct Browser Hits", adSpend: 0, costPerClick: 0.00, leadManager: "Organic Growth" },
    };

    return leftRows.map(left => {
      let matchedRight: any = null;
      if (joinTable === "demographics") {
        matchedRight = demographicsDict[left.user_id] || {
          tier: (parseInt(left.user_id.replace(/\D/g, "") || "0") % 2 === 0) ? "Premium Loyalty" : "Guest Tier",
          ageRange: ["18-24", "25-34", "35-44", "45-54"][parseInt(left.user_id.replace(/\D/g, "") || "0") % 4],
          segment: ["Tech Enthusiast", "Lifestyle General", "Value Buyer", "Holiday Spender"][parseInt(left.user_id.replace(/\D/g, "") || "0") % 4]
        };
      } else {
        matchedRight = campaignCostsDict[left.traffic_source] || {
          campaignName: "Default Referral Campaign",
          adSpend: 150,
          costPerClick: 0.45,
          leadManager: "Marketing Bot"
        };
      }

      const isMatch = matchedRight !== null;
      if (joinType === "inner" && !isMatch) {
         return null;
      }

      return {
        ...left,
        matchedRight,
        joinKey: joinTable === "demographics" ? left.user_id : left.traffic_source
      };
    }).filter(Boolean) as any[];
  }, [sheetRows, joinType, joinTable]);

  // 2. Cohort Sets: Sets intersection, union, and difference
  const setResults = useMemo(() => {
    const usersSetA = new Set<string>();
    sheetRows.forEach(r => {
      if (setA === "all") {
        usersSetA.add(r.user_id);
      } else if (setA === "cart_adders") {
        if (r.event_type === "cart" || r.event_type === "checkout" || r.event_type === "purchase") {
          usersSetA.add(r.user_id);
        }
      } else if (setA === "purchasers") {
        if (r.event_type === "purchase" || r.revenue > 0) {
          usersSetA.add(r.user_id);
        }
      }
    });

    const usersSetB = new Set<string>();
    sheetRows.forEach(r => {
      if (setB === "mobile") {
        if (r.device_type === "Mobile" || r.device_type === "Tablet" || r.device_type === "tablet") {
          usersSetB.add(r.user_id);
        }
      } else if (setB === "vip") {
        const totalUserSpends: Record<string, number> = {};
        sheetRows.forEach(u => { totalUserSpends[u.user_id] = (totalUserSpends[u.user_id] || 0) + u.revenue; });
        if (totalUserSpends[r.user_id] > 80) {
          usersSetB.add(r.user_id);
        }
      } else if (setB === "organic") {
        if (r.traffic_source === "Google Organic" || r.traffic_source === "Direct") {
          usersSetB.add(r.user_id);
        }
      }
    });

    const intersection = new Set<string>([...usersSetA].filter(x => usersSetB.has(x)));
    const union = new Set<string>([...usersSetA, ...usersSetB]);
    const difference = new Set<string>([...usersSetA].filter(x => !usersSetB.has(x)));

    const targetUserIdSet = selectedSetResultType === "intersection" ? intersection 
                          : selectedSetResultType === "union" ? union 
                          : difference;

    const breakdownList = Array.from(targetUserIdSet).slice(0, 15).map(uid => {
      const rep = sheetRows.find(r => r.user_id === uid) || { 
        user_id: uid, product_name: "Match Profile", traffic_source: "Organic Search", region: "North Americas" 
      };
      return {
        user_id: uid,
        repProduct: rep.product_name,
        repChannel: rep.traffic_source,
        repRegion: rep.region
      };
    });

    return {
      sizeA: usersSetA.size,
      sizeB: usersSetB.size,
      intersectionCount: intersection.size,
      unionCount: union.size,
      differenceCount: difference.size,
      breakdownList,
      setAName: setA === "all" ? "All Visitors" : setA === "cart_adders" ? "Cart Adders" : "Conversion Cohort",
      setBName: setB === "mobile" ? "Mobile Devices Users" : setB === "vip" ? "VIP Spenders (> $80)" : "Organic Channels"
    };
  }, [sheetRows, setA, setB, selectedSetResultType]);

  // 3. Multi-Channel Unions: Stack offline events with browser activity logs
  const unionResults = useMemo(() => {
    const source1Events = sheetRows.map(r => ({
      timestamp: r.timestamp,
      user_id: r.user_id,
      activity: r.event_type === "purchase" ? "Online Purchase" : r.event_type === "checkout" ? "Online Checkout" : "Web Browse Session",
      channel: "Web Storefront Online",
      revenue: r.revenue,
      location: r.region
    }));

    const offlineRows = [
      { timestamp: "2026-06-06T12:10:00Z", user_id: "usr_off_501", activity: "Store Point-of-Sale Sale", channel: "In-Store Retail Terminal", revenue: 145.00, location: "London Soho Boutique" },
      { timestamp: "2026-06-06T12:22:00Z", user_id: "usr_off_502", activity: "Store Point-of-Sale Sale", channel: "In-Store Retail Terminal", revenue: 89.99, location: "Boston Flagship Store" },
      { timestamp: "2026-06-06T12:45:00Z", user_id: "usr_101", activity: "Boutique Return Exchange", channel: "In-Store Retail Terminal", revenue: -50.00, location: "Tokyo Shibuya Outlets" }, 
      { timestamp: "2026-06-06T13:02:00Z", user_id: "usr_off_504", activity: "Store Point-of-Sale Sale", channel: "In-Store Retail Terminal", revenue: 210.00, location: "Paris Boulevard POS" },
      { timestamp: "2026-06-06T13:14:00Z", user_id: "usr_105", activity: "Custom Styling Consultation", channel: "Luxury VIP Lounge", revenue: 0.00, location: "London Soho Boutique" },
      { timestamp: "2026-06-06T13:30:00Z", user_id: "usr_off_506", activity: "Store Point-of-Sale Sale", channel: "In-Store Retail Terminal", revenue: 320.00, location: "Tokyo Shibuya Outlets" },
      { timestamp: "2026-06-06T13:55:00Z", user_id: "usr_off_507", activity: "Store Point-of-Sale Sale", channel: "In-Store Retail Terminal", revenue: 75.50, location: "Boston Flagship Store" },
    ];

    let combined = [];
    if (unionType === "all") {
      combined = [...source1Events, ...offlineRows];
    } else {
      const seenUsers = new Set<string>();
      combined = [...source1Events, ...offlineRows].filter(item => {
        if (seenUsers.has(item.user_id)) return false;
        seenUsers.add(item.user_id);
        return true;
      });
    }

    const onlineTotalRev = source1Events.reduce((acc, curr) => acc + curr.revenue, 0);
    const offlineTotalRev = offlineRows.reduce((acc, curr) => acc + curr.revenue, 0);

    const shareData = [
      { name: "Online Channels", value: Math.round(onlineTotalRev) },
      { name: "Retail Stores", value: Math.round(offlineTotalRev) }
    ];

    return {
      combinedRows: combined,
      onlineEventsCount: source1Events.length,
      offlineEventsCount: offlineRows.length,
      unitedTotalRev: onlineTotalRev + offlineTotalRev,
      shareData
    };
  }, [sheetRows, unionType]);

  // 4. SQL Count Distinct Groups calculations
  const distinctGroupsResults = useMemo(() => {
    const groups: Record<string, { totalCount: number; uniqueItems: Set<string>; totalRevenue: number }> = {};

    sheetRows.forEach(r => {
      const gValue = r[distinctDimension] as string;
      const gKey = gValue || "Other / Direct";
      if (!groups[gKey]) {
        groups[gKey] = { totalCount: 0, uniqueItems: new Set<string>(), totalRevenue: 0 };
      }
      groups[gKey].totalCount += 1;
      
      let metricVal = r.user_id;
      if (distinctMetric === "session_id") metricVal = r.session_id;
      else if (distinctMetric === "product_id") metricVal = r.product_id;

      groups[gKey].uniqueItems.add(metricVal);
      groups[gKey].totalRevenue += r.revenue || 0;
    });

    return Object.keys(groups).map(key => {
      const totalCount = groups[key].totalCount;
      const distinctCount = groups[key].uniqueItems.size;
      const totalRevenue = groups[key].totalRevenue;
      return {
        dimensionValue: key,
        totalCount,
        distinctCount,
        associatedRevenue: Math.round(totalRevenue),
        uniquenessRatio: parseFloat(((distinctCount / totalCount) * 100).toFixed(1))
      };
    });
  }, [sheetRows, distinctDimension, distinctMetric]);

  // 5. Custom Charting Studio calculations
  const studioChartData = useMemo(() => {
    const aggregates: Record<string, { sumRevenue: number; countOrders: number; usersSet: Set<string> }> = {};

    sheetRows.forEach(row => {
      const xVal = (row[studioX] as string) || "Unknown";
      if (!aggregates[xVal]) {
        aggregates[xVal] = { sumRevenue: 0, countOrders: 0, usersSet: new Set<string>() };
      }

      if (row.event_type === "purchase" || row.revenue > 0) {
        aggregates[xVal].sumRevenue += row.revenue;
        aggregates[xVal].countOrders += 1;
      }
      aggregates[xVal].usersSet.add(row.user_id);
    });

    return Object.keys(aggregates).map(key => {
      const usersCount = aggregates[key].usersSet.size;
      return {
        name: key,
        revenue: Math.round(aggregates[key].sumRevenue),
        ordersCount: aggregates[key].countOrders,
        distinctUsersCount: usersCount
      };
    });
  }, [sheetRows, studioX, studioY]);
  // --- END MINI-GA DATA PIPELINES ---

  const hasData = (uploadedData && uploadedData.length > 0) || isSimulating;

  if (!hasData) {
    return (
      <div className="p-8 bg-white dark:bg-zinc-900 border border-gray-150 dark:border-zinc-805 rounded-3xl text-center space-y-6 max-w-xl mx-auto my-12 shadow-sm text-left">
        <div className="h-14 w-14 shrink-0 rounded-full bg-cyan-55/60 dark:bg-cyan-950/40 border border-cyan-150 dark:border-cyan-900 flex items-center justify-center text-cyan-600 dark:text-cyan-400 mx-auto animate-pulse">
          <FileSpreadsheet className="h-7 w-7" />
        </div>
        <div className="space-y-2 text-center">
          <h3 className="text-base font-bold text-gray-900 dark:text-white">Spreadsheet Dashboard Is Quiet</h3>
          <p className="text-xs text-gray-500 dark:text-zinc-400 max-w-sm mx-auto leading-relaxed">
            Live transaction timelines, active conversion indicators, and tabular spreadsheet grids are currently hidden because no active file has been parsed. Ingest a transaction dataset inside the <strong className="font-semibold text-indigo-505">About & Ingest</strong> panel or activate the demo set to unlock calculations.
          </p>
        </div>
        <div className="text-center">
          <button
            id="dashboard-empty-demo-btn"
            onClick={onSelectPreset}
            className="inline-flex items-center gap-1.5 text-xs font-black bg-indigo-650 hover:bg-indigo-700 dark:bg-indigo-600 p-3 px-6 rounded-xl text-white transition-all shadow cursor-pointer active:scale-95"
          >
            <span>Activate Demo Dataset Instead</span>
          </button>
        </div>
      </div>
    );
  }

  const regionOptions = [
    { value: "all", label: "Global Regions" },
    { value: "Americas", label: "North Americas" },
    { value: "Europe", label: "European Union" },
    { value: "APAC", label: "Asia Pacific" },
    { value: "MEA", label: "Middle East & Africa" }
  ];

  const deviceOptions = [
    { value: "all", label: "All Devices" },
    { value: "Desktop", label: "Desktop" },
    { value: "Mobile", label: "Mobile" },
    { value: "Tablet", label: "Tablet" }
  ];

  // Helper formatting values
  const formatCurrency = (val: number) => {
    if (val >= 1000000) return `$${(val / 1000000).toFixed(2)}M`;
    if (val >= 1000) return `$${(val / 1000).toFixed(1)}k`;
    return `$${val.toLocaleString()}`;
  };

  const formatNumber = (val: number) => {
    if (val >= 1000) return (val / 1000).toFixed(1) + "k";
    return val.toLocaleString();
  };

  // Filter sheet rows based on search
  const filteredSheetRows = sheetRows.filter(row => {
    const matchesSearch = 
      row.product_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      row.user_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      row.traffic_source.toLowerCase().includes(searchTerm.toLowerCase()) ||
      row.region.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesEvent = eventFilter === "all" || row.event_type === eventFilter;

    return matchesSearch && matchesEvent;
  });

  const getHealthScore = () => {
    return Math.min(100, Math.max(40, Math.round(
      (metrics.conversionRate * 12) + (metrics.returningCustomerRate * 0.8) - (metrics.cartAbandonment * 0.1) + 45
    )));
  };

  const healthScore = getHealthScore();

  return (
    <div id="dashboard-main-split-container" className="space-y-6">
      
      {/* 1. DYNAMIC CONTROLLERS BANNER */}
      <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-gray-150 dark:border-zinc-800/80 shadow-sm flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
        <div className="space-y-1">
          <span className="text-[10px] uppercase font-black text-indigo-500 tracking-wider flex items-center gap-1.5 leading-none">
            <Sliders className="h-3.5 w-3.5" />
            <span>Interactive Workspace Hub</span>
          </span>
          <h2 className="text-base font-bold text-gray-900 dark:text-white">Active Conversion Metrics Panel</h2>
        </div>

        <div className="flex flex-wrap gap-2">
          {/* Quick Region Selector */}
          <div className="flex items-center gap-1.5 bg-gray-55 border border-gray-150 dark:bg-zinc-850 dark:border-zinc-85 px-3 py-1.5 rounded-xl text-xs font-semibold">
            <Filter className="h-3 w-3 text-cyan-500" />
            <select
              id="dash-filter-region"
              value={filters.region}
              onChange={(e) => setFilters({ ...filters, region: e.target.value })}
              className="bg-transparent text-gray-800 dark:text-zinc-200 outline-none cursor-pointer focus:ring-0"
            >
              {regionOptions.map(o => <option key={o.value} className="bg-white dark:bg-zinc-900" value={o.value}>{o.label}</option>)}
            </select>
          </div>

          {/* Quick Device Selector */}
          <div className="flex items-center gap-1.5 bg-gray-55 border border-gray-150 dark:bg-zinc-850 dark:border-zinc-85 px-3 py-1.5 rounded-xl text-xs font-semibold">
            <select
              id="dash-filter-device"
              value={filters.device}
              onChange={(e) => setFilters({ ...filters, device: e.target.value })}
              className="bg-transparent text-gray-800 dark:text-zinc-200 outline-none cursor-pointer focus:ring-0"
            >
              {deviceOptions.map(o => <option key={o.value} className="bg-white dark:bg-zinc-900" value={o.value}>{o.label}</option>)}
            </select>
          </div>
        </div>
      </div>

      {/* 2. RESPONSIVE SIDE-BY-SIDE DESKTOP SPLIT GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT COLS: THE VISUAL ANALYTIC DASHBOARD (7 COLS) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Six KPI cards in tight layout */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            
            {/* Revenue */}
            <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-gray-150 dark:border-zinc-800 shadow-sm flex flex-col justify-between h-28">
              <div className="flex justify-between items-center text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase">
                <span>Revenue Flow</span>
                <DollarSign className="h-4 w-4 text-cyan-500" />
              </div>
              <p className="text-lg font-black text-gray-900 dark:text-white tracking-tight leading-none">
                {formatCurrency(metrics.revenue)}
              </p>
              <div className="flex items-center gap-1 text-[9px] text-emerald-500 font-bold leading-none">
                <ArrowUpRight className="h-3 w-3" />
                <span>+12.4% vs base</span>
              </div>
            </div>

            {/* Orders */}
            <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-gray-150 dark:border-zinc-800 shadow-sm flex flex-col justify-between h-28">
              <div className="flex justify-between items-center text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase">
                <span>Total Orders</span>
                <ShoppingBag className="h-4 w-4 text-indigo-500" />
              </div>
              <p className="text-lg font-black text-gray-900 dark:text-white tracking-tight leading-none">
                {formatNumber(metrics.orders)}
              </p>
              <div className="flex items-center gap-1 text-[9px] text-emerald-500 font-bold leading-none">
                <ArrowUpRight className="h-3 w-3" />
                <span>+8.2% conversion</span>
              </div>
            </div>

            {/* Conversion Rate */}
            <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-gray-150 dark:border-zinc-800 shadow-sm flex flex-col justify-between h-28">
              <div className="flex justify-between items-center text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase">
                <span>Conversion Rate</span>
                <Percent className="h-4 w-4 text-purple-500" />
              </div>
              <p className="text-lg font-black text-gray-900 dark:text-white tracking-tight leading-none">
                {metrics.conversionRate}%
              </p>
              <div className="flex items-center gap-1 text-[9px] text-emerald-500 font-bold leading-none">
                <ArrowUpRight className="h-3 w-3" />
                <span>Healthy index</span>
              </div>
            </div>

            {/* AOV */}
            <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-gray-150 dark:border-zinc-800 shadow-sm flex flex-col justify-between h-28">
              <div className="flex justify-between items-center text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase">
                <span>Avg Order Value</span>
                <DollarSign className="h-4 w-4 text-amber-500" />
              </div>
              <p className="text-lg font-black text-gray-900 dark:text-white tracking-tight leading-none">
                ${metrics.aov}
              </p>
              <div className="flex items-center gap-1 text-[9px] text-emerald-500 font-bold leading-none">
                <ArrowUpRight className="h-3 w-3" />
                <span>+5.1% spend value</span>
              </div>
            </div>

            {/* Cart Abandonment */}
            <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-gray-150 dark:border-zinc-800 shadow-sm flex flex-col justify-between h-28">
              <div className="flex justify-between items-center text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase">
                <span>Abandoned Carts</span>
                <AlertTriangle className="h-4 w-4 text-orange-500" />
              </div>
              <p className="text-lg font-black text-rose-500 dark:text-orange-400 tracking-tight leading-none">
                {metrics.cartAbandonment}%
              </p>
              <div className="flex items-center gap-1 text-[9px] text-orange-400 font-bold leading-none">
                <ArrowDownRight className="h-3 w-3" />
                <span>Friction point</span>
              </div>
            </div>

            {/* Retention */}
            <div className="p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-gray-150 dark:border-zinc-800 shadow-sm flex flex-col justify-between h-28">
              <div className="flex justify-between items-center text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase">
                <span>Returning Rate</span>
                <Users className="h-4 w-4 text-emerald-500" />
              </div>
              <p className="text-lg font-black text-gray-900 dark:text-white tracking-tight leading-none">
                {metrics.returningCustomerRate}%
              </p>
              <div className="flex items-center gap-1 text-[9px] text-emerald-500 font-bold leading-none">
                <ArrowUpRight className="h-3 w-3" />
                <span>Loyal cohorts</span>
              </div>
            </div>

          </div>

          {/* Area Chart: Revenue Trend */}
          <div className="p-5 rounded-2xl border border-gray-150 dark:border-zinc-805 bg-white dark:bg-zinc-900 shadow-sm space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-gray-100 dark:border-zinc-800">
              <div>
                <h3 className="text-xs font-bold text-gray-900 dark:text-white">Revenue Timeline Stream</h3>
                <p className="text-[10px] text-gray-400 mt-0.5">Plotting raw revenue events aggregated across active filters.</p>
              </div>
              <div className="text-[11px] font-mono text-cyan-600 font-bold">
                Live Data Rendered
              </div>
            </div>

            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={metrics.revenueTrend} margin={{ top: 10, right: 5, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="cyanGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="rgb(6, 182, 212)" stopOpacity={0.25}/>
                      <stop offset="95%" stopColor="rgb(6, 182, 212)" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="date" tickLine={false} style={{ fontSize: 9, fill: "#888" }} />
                  <YAxis tickLine={false} style={{ fontSize: 9, fill: "#888" }} tickFormatter={(v) => `$${v}`} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "rgba(10, 10, 10, 0.95)",
                      border: "1px solid rgba(80, 80, 80, 0.3)",
                      borderRadius: 12,
                      fontSize: 10,
                      color: "#fff"
                    }}
                  />
                  <Area type="monotone" dataKey="value" stroke="#06b6d4" strokeWidth={2.5} fillOpacity={1} fill="url(#cyanGradient)" name="Net Revenue" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Business Health Meter Box */}
          <div className="p-4 rounded-xl border border-indigo-505/15 bg-indigo-500/[0.02] dark:bg-indigo-950/20 flex flex-col sm:flex-row items-center gap-4 justify-between">
            <div className="flex gap-2.5 items-center">
              <div className="h-10 w-10 shrink-0 rounded-full border border-indigo-150 dark:border-indigo-900 flex items-center justify-center font-mono text-sm font-black text-indigo-600 dark:text-indigo-400 bg-white dark:bg-zinc-850">
                {healthScore}
              </div>
              <div className="text-left space-y-0.5">
                <span className="block text-xs font-bold text-gray-900 dark:text-white">Active Operational Vitality Index</span>
                <p className="text-[10px] text-gray-500 dark:text-zinc-400">Composite score derived from conversion rate and user retention.</p>
              </div>
            </div>
            <span className="text-[9.5px] uppercase font-black tracking-widest text-indigo-600 dark:text-indigo-400 bg-indigo-100/50 dark:bg-indigo-900/30 px-3 py-1 rounded">
              {healthScore >= 75 ? "Excellent Health" : "Needs checkout review"}
            </span>
          </div>

        </div>

        {/* RIGHT COLS: THE SPREADSHEET PREVIEW OF EXCEL (5 COLS - SIDE OF THE DASHBOARD) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-5 rounded-2xl border border-gray-150 dark:border-zinc-800 bg-white dark:bg-zinc-900 shadow-sm space-y-4 flex flex-col h-[525px]">
            
            {/* Spreadsheet Header */}
            <div className="flex items-center justify-between border-b border-gray-100 dark:border-zinc-805 pb-3 shrink-0">
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 flex items-center justify-center text-emerald-500 border border-emerald-150 dark:border-emerald-900">
                  <FileSpreadsheet className="h-4.5 w-4.5" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                    <span>Spreadsheet Grid Preview</span>
                    <span className="text-[9px] bg-emerald-500/10 text-emerald-500 p-0.5 px-1.5 rounded-full font-mono font-bold">XLS Viewer</span>
                  </h3>
                  <p className="text-[9.5px] text-gray-400 mt-0.5">Direct spreadsheet viewer of your uploaded transaction records.</p>
                </div>
              </div>
              <span className="text-[9.5px] text-gray-400 font-mono font-bold shrink-0">
                Total: {uploadedData.length > 0 ? uploadedData.length : "Demo"} rows
              </span>
            </div>

            {/* Filter controls inside preview */}
            <div className="flex gap-2 shrink-0">
              {/* Search Bar */}
              <div className="flex-1 relative">
                <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-gray-400" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full text-[11px] p-2 pl-8 pr-3 rounded-lg border border-gray-200 dark:border-zinc-800 bg-gray-55/40 dark:bg-zinc-950/40 outline-none focus:border-cyan-500 text-gray-800 dark:text-zinc-200"
                  placeholder="Search rows or products..."
                />
              </div>

              {/* Event Badge selector */}
              <select
                value={eventFilter}
                onChange={(e) => setEventFilter(e.target.value)}
                className="text-[11px] p-2 bg-gray-55 dark:bg-zinc-950 border border-gray-200 dark:border-zinc-800 outline-none rounded-lg text-gray-700 dark:text-zinc-300"
              >
                <option value="all">All Events</option>
                <option value="view">Views</option>
                <option value="cart">Carts</option>
                <option value="checkout">Checkouts</option>
                <option value="purchase">Purchases</option>
              </select>
            </div>

            {/* Scrollable grid Table */}
            <div className="flex-1 overflow-auto border border-gray-150 dark:border-zinc-85 rounded-xl bg-gray-55/20 dark:bg-zinc-950/20">
              <table className="w-full text-[10.5px] text-left border-collapse">
                <thead className="bg-gray-100 dark:bg-zinc-900 sticky top-0 z-10 border-b border-gray-200 dark:border-zinc-800 text-[10px] font-bold text-gray-500 dark:text-zinc-400 uppercase tracking-wider">
                  <tr>
                    <th className="p-2 pl-3 font-semibold border-r border-gray-150 dark:border-zinc-800/80">User ID</th>
                    <th className="p-2 font-semibold border-r border-gray-150 dark:border-zinc-800/80">Product Name</th>
                    <th className="p-2 font-semibold border-r border-gray-150 dark:border-zinc-800/80">Goal event</th>
                    <th className="p-2 pr-3 font-semibold text-right">Revenue</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-150 dark:divide-zinc-85">
                  {filteredSheetRows.slice(0, 100).map((row, index) => (
                    <tr
                      key={index}
                      className="hover:bg-slate-50 dark:hover:bg-zinc-925 border-b border-gray-100 dark:border-zinc-85 transition-colors font-medium text-gray-800 dark:text-zinc-350"
                    >
                      {/* User Cell */}
                      <td className="p-2 pl-3 font-mono text-[9px] max-w-16 truncate border-r border-gray-150 dark:border-zinc-800/80">
                        {row.user_id}
                      </td>

                      {/* Product Name Cell */}
                      <td className="p-2 truncate max-w-28 border-r border-gray-150 dark:border-zinc-800/80" title={row.product_name}>
                        {row.product_name}
                      </td>

                      {/* Event Type Cell with mini styled pills */}
                      <td className="p-2 border-r border-gray-150 dark:border-zinc-800/80">
                        <span className={`inline-block text-[8.5px] font-bold uppercase tracking-tight px-1.5 py-0.5 rounded ${
                          row.event_type === "purchase" ? "bg-emerald-500/10 text-emerald-500" :
                          row.event_type === "checkout" ? "bg-amber-500/10 text-amber-500" :
                          row.event_type === "cart" ? "bg-blue-500/10 text-blue-500" :
                          "bg-gray-400/10 text-gray-400"
                        }`}>
                          {row.event_type}
                        </span>
                      </td>

                      {/* Revenue Cell */}
                      <td className={`p-2 pr-3 text-right font-mono text-[10px] font-bold ${row.revenue > 0 ? "text-emerald-505" : "text-gray-400"}`}>
                        {row.revenue > 0 ? `$${row.revenue.toFixed(2)}` : "—"}
                      </td>
                    </tr>
                  ))}

                  {filteredSheetRows.length === 0 && (
                    <tr>
                      <td colSpan={4} className="text-center py-20 text-gray-400 dark:text-zinc-550 space-y-2">
                        <Clock className="h-6 w-6 text-gray-300 dark:text-zinc-800 mx-auto" />
                        <p className="text-[10.5px]">No sheet records match search criteria.</p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Bottom help bar */}
            <div className="shrink-0 flex justify-between items-center text-[9px] text-gray-400 bg-gray-50 dark:bg-zinc-950 p-2 rounded-lg border border-gray-100 dark:border-zinc-900 leading-none">
              <span className="flex items-center gap-1">
                <Grid3X3 className="h-3 w-3 text-emerald-505" />
                Showing {Math.min(100, filteredSheetRows.length)} of {filteredSheetRows.length} lines
              </span>
              <span>Scroll to browse</span>
            </div>

          </div>
        </div>

      </div>

      {/* ========================================== */}
      {/* 3. CONVERTIQ MINI GOOGLE ANALYTICS ENGINE */}
      {/* ========================================== */}
      <div id="mini-ga-analytical-suite" className="mt-8 p-6 rounded-3xl border border-gray-150 dark:border-zinc-800 bg-white dark:bg-zinc-900 shadow-md space-y-6">
        
        {/* Banner header inside the card */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-gray-100 dark:border-zinc-805">
          <div className="space-y-1 text-left">
            <span className="text-[10px] uppercase font-black text-cyan-500 tracking-widest flex items-center gap-1.5 leading-none">
              <Database className="h-3.5 w-3.5 text-cyan-500" />
              <span>Computational Data Layer</span>
            </span>
            <h2 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2 mt-1">
              <span>⚡ ConvertIQ Mini Google Analytics Engine</span>
            </h2>
            <p className="text-xs text-gray-400 mt-1">
              Aggregate browser logs using relational operators (Joins, Sets, Unions, and Distinct filters). Measure conversion attribution with live interactive charts.
            </p>
          </div>

          {/* Quick Tab switcher */}
          <div className="flex flex-wrap gap-1 bg-gray-55 dark:bg-zinc-950 p-1 rounded-xl border border-gray-150 dark:border-zinc-85 shrink-0 text-xs font-semibold">
            <button
              id="btn-ga-tab-join"
              onClick={() => setGaTab("join")}
              className={`p-2 px-3 rounded-lg cursor-pointer transition-all duration-200 ${
                gaTab === "join"
                  ? "bg-white dark:bg-zinc-800 text-gray-900 dark:text-white shadow-sm font-black text-xs font-semibold"
                  : "text-gray-400 hover:text-gray-800 dark:hover:text-zinc-200"
              }`}
            >
              Relational Joins
            </button>
            <button
              id="btn-ga-tab-set"
              onClick={() => setGaTab("set")}
              className={`p-2 px-3 rounded-lg cursor-pointer transition-all duration-200 ${
                gaTab === "set"
                  ? "bg-white dark:bg-zinc-800 text-gray-900 dark:text-white shadow-sm font-black text-xs font-semibold"
                  : "text-gray-400 hover:text-gray-800 dark:hover:text-zinc-200"
              }`}
            >
              Cohort Sets
            </button>
            <button
              id="btn-ga-tab-union"
              onClick={() => setGaTab("union")}
              className={`p-2 px-3 rounded-lg cursor-pointer transition-all duration-200 ${
                gaTab === "union"
                  ? "bg-white dark:bg-zinc-800 text-gray-900 dark:text-white shadow-sm font-black text-xs font-semibold"
                  : "text-gray-400 hover:text-gray-800 dark:hover:text-zinc-200"
              }`}
            >
              Unions
            </button>
            <button
              id="btn-ga-tab-distinct"
              onClick={() => setGaTab("distinct")}
              className={`p-2 px-3 rounded-lg cursor-pointer transition-all duration-200 ${
                gaTab === "distinct"
                  ? "bg-white dark:bg-zinc-800 text-gray-900 dark:text-white shadow-sm font-black text-xs font-semibold"
                  : "text-gray-400 hover:text-gray-800 dark:hover:text-zinc-200"
              }`}
            >
              Distinct Groups
            </button>
            <button
              id="btn-ga-tab-studio"
              onClick={() => setGaTab("studio")}
              className={`p-2 px-3 rounded-lg cursor-pointer transition-all duration-200 ${
                gaTab === "studio"
                  ? "bg-gradient-to-r from-cyan-500/10 to-indigo-500/10 dark:from-cyan-955/30 dark:to-indigo-955/30 text-indigo-605 dark:text-cyan-400 border border-indigo-505/20 shadow-sm font-black text-xs font-semibold"
                  : "text-gray-400 hover:text-gray-800 dark:hover:text-zinc-200"
              }`}
            >
              ✨ Metric Studio
            </button>
          </div>
        </div>

        {/* Tab content area */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start text-left">
          
          {/* ======================= TAB 1: RELATIONAL JOINS ======================= */}
          {gaTab === "join" && (
            <>
              {/* Left Column: Interactive Settings Card */}
              <div className="lg:col-span-4 p-4 rounded-2xl border border-gray-150 dark:border-zinc-805 space-y-4 bg-gray-55/30 dark:bg-zinc-950/40">
                <span className="text-[9.5px]/none uppercase font-black text-cyan-505 bg-cyan-500/10 px-2 py-0.5 rounded inline-block">
                  SQL Query Simulator
                </span>
                <h3 className="text-xs font-bold text-gray-901 dark:text-white">Join Configuration</h3>
                <p className="text-[10.5px] text-gray-500 dark:text-zinc-400 leading-relaxed">
                  Combine the active web transaction events spreadsheet data with a secondary mock operational ledger using standard database join functions.
                </p>

                {/* Primary Table Left indicator */}
                <div className="text-[10.5px] p-2 bg-white dark:bg-zinc-900 rounded-lg border border-gray-100 dark:border-zinc-85 space-y-1">
                  <span className="text-[8.5px] text-gray-400 uppercase font-bold">Left Table (Table A)</span>
                  <div className="font-semibold text-gray-800 dark:text-zinc-200 flex items-center justify-between">
                    <span>Parsed Website Logs</span>
                    <span className="text-[9px] text-indigo-505 font-mono font-bold">Key: {joinTable === "demographics" ? "user_id" : "traffic_source"}</span>
                  </div>
                </div>

                {/* Match Table Selector */}
                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-gray-400 uppercase block">Match with Ledger (Table B)</label>
                  <select
                    id="join-table-select"
                    value={joinTable}
                    onChange={(e) => setJoinTable(e.target.value as any)}
                    className="w-full text-xs p-2 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 outline-none rounded-lg text-gray-850 dark:text-zinc-200 font-medium"
                  >
                    <option value="demographics">User Demographics (Tier, Age Group)</option>
                    <option value="campaigns">Campaign Expenditures (Ad Spend, CPC, Lead Manager)</option>
                  </select>
                </div>

                {/* Join Condition Selector */}
                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-gray-400 uppercase block">Relational Join Mode</label>
                  <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
                    <button
                      id="btn-join-left"
                      onClick={() => setJoinType("left")}
                      className={`p-2 rounded-lg cursor-pointer text-center outline-none border transition-all ${
                        joinType === "left"
                          ? "bg-indigo-650 text-white border-indigo-600 dark:bg-indigo-600"
                          : "bg-white dark:bg-zinc-905 border-gray-200 dark:border-zinc-800 text-gray-700 dark:text-zinc-350 hover:bg-slate-50 dark:hover:bg-zinc-850"
                      }`}
                    >
                      LEFT OUTER JOIN
                    </button>
                    <button
                      id="btn-join-inner"
                      onClick={() => setJoinType("inner")}
                      className={`p-2 rounded-lg cursor-pointer text-center outline-none border transition-all ${
                        joinType === "inner"
                          ? "bg-indigo-650 text-white border-indigo-600 dark:bg-indigo-600"
                          : "bg-white dark:bg-zinc-905 border-gray-200 dark:border-zinc-800 text-gray-700 dark:text-zinc-350 hover:bg-slate-50 dark:hover:bg-zinc-850"
                      }`}
                    >
                      INNER JOIN
                    </button>
                  </div>
                </div>

                {/* Simulated Schema Formula */}
                <div className="p-3 bg-zinc-950 font-mono text-[9px] text-emerald-400/90 rounded-lg space-y-1">
                  <span className="text-gray-500 font-bold block">SQL Execution:</span>
                  <p className="whitespace-pre-wrap leading-relaxed select-all">
                    {joinTable === "demographics" ? (
                      `SELECT \n  A.*, B.loyalty_tier, B.age_group\nFROM web_logs A\n${joinType === "inner" ? "INNER" : "LEFT"} JOIN user_profiles B \nON A.user_id = B.user_id`
                    ) : (
                      `SELECT \n  A.*, B.ad_spend, B.lead_manager\nFROM web_logs A\n${joinType === "inner" ? "INNER" : "LEFT"} JOIN marketing_campaigns B \nON A.traffic_source = B.traffic_source`
                    )}
                  </p>
                </div>
              </div>

              {/* Right Column: Visualization Graphics & Joined Table */}
              <div className="lg:col-span-8 space-y-6 animate-fadeIn">
                
                {/* Visual join diagram chart */}
                <div className="p-4 border border-gray-150 dark:border-zinc-800 rounded-2xl space-y-3">
                  <h4 className="text-xs font-black text-gray-901 dark:text-white uppercase tracking-wider">Matched Attribution Dashboard Output</h4>
                  <p className="text-[10px] text-gray-450 mt-0.5 max-w-lg leading-relaxed">
                    Analyzing active filtered records ({joinedResults.length} records joined) mapped to linked operational indices.
                  </p>

                  <div className="h-56">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart 
                        data={
                          joinTable === "demographics" ? [
                            { name: "18-24", Revenue: joinedResults.filter(r => r.matchedRight?.ageRange === "18-24").reduce((sum, r) => sum + r.revenue, 0) },
                            { name: "25-34", Revenue: joinedResults.filter(r => r.matchedRight?.ageRange === "25-34").reduce((sum, r) => sum + r.revenue, 0) },
                            { name: "35-44", Revenue: joinedResults.filter(r => r.matchedRight?.ageRange === "35-44").reduce((sum, r) => sum + r.revenue, 0) },
                            { name: "45-54", Revenue: joinedResults.filter(r => r.matchedRight?.ageRange === "45-54").reduce((sum, r) => sum + r.revenue, 0) },
                          ] : [
                            { name: "Google Organic", Revenue: joinedResults.filter(r => r.traffic_source === "Google Organic").reduce((sum, r) => sum + r.revenue, 0), "Campaign Ad Spend": 0 },
                            { name: "Meta Social Ads", Revenue: joinedResults.filter(r => r.traffic_source === "Meta Social Ads").reduce((sum, r) => sum + r.revenue, 0), "Campaign Ad Spend": 1200 },
                            { name: "Email Campaign", Revenue: joinedResults.filter(r => r.traffic_source === "Email Campaign").reduce((sum, r) => sum + r.revenue, 0), "Campaign Ad Spend": 350 },
                            { name: "Influencer Referral", Revenue: joinedResults.filter(r => r.traffic_source === "Influencer Referral").reduce((sum, r) => sum + r.revenue, 0), "Campaign Ad Spend": 4500 },
                          ]
                        }
                        margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" className="dark:stroke-zinc-800/40" />
                        <XAxis dataKey="name" tickLine={false} style={{ fontSize: 9, fill: "#888" }} />
                        <YAxis tickLine={false} style={{ fontSize: 9, fill: "#888" }} tickFormatter={(v) => `$${v}`} />
                        <Tooltip contentStyle={{ backgroundColor: "#1e1e24", border: "none", borderRadius: 8, fontSize: 10, color: "#fff" }} />
                        <Bar 
                          dataKey="Revenue" 
                          fill="#06b6d4" 
                          radius={[4, 4, 0, 0]} 
                          maxBarSize={45}
                        />
                        {joinTable === "campaigns" && (
                          <Bar 
                            dataKey="Campaign Ad Spend" 
                            fill="#6366f1" 
                            radius={[4, 4, 0, 0]} 
                            maxBarSize={45} 
                          />
                        )}
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* First 5 raw output tuples */}
                <div className="space-y-2 text-left">
                  <h4 className="text-[10.5px] font-black text-gray-901 dark:text-white uppercase tracking-wider">Raw Joined Tuples (Limit 5 records)</h4>
                  <div className="overflow-x-auto border border-gray-150 dark:border-zinc-85 rounded-xl">
                    <table className="w-full text-left text-[10px] whitespace-nowrap">
                      <thead className="bg-gray-100 dark:bg-zinc-800 border-b border-gray-200 dark:border-zinc-800 text-gray-500 font-bold uppercase">
                        <tr>
                          <th className="p-2 pl-3">Table A Key</th>
                          <th className="p-2">Linkage Status</th>
                          <th className="p-2">{joinTable === "demographics" ? "Matched Customer Loyalty Profile (Table B)" : "Campaign Financial Record (Table B)"}</th>
                          <th className="p-2 pr-3 text-right">Row Revenue</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-150 dark:divide-zinc-85 font-medium text-gray-705 dark:text-zinc-300">
                        {joinedResults.slice(0, 5).map((j, idx) => (
                          <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-zinc-925">
                            <td className="p-2 pl-3 font-mono text-[9px] text-cyan-600 dark:text-cyan-400 font-bold">{j.joinKey}</td>
                            <td className="p-2">
                              <span className="text-[8.5px] bg-emerald-500/10 text-emerald-500 p-0.5 px-2 rounded-full font-bold">
                                🤝 MATCHED_RECORDS
                              </span>
                            </td>
                            <td className="p-2">
                              {joinTable === "demographics" ? (
                                <span className="p-1 px-1.5 rounded bg-indigo-50 dark:bg-zinc-850 text-[9.5px] text-gray-700 dark:text-zinc-300">
                                  Tier: <strong className="font-semibold text-indigo-600 dark:text-indigo-400">{j.matchedRight?.tier}</strong> | Age: <strong>{j.matchedRight?.ageRange}</strong> | Hobbyists: <strong>{j.matchedRight?.segment}</strong>
                                </span>
                              ) : (
                                <span className="p-1 px-1.5 rounded bg-purple-50 dark:bg-zinc-850 text-[9.5px] text-gray-700 dark:text-zinc-300">
                                  Campaign: <strong className="font-semibold text-purple-650 dark:text-purple-400">{j.matchedRight?.campaignName}</strong> | CPC: <strong>${j.matchedRight?.costPerClick}</strong> | Manager: <strong>{j.matchedRight?.leadManager}</strong>
                                </span>
                              )}
                            </td>
                            <td className="p-2 pr-3 text-right font-mono text-[9.5px] font-bold text-gray-808 dark:text-white">
                              ${j.revenue.toFixed(2)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>
            </>
          )}

          {/* ======================= TAB 2: COHORT SETS ======================= */}
          {gaTab === "set" && (
            <>
              {/* Left Column: Intersect Controls */}
              <div className="lg:col-span-4 p-4 rounded-2xl border border-gray-150 dark:border-zinc-805 space-y-4 bg-gray-55/30 dark:bg-zinc-950/40">
                <span className="text-[9.5px]/none uppercase font-black text-purple-505 bg-purple-500/10 px-2 py-0.5 rounded inline-block">
                  Venn Theory Simulator
                </span>
                <h3 className="text-xs font-bold text-gray-901 dark:text-white font-sans">Cohort Set Parameters</h3>
                <p className="text-[10.5px] text-gray-500 dark:text-zinc-400 leading-relaxed font-sans">
                  Design complex segment intersections (Sets A and B) to isolate key target cohorts. Click on set elements to run logical filters.
                </p>

                {/* Set A selector */}
                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-gray-400 uppercase block">Set A (Base Customer Base)</label>
                  <select
                    id="set-a-select"
                    value={setA}
                    onChange={(e) => setSetA(e.target.value as any)}
                    className="w-full text-xs p-2 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 outline-none rounded-lg text-gray-850 dark:text-zinc-200 font-medium"
                  >
                    <option value="all">All Registered Visitors (100%)</option>
                    <option value="cart_adders">Interactive Cart Adders (Cart Event Rows)</option>
                    <option value="purchasers">Paying Customer Goal Cohort (Purchasers)</option>
                  </select>
                </div>

                {/* Set B selector */}
                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-gray-400 uppercase block">Set B (Comparative Cohort)</label>
                  <select
                    id="set-b-select"
                    value={setB}
                    onChange={(e) => setB(e.target.value as any)}
                    className="w-full text-xs p-2 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 outline-none rounded-lg text-gray-850 dark:text-zinc-200 font-medium"
                  >
                    <option value="mobile">Mobile Devices & Tablet Browsers Users</option>
                    <option value="vip">High Lifetime Spenders (Total spent &gt; $80)</option>
                    <option value="organic">Organic Google Search / Direct Access</option>
                  </select>
                </div>

                {/* Select Results Type Buttons */}
                <div className="space-y-1 bg-white dark:bg-zinc-900 p-2.5 rounded-xl border border-gray-200 dark:border-zinc-85">
                  <span className="text-[8.5px] text-gray-400 uppercase font-bold block mb-1">Current Drill-down Operator</span>
                  <div className="space-y-1 text-xs">
                    <label className="flex items-center gap-2 cursor-pointer p-1.5 rounded hover:bg-gray-50 dark:hover:bg-zinc-850">
                      <input
                        type="radio"
                        name="set_result"
                        checked={selectedSetResultType === "intersection"}
                        onChange={() => setSelectedSetResultType("intersection")}
                        className="accent-indigo-600 cursor-pointer text-indigo-600 font-sans"
                      />
                      <div className="text-left font-semibold">
                        <span className="block text-gray-800 dark:text-white">Intersection Subset (A ∩ B)</span>
                        <span className="text-[9.5px] text-gray-400 font-medium">Users present in BOTH criteria({setResults.intersectionCount} users)</span>
                      </div>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer p-1.5 rounded hover:bg-gray-50 dark:hover:bg-zinc-850">
                      <input
                        type="radio"
                        name="set_result"
                        checked={selectedSetResultType === "union"}
                        onChange={() => setSelectedSetResultType("union")}
                        className="accent-indigo-600 cursor-pointer text-indigo-600 font-sans"
                      />
                      <div className="text-left font-semibold">
                        <span className="block text-gray-800 dark:text-white">Union Subset (A ∪ B)</span>
                        <span className="text-[9.5px] text-gray-400 font-medium">Users present in EITHER criteria({setResults.unionCount} users)</span>
                      </div>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer p-1.5 rounded hover:bg-gray-50 dark:hover:bg-zinc-850">
                      <input
                        type="radio"
                        name="set_result"
                        checked={selectedSetResultType === "difference"}
                        onChange={() => setSelectedSetResultType("difference")}
                        className="accent-indigo-600 cursor-pointer text-indigo-600 font-sans"
                      />
                      <div className="text-left font-semibold">
                        <span className="block text-gray-800 dark:text-white">Difference Subset (A - B)</span>
                        <span className="text-[9.5px] text-gray-400 font-medium">Users in Set A but NOT Set B({setResults.differenceCount} users)</span>
                      </div>
                    </label>
                  </div>
                </div>
              </div>

              {/* Right Column: Visual Venn Overlays & Drill-Down Members */}
              <div className="lg:col-span-8 space-y-6 text-left animate-fadeIn">
                
                {/* Visual Venn Overlays */}
                <div className="p-4 border border-gray-150 dark:border-zinc-805 rounded-2xl bg-white dark:bg-zinc-900/10">
                  <h4 className="text-xs font-black text-gray-901 dark:text-white uppercase tracking-wider mb-2">Venn Cohort Diagram Output</h4>
                  
                  {/* Interactive overlapping nodes */}
                  <div className="flex items-center justify-center py-6 bg-slate-50/50 dark:bg-zinc-950/20 rounded-xl border border-dashed border-gray-200 dark:border-zinc-815">
                    <div className="relative w-96 h-48 flex items-center justify-center">
                      
                      {/* Node A (Left Circle) */}
                      <div 
                        onClick={() => setSelectedSetResultType("difference")}
                        className={`absolute left-8 w-40 h-40 rounded-full border border-indigo-505 bg-indigo-550/10 dark:bg-indigo-950/30 flex flex-col items-center justify-center cursor-pointer transition-all hover:scale-[102%] ${
                          selectedSetResultType === "difference" ? "ring-4 ring-indigo-505/30 border-2 scale-[102%]" : "opacity-85"
                        }`}
                      >
                        <span className="text-[9px] font-black text-indigo-605 dark:text-indigo-400 uppercase tracking-tight text-center max-w-24 px-1 truncate">
                          {setResults.setAName}
                        </span>
                        <span className="text-2xl font-black text-gray-900 dark:text-white font-mono mt-1">
                          {setResults.sizeA}
                        </span>
                        <span className="text-[8px] bg-indigo-500/15 text-indigo-650 dark:text-indigo-400 p-0.5 px-1.5 rounded mt-2 font-bold uppercase">
                          A - B Diff
                        </span>
                      </div>

                      {/* Node B (Right Circle) */}
                      <div className="absolute right-8 w-40 h-40 rounded-full border border-purple-500 bg-purple-500/10 dark:bg-purple-950/20 flex flex-col items-center justify-center opacity-85 select-none">
                        <span className="text-[9px] font-black text-purple-650 dark:text-purple-400 uppercase tracking-tight text-center max-w-24 px-1 truncate">
                          {setResults.setBName}
                        </span>
                        <span className="text-2xl font-black text-gray-900 dark:text-white font-mono mt-1">
                          {setResults.sizeB}
                        </span>
                        <span className="text-[8px] text-purple-600 dark:text-purple-400 font-bold uppercase mt-2">
                          Cohort B Base
                        </span>
                      </div>

                      {/* Overlap area (Intersection Bubble) */}
                      <div 
                        onClick={() => setSelectedSetResultType("intersection")}
                        className={`absolute w-24 h-24 rounded-full border-2 border-cyan-400 bg-cyan-400/25 dark:bg-cyan-505/25 flex flex-col items-center justify-center cursor-pointer transition-all hover:scale-105 ${
                          selectedSetResultType === "intersection" ? "ring-4 ring-cyan-500/30 border-cyan-500" : ""
                        }`}
                        style={{ left: "calc(50% - 48px)" }}
                      >
                        <span className="text-[8px] uppercase tracking-tighter text-cyan-600 dark:text-cyan-300 font-black">
                          A ∩ B Match
                        </span>
                        <span className="text-lg font-black text-cyan-805 dark:text-cyan-200 font-mono">
                          {setResults.intersectionCount}
                        </span>
                        <span className="text-[7.5px] bg-cyan-500/30 text-cyan-805 dark:text-cyan-200 p-0.5 px-1.5 rounded-full font-bold">
                          Intersect
                        </span>
                      </div>

                    </div>
                  </div>
                </div>

                {/* Targeted User Listing */}
                <div className="space-y-2">
                  <h4 className="text-[10.5px] font-black text-gray-900 dark:text-white uppercase tracking-wider flex items-center justify-between">
                    <span>Subset User Profiles Drill-Down ({setResults.breakdownList.length} shown)</span>
                    <span className="text-[9px] bg-gray-100 dark:bg-zinc-800 text-gray-605 dark:text-zinc-350 p-1 px-2.5 rounded font-bold font-mono">
                      Query Mode: {selectedSetResultType.toUpperCase()}
                    </span>
                  </h4>
                  <div className="overflow-x-auto border border-gray-150 dark:border-zinc-85 rounded-xl">
                    <table className="w-full text-left text-[10px] whitespace-nowrap">
                      <thead className="bg-gray-100 dark:bg-zinc-800 border-b border-gray-200 dark:border-zinc-800 text-gray-500 font-bold uppercase">
                        <tr>
                          <th className="p-2 pl-3">User Identifier</th>
                          <th className="p-2">Representative Product Category</th>
                          <th className="p-2">Logged Channel</th>
                          <th className="p-2 pr-3">Geographic region</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-150 dark:divide-zinc-85 font-medium text-gray-700 dark:text-zinc-350">
                        {setResults.breakdownList.map((item, idx) => (
                          <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-zinc-925">
                            <td className="p-2 pl-3 font-mono text-[9px] text-purple-600 dark:text-purple-400 font-bold">{item.user_id}</td>
                            <td className="p-2 truncate max-w-44 text-gray-800 dark:text-white">{item.repProduct}</td>
                            <td className="p-2 font-semibold text-indigo-505">{item.repChannel}</td>
                            <td className="p-2 pr-3">{item.repRegion}</td>
                          </tr>
                        ))}
                        {setResults.breakdownList.length === 0 && (
                          <tr>
                            <td colSpan={4} className="text-center py-10 text-gray-550 text-xs text-medium">
                              Empty subset. Modify Set selections to compile and list overlapping members.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>
            </>
          )}

          {/* ======================= TAB 3: UNIONS ======================= */}
          {gaTab === "union" && (
            <>
              {/* Left Column: Union Merge Options */}
              <div className="lg:col-span-4 p-4 rounded-2xl border border-gray-150 dark:border-zinc-805 space-y-4 bg-gray-55/30 dark:bg-zinc-950/40">
                <span className="text-[9.5px]/none uppercase font-black text-indigo-505 bg-indigo-500/10 px-2 py-0.5 rounded inline-block">
                  Source Fusion
                </span>
                <h3 className="text-xs font-bold text-gray-901 dark:text-white">Multi-Channel Union</h3>
                <p className="text-[10.5px] text-gray-500 dark:text-zinc-400 leading-relaxed">
                  Combine distinct data sources (Online web platform clickstreams and Offline retail POS terminal lines) into a unified dataset structure.
                </p>

                {/* Source feeds overview */}
                <div className="space-y-2 text-left">
                  <span className="text-[8.5px] text-gray-400 uppercase font-bold block">Fusing Data Inputs</span>
                  
                  {/* Feed 1 */}
                  <div className="p-2 px-3 bg-white dark:bg-zinc-900 border border-gray-150 dark:border-zinc-85 rounded-lg text-xs font-semibold flex justify-between items-center">
                    <span className="text-gray-855 dark:text-zinc-200">Online Web Events</span>
                    <span className="text-[10px] bg-blue-500/10 text-blue-500 font-mono font-bold px-2 rounded-full">
                      {unionResults.onlineEventsCount} rows Ingested
                    </span>
                  </div>

                  {/* Feed 2 */}
                  <div className="p-2 px-3 bg-white dark:bg-zinc-900 border border-gray-150 dark:border-zinc-85 rounded-lg text-xs font-semibold flex justify-between items-center">
                    <span className="text-gray-855 dark:text-zinc-200">Offline Retail POS (CRM Feed)</span>
                    <span className="text-[10px] bg-orange-500/10 text-orange-550 font-mono font-bold px-2 rounded-full">
                      {unionResults.offlineEventsCount} rows Ingested
                    </span>
                  </div>
                </div>

                {/* Union Operator Logic */}
                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-gray-400 uppercase block">Union Mode</label>
                  <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
                    <button
                      id="btn-union-all"
                      onClick={() => setUnionType("all")}
                      className={`p-2 rounded-lg cursor-pointer text-center outline-none border transition-all ${
                        unionType === "all"
                          ? "bg-indigo-650 text-white border-indigo-600 dark:bg-indigo-600"
                          : "bg-white dark:bg-zinc-905 border-gray-200 dark:border-zinc-800 text-gray-700 dark:text-zinc-300 hover:bg-slate-50 dark:hover:bg-zinc-850"
                      }`}
                    >
                      UNION ALL (Keep duplicates)
                    </button>
                    <button
                      id="btn-union-distinct"
                      onClick={() => setUnionType("distinct")}
                      className={`p-2 rounded-lg cursor-pointer text-center outline-none border transition-all ${
                        unionType === "distinct"
                          ? "bg-indigo-650 text-white border-indigo-600 dark:bg-indigo-600"
                          : "bg-white dark:bg-zinc-905 border-gray-200 dark:border-zinc-800 text-gray-700 dark:text-zinc-300 hover:bg-slate-50 dark:hover:bg-zinc-850"
                      }`}
                    >
                      UNION DISTINCT (Deduplicate)
                    </button>
                  </div>
                </div>

                {/* Union Logic block */}
                <div className="p-3 bg-zinc-950 font-mono text-[9px] text-emerald-400/90 rounded-lg space-y-1">
                  <span className="text-gray-500 font-bold block">SQL Execution Statement:</span>
                  <p className="whitespace-pre-wrap leading-relaxed select-all">
                    {`SELECT user_id, timestamp, revenue\nFROM web_clicks_history\nUNION ${unionType === "all" ? "ALL" : "DISTINCT"}\nSELECT user_id, timestamp, revenue\nFROM offline_pos_ledgers`}
                  </p>
                </div>
              </div>

              {/* Right Column: Comparative chart and Union stream */}
              <div className="lg:col-span-8 space-y-6 text-left animate-fadeIn">
                
                {/* Comparative Doughnut-Style Share Chart */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 border border-gray-150 dark:border-zinc-800 rounded-2xl flex flex-col justify-between bg-white dark:bg-zinc-900/40">
                    <div>
                      <h4 className="text-xs font-black text-gray-901 dark:text-white uppercase tracking-wider">Fused Revenue Attribution share</h4>
                      <p className="text-[10px] text-gray-400 mt-0.5">Aggregated multi-channel performance ($USD).</p>
                    </div>
                    
                    <div className="h-40 flex items-center justify-center">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={unionResults.shareData}
                            cx="50%"
                            cy="50%"
                            innerRadius={45}
                            outerRadius={60}
                            paddingAngle={5}
                            dataKey="value"
                          >
                            <Cell fill="#06b6d4" />
                            <Cell fill="#f97316" />
                          </Pie>
                          <Tooltip formatter={(v) => `$${v.toLocaleString()}`} />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>

                    <div className="flex justify-center gap-4 text-[9.5px] font-bold">
                      <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-cyan-500 text-gray-700 dark:text-zinc-300"></span>Online: ${unionResults.shareData[0].value.toLocaleString()}</span>
                      <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-orange-550 text-gray-700 dark:text-zinc-300"></span>Retail Stores: ${unionResults.shareData[1].value.toLocaleString()}</span>
                    </div>
                  </div>

                  {/* Summary aggregate metrics box */}
                  <div className="p-5 border border-indigo-505/15 bg-indigo-5/10 dark:bg-indigo-950/20 rounded-2xl flex flex-col justify-between space-y-4">
                    <div className="space-y-1">
                      <span className="text-[8.5px] uppercase font-black text-indigo-505 tracking-widest block font-sans">Fused Core Ledger Stats</span>
                      <h3 className="text-sm font-black text-gray-900 dark:text-white font-sans">Multi-Source Union Successful</h3>
                      <p className="text-[11px] text-gray-500 dark:text-zinc-400 leading-relaxed font-sans">
                        Compiling browser timeline steps together with local offline retail entries records generates a larger database pool for deep cohort analytics.
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-2 border-t border-indigo-505/10 font-mono text-left">
                      <div>
                        <span className="block text-[8.5px] text-gray-400 uppercase">United Rows</span>
                        <strong className="block text-sm text-gray-950 dark:text-white">{unionResults.combinedRows.length} lines</strong>
                      </div>
                      <div>
                        <span className="block text-[8.5px] text-gray-400 uppercase font-bold text-gray-450">FUSED REVENUE</span>
                        <strong className="block text-sm text-indigo-600 dark:text-indigo-400">${Math.round(unionResults.unitedTotalRev).toLocaleString()}</strong>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Merged Stream Logs */}
                <div className="space-y-2">
                  <h4 className="text-[10.5px] font-black text-gray-901 dark:text-white uppercase tracking-wider">Merged Data Stream Terminal (Latest 5 Events)</h4>
                  <div className="overflow-x-auto border border-gray-150 dark:border-zinc-85 rounded-xl">
                    <table className="w-full text-left text-[10px] whitespace-nowrap">
                      <thead className="bg-gray-100 dark:bg-zinc-800 border-b border-gray-200 dark:border-zinc-800 text-gray-500 font-bold uppercase">
                        <tr>
                          <th className="p-2 pl-3">User Identifier</th>
                          <th className="p-2">Observed Activity</th>
                          <th className="p-2">Data Source Channel</th>
                          <th className="p-2">Location Context</th>
                          <th className="p-2 pr-3 text-right">Revenue</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-150 dark:divide-zinc-85 font-medium text-gray-700 dark:text-zinc-350">
                        {unionResults.combinedRows.slice(0, 5).map((u, idx) => (
                          <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-zinc-925">
                            <td className="p-2 pl-3 font-mono text-[9px] text-indigo-600 dark:text-indigo-400 font-bold">{u.user_id}</td>
                            <td className="p-2 font-semibold text-gray-901 dark:text-white">{u.activity}</td>
                            <td className="p-2">
                              <span className={`inline-block text-[8.5px] font-bold p-0.5 px-2 rounded-full ${
                                u.channel.includes("Online") ? "bg-blue-500/10 text-blue-500" : "bg-orange-500/10 text-orange-550"
                              }`}>
                                {u.channel}
                              </span>
                            </td>
                            <td className="p-2 font-mono text-[9px] text-gray-450">{u.location}</td>
                            <td className={`p-2 pr-3 text-right font-mono text-[9.5px] font-bold ${u.revenue > 0 ? "text-emerald-500" : u.revenue < 0 ? "text-rose-500" : "text-gray-400"}`}>
                              {u.revenue !== 0 ? `$${u.revenue.toFixed(2)}` : "—"}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>
            </>
          )}

          {/* ======================= TAB 4: GROUP DISTINCT ======================= */}
          {gaTab === "distinct" && (
            <>
              {/* Left Column: Group controls */}
              <div className="lg:col-span-4 p-4 rounded-2xl border border-gray-150 dark:border-zinc-805 space-y-4 bg-gray-55/30 dark:bg-zinc-950/40">
                <span className="text-[9.5px]/none uppercase font-black text-indigo-505 bg-indigo-500/10 px-2 py-0.5 rounded inline-block">
                  SQL GROUP BY
                </span>
                <h3 className="text-xs font-bold text-gray-910 dark:text-white">Count Distinct Optimizer</h3>
                <p className="text-[10.5px] text-gray-500 dark:text-zinc-400 leading-relaxed">
                  Run standard SQL `COUNT(DISTINCT item)` routines on database dimensions to isolate active cohorts and calculate structural uniqueness ratios.
                </p>

                {/* Group Dimension selector */}
                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-gray-400 uppercase block">Group Dimension Column</label>
                  <select
                    id="distinct-dim-select"
                    value={distinctDimension}
                    onChange={(e) => setDistinctDimension(e.target.value as any)}
                    className="w-full text-xs p-2 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 outline-none rounded-lg text-gray-850 dark:text-zinc-200 font-medium"
                  >
                    <option value="region">Geographic Trading Region (region)</option>
                    <option value="device_type">Visitor Device Browser (device_type)</option>
                    <option value="traffic_source">Marketing Funnel / Channel (traffic_source)</option>
                    <option value="category">Product Inventory Category (category)</option>
                  </select>
                </div>

                {/* Distinct target metric selector */}
                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-gray-400 uppercase block">Count Unique (Distinct Target)</label>
                  <select
                    id="distinct-metric-select"
                    value={distinctMetric}
                    onChange={(e) => setDistinctMetric(e.target.value as any)}
                    className="w-full text-xs p-2 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 outline-none rounded-lg text-gray-850 dark:text-zinc-200 font-medium"
                  >
                    <option value="user_id">Count Distinct User Profiles (COUNT(DISTINCT user_id))</option>
                    <option value="session_id">Count Distinct Active Sessions (COUNT(DISTINCT session_id))</option>
                    <option value="product_id">Count Distinct Inventory SKU items (COUNT(DISTINCT product_id))</option>
                  </select>
                </div>

                {/* SQL Code Block */}
                <div className="p-3 bg-zinc-950 font-mono text-[9px] text-emerald-400/90 rounded-lg space-y-1">
                  <span className="text-gray-500 font-bold block">SQL Statement:</span>
                  <p className="whitespace-pre-wrap leading-relaxed select-all">
                    {`SELECT \n  ${distinctDimension},\n  COUNT(1) as total_events,\n  COUNT(DISTINCT ${distinctMetric}) as unique_${distinctMetric},\n  SUM(revenue) as total_rev\nFROM web_logs\nGROUP BY ${distinctDimension}`}
                  </p>
                </div>
              </div>

              {/* Right Column: Visualization Chart & Aggregation spreadsheet */}
              <div className="lg:col-span-8 space-y-6 text-left animate-fadeIn">
                
                {/* Visual grouping chart */}
                <div className="p-4 border border-gray-150 dark:border-zinc-800 rounded-2xl space-y-3">
                  <h4 className="text-xs font-black text-gray-901 dark:text-white uppercase tracking-wider font-sans">Distinct Count Group Attribution Chart</h4>
                  
                  <div className="h-56">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={distinctGroupsResults} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" className="dark:stroke-zinc-800/40" />
                        <XAxis dataKey="dimensionValue" tickLine={false} style={{ fontSize: 9, fill: "#888" }} />
                        <YAxis tickLine={false} style={{ fontSize: 9, fill: "#888" }} />
                        <Tooltip contentStyle={{ backgroundColor: "#1e1e24", border: "none", borderRadius: 8, fontSize: 10, color: "#fff" }} />
                        <Bar dataKey="distinctCount" fill="#4f46e5" radius={[4, 4, 0, 0]} maxBarSize={45} name={`Unique ${distinctMetric}`} />
                        <Bar dataKey="totalCount" fill="#dbdbdb" radius={[4, 4, 0, 0]} maxBarSize={45} name="Total logs count" className="opacity-40" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Structured groups table */}
                <div className="space-y-2">
                  <h4 className="text-[10.5px] font-black text-gray-905 dark:text-white uppercase tracking-wider">Group aggregation table output</h4>
                  <div className="overflow-x-auto border border-gray-150 dark:border-zinc-85 rounded-xl">
                    <table className="w-full text-left text-[10px] whitespace-nowrap">
                      <thead className="bg-gray-100 dark:bg-zinc-800 border-b border-gray-200 dark:border-zinc-800 text-gray-500 font-bold uppercase">
                        <tr>
                          <th className="p-2 pl-3">Group Dimension Value</th>
                          <th className="p-2">Total Rows Trace Count</th>
                          <th className="p-2 text-indigo-505 font-bold">COUNT(DISTINCT {distinctMetric})</th>
                          <th className="p-2 opacity-80">Unique-to-Total Ratio</th>
                          <th className="p-2 pr-3 text-right">Summed Revenue Contribution</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-150 dark:divide-zinc-85 font-medium text-gray-750 dark:text-zinc-300">
                        {distinctGroupsResults.map((gp, idx) => (
                          <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-zinc-925">
                            <td className="p-2 pl-3 font-bold text-gray-901 dark:text-white capitalize">{gp.dimensionValue}</td>
                            <td className="p-2 font-mono">{gp.totalCount} transactions</td>
                            <td className="p-2 font-mono font-bold text-indigo-650 dark:text-indigo-400 text-xs">
                              👥 {gp.distinctCount}
                            </td>
                            <td className="p-2">
                              <div className="flex items-center gap-1.5 font-mono text-[9.5px]">
                                <div className="w-12 h-1.5 rounded-full bg-gray-200 dark:bg-zinc-800 overflow-hidden shrink-0">
                                  <div className="h-full bg-cyan-505" style={{ width: `${Math.min(100, gp.uniquenessRatio)}%` }}></div>
                                </div>
                                {gp.uniquenessRatio}%
                              </div>
                            </td>
                            <td className="p-2 pr-3 text-right font-mono text-[10px] font-bold text-emerald-505">
                              ${gp.associatedRevenue.toLocaleString()}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>
            </>
          )}

          {/* ======================= TAB 5: CUSTOM METRICS STUDIO ======================= */}
          {gaTab === "studio" && (
            <>
              {/* Left Column: Studio Builder panel */}
              <div className="lg:col-span-4 p-4 rounded-2xl border border-gray-150 dark:border-zinc-805 space-y-4 bg-gradient-to-br from-white to-gray-55/30 dark:from-zinc-900 dark:to-zinc-950/20">
                <span className="text-[9.5px]/none uppercase font-black text-rose-550 bg-rose-500/10 px-2.5 py-1 rounded inline-block animate-pulse font-bold">
                  ✨ Metric Compiler Hub
                </span>
                <h3 className="text-xs font-bold text-gray-901 dark:text-white">Dynamic Chart Studio</h3>
                <p className="text-[10.5px] text-gray-500 dark:text-zinc-400 leading-relaxed font-sans mt-1">
                  Build custom visualization matrices exactly like Google Analytics Explore reports. Choose dimensions, metrics, and chart models instantly.
                </p>

                {/* X Selector */}
                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-gray-400 uppercase block">Horizontal Axis (X-Axis Segment)</label>
                  <select
                    id="studio-x-select"
                    value={studioX}
                    onChange={(e) => setStudioX(e.target.value as any)}
                    className="w-full text-xs p-2 bg-white dark:bg-zinc-930 border border-gray-200 dark:border-zinc-800 outline-none rounded-lg text-gray-850 dark:text-zinc-200 font-medium"
                  >
                    <option value="region">Sales Trading Region (region)</option>
                    <option value="device_type">Visitor Device Platform (device_type)</option>
                    <option value="traffic_source">Marketing Ingress Funnel (traffic_source)</option>
                    <option value="category">Retail Inventory Product Line </option>
                  </select>
                </div>

                {/* Y Selector */}
                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-gray-400 uppercase block">Vertical Height (Y-Axis Metric Value)</label>
                  <select
                    id="studio-y-select"
                    value={studioY}
                    onChange={(e) => setStudioY(e.target.value as any)}
                    className="w-full text-xs p-2 bg-white dark:bg-zinc-930 border border-gray-200 dark:border-zinc-800 outline-none rounded-lg text-gray-850 dark:text-zinc-200 font-medium"
                  >
                    <option value="revenue">Cumulative Sales General GMV ($ USD)</option>
                    <option value="ordersCount">Compounded Complete checkout Count (Units)</option>
                    <option value="distinctUsersCount">Unique Profiles Ingest Count (Count Distinct)</option>
                  </select>
                </div>

                {/* Visualizer Type */}
                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-gray-400 uppercase block">Visual Graphic Model</label>
                  <div className="grid grid-cols-4 gap-1.5 text-center text-[10.5px] font-bold">
                    <button
                      id="btn-studio-bar"
                      onClick={() => setStudioChartType("bar")}
                      className={`p-1.5 rounded-lg cursor-pointer outline-none border transition-all ${
                        studioChartType === "bar" ? "bg-cyan-500/10 text-cyan-600 border-cyan-505" : "bg-white dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 text-gray-400 cursor-pointer"
                      }`}
                    >
                      Bar
                    </button>
                    <button
                      id="btn-studio-line"
                      onClick={() => setStudioChartType("line")}
                      className={`p-1.5 rounded-lg cursor-pointer outline-none border transition-all ${
                        studioChartType === "line" ? "bg-indigo-505/10 text-indigo-505 border-indigo-505" : "bg-white dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 text-gray-400 cursor-pointer"
                      }`}
                    >
                      Line
                    </button>
                    <button
                      id="btn-studio-area"
                      onClick={() => setStudioChartType("area")}
                      className={`p-1.5 rounded-lg cursor-pointer outline-none border transition-all ${
                        studioChartType === "area" ? "bg-purple-500/10 text-purple-605 border-purple-505" : "bg-white dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 text-gray-400 cursor-pointer"
                      }`}
                    >
                      Area
                    </button>
                    <button
                      id="btn-studio-pie"
                      onClick={() => setStudioChartType("pie")}
                      className={`p-1.5 rounded-lg cursor-pointer outline-none border transition-all ${
                        studioChartType === "pie" ? "bg-pink-505/10 text-pink-550 border-pink-505" : "bg-white dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 text-gray-400 cursor-pointer"
                      }`}
                    >
                      Pie
                    </button>
                  </div>
                </div>

                {/* Legend indicator */}
                <div className="p-3 bg-indigo-50/20 dark:bg-indigo-950/20 border border-indigo-505/10 rounded-lg text-[10px] text-indigo-750 dark:text-indigo-400 leading-relaxed font-sans">
                  <div className="flex gap-2 items-center">
                    <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0" />
                    <span>Real-time calculation mapped to active spreadsheet filters. Changes map instantly.</span>
                  </div>
                </div>
              </div>

              {/* Right Column: Custom Studio Active Render Canvas */}
              <div className="lg:col-span-8 border border-gray-150 dark:border-zinc-805 rounded-2xl p-4 bg-white dark:bg-zinc-900/40 relative space-y-4 text-left animate-fadeIn">
                <div className="flex items-center justify-between pb-2 border-b border-gray-100 dark:border-zinc-805">
                  <h4 className="text-xs font-black text-gray-901 dark:text-white uppercase tracking-wider font-sans">
                    Studio visualization Canvas
                  </h4>
                  <span className="text-[9px] font-mono uppercase bg-emerald-500/10 text-emerald-500 font-bold p-0.5 px-2 rounded-full flex items-center gap-1.5">
                    <Clock className="h-3 w-3" /> Operational Live Stream
                  </span>
                </div>

                {/* Display Canvas area */}
                <div className="h-64 flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    {studioChartType === "bar" ? (
                      <BarChart data={studioChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" className="dark:stroke-zinc-800/40" />
                        <XAxis dataKey="name" tickLine={false} style={{ fontSize: 9, fill: "#888" }} />
                        <YAxis tickLine={false} style={{ fontSize: 9, fill: "#888" }} />
                        <Tooltip contentStyle={{ backgroundColor: "#1e1e24", border: "none", borderRadius: 8, fontSize: 10, color: "#fff" }} />
                        <Bar dataKey={studioY} fill="#0d9488" radius={[4, 4, 0, 0]} maxBarSize={45}>
                          {studioChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={["#06b6d4", "#6366f1", "#a855f7", "#ec4899", "#f59e0b", "#10b981"][index % 6]} />
                          ))}
                        </Bar>
                      </BarChart>
                    ) : studioChartType === "line" ? (
                      <LineChart data={studioChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" className="dark:stroke-zinc-800/40" />
                        <XAxis dataKey="name" tickLine={false} style={{ fontSize: 9, fill: "#888" }} />
                        <YAxis tickLine={false} style={{ fontSize: 9, fill: "#888" }} />
                        <Tooltip contentStyle={{ backgroundColor: "#1e1e24", border: "none", borderRadius: 8, fontSize: 10, color: "#fff" }} />
                        <Line type="monotone" dataKey={studioY} stroke="#3b82f6" strokeWidth={3} dot={{ r: 5 }} />
                      </LineChart>
                    ) : studioChartType === "area" ? (
                      <AreaChart data={studioChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                        <defs>
                          <linearGradient id="studioGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.4}/>
                            <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" className="dark:stroke-zinc-800/40" />
                        <XAxis dataKey="name" tickLine={false} style={{ fontSize: 9, fill: "#888" }} />
                        <YAxis tickLine={false} style={{ fontSize: 9, fill: "#888" }} />
                        <Tooltip contentStyle={{ backgroundColor: "#1e1e24", border: "none", borderRadius: 8, fontSize: 10, color: "#fff" }} />
                        <Area type="monotone" dataKey={studioY} stroke="#4f46e5" strokeWidth={2.5} fillOpacity={1} fill="url(#studioGradient)" />
                      </AreaChart>
                    ) : (
                      <PieChart>
                        <Pie
                          data={studioChartData}
                          cx="50%"
                          cy="50%"
                          outerRadius={80}
                          paddingAngle={3}
                          dataKey={studioY}
                        >
                          {studioChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={["#06b6d4", "#6366f1", "#a855f7", "#ec4899", "#f59e0b", "#10b981"][index % 6]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    )}
                  </ResponsiveContainer>
                </div>

                {/* Custom metrics values breakdown metrics widgets */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 text-center text-xs font-mono font-medium border-t border-gray-100 dark:border-zinc-85">
                  {studioChartData.slice(0, 4).map((entry, idx) => (
                    <div key={idx} className="p-2 border border-gray-100 dark:border-zinc-850 bg-slate-55/35 dark:bg-zinc-950/20 rounded-xl leading-relaxed">
                      <span className="block text-[8px] text-gray-400 uppercase truncate font-bold">{entry.name}</span>
                      <strong className="block text-xs text-gray-950 dark:text-zinc-100">
                        {studioY === "revenue" ? `$${entry.revenue.toLocaleString()}` : studioY === "ordersCount" ? `${entry.ordersCount} checkouts` : `${entry.distinctUsersCount} users`}
                      </strong>
                    </div>
                  ))}
                </div>

              </div>
            </>
          )}

        </div>

        {/* AI ATTRIBUTION EXAMINER & ACTIONABLE STEPS */}
        <div id="ai-attribution-insights-card" className="mt-6 p-4 rounded-2xl bg-gradient-to-r from-cyan-500/[0.03] to-indigo-500/[0.03] dark:from-cyan-950/30 dark:to-indigo-950/30 border border-cyan-505/15 flex flex-col sm:flex-row items-start gap-4 text-left">
          <div className="h-10 w-10 shrink-0 rounded-full bg-cyan-50/60 dark:bg-cyan-955/40 border border-cyan-150 dark:border-cyan-900 flex items-center justify-center text-cyan-600 dark:text-cyan-405">
            <Sparkles className="h-5 w-5 animate-pulse" />
          </div>
          <div className="space-y-1.5 flex-1 text-left">
            <span className="text-[10px]/none uppercase font-black text-cyan-600 dark:text-cyan-400 tracking-wider">ConvertIQ AI Attribution Insights</span>
            <div className="text-xs text-gray-800 dark:text-zinc-300 leading-relaxed font-sans mt-1">
              {gaTab === "join" && (
                <p>
                  <strong>Relational Joins Attribution Summary:</strong> Merging logs with 3rd-party profile dictionaries highlights high concentration segments. Users matching demographic profiles for the <strong className="font-semibold text-cyan-605">"VIP Double Diamond"</strong> tier have generated a massive spend value. Retarget VIP Elite customers in the Americas region to optimize CAC profiles.
                </p>
              )}
              {gaTab === "set" && (
                <p>
                  <strong>Cohort Venn Set Attribution Summary:</strong> The set intersection reveals that <strong className="font-semibold text-purple-600">Mobile Devices Users</strong> account for a dominant share of the shopping cart abandoners subset. This mathematical overlap suggests visual forms friction on Safari and Android browsers. Streamline mobile address verification pipelines to bypass dropoffs.
                </p>
              )}
              {gaTab === "union" && (
                <p>
                  <strong>Multi-Channel Union Attribution Summary:</strong> Combining Online Web events with Offline Store POS feeds reveals that physical boutiques contribute a significant portion of the consolidated Merchandising Volume. Users like <span className="font-mono bg-orange-100 dark:bg-orange-950 text-orange-600 dark:text-orange-400 px-1 rounded text-[10.5px]">"usr_101"</span> indicate cross-channel loyalty, shopping both online and experiencing bespoke showroom exchanges.
                </p>
              )}
              {gaTab === "distinct" && (
                <p>
                  <strong>SQL Group Distinct Summary:</strong> Executed dynamic SQL routines demonstrate high variation in uniqueness ratios. Grouping transactions by <span className="font-mono bg-cyan-105 dark:bg-cyan-950 text-cyan-600 dark:text-cyan-400 px-1 rounded text-[10.5px]">{distinctDimension}</span> shows a uniqueness ratio of the target distinct variable that averages 25%. Lower ratios suggest repetitive customer interactions, reinforcing strong brand retention.
                </p>
              )}
              {gaTab === "studio" && (
                <p>
                  <strong>Metric Studio Summary:</strong> Custom report compilation highlights that grouping the database by <span className="font-semibold text-teal-650 dark:text-teal-400">{studioX}</span> shows a strong skew across the vertically compiled measure <span className="font-semibold text-indigo-650 dark:text-indigo-400">{studioY}</span>. Focus budget expansion on key high-density categories to scale optimization loops safely offline.
                </p>
              )}
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
