import { useState, useEffect, useRef } from "react";
import {
  GitMerge,
  Grid3X3,
  Users,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  HelpCircle,
  Filter,
  Layers,
  ArrowDownRight,
  Sparkles,
  RefreshCw,
  ShoppingBag,
  Home as HomeIcon,
  Tag,
  Package,
  ShoppingCart,
  Receipt,
  XCircle,
  CheckCircle,
  ArrowUpRight,
  Inbox
} from "lucide-react";
import { UnifiedMetrics, GlobalFilters, IngestedRecord, ActiveTab } from "../types";

interface CustomerJourneyCohortProps {
  metrics: UnifiedMetrics;
  filters: GlobalFilters;
  setFilters: (filters: GlobalFilters) => void;
  isSimulating: boolean;
  uploadedData: IngestedRecord[];
  activeTab: any;
}

// Map record to standard stage name
function getStageName(rec: IngestedRecord): string {
  const ev = (rec.event_type || "").trim().toLowerCase();
  const cat = (rec.category || "").trim().toLowerCase();
  const prod = (rec.product_name || "").trim().toLowerCase();
  
  if (ev === "purchase" || ev === "order") return "Purchase";
  if (ev === "checkout") return "Checkout";
  if (ev === "cart" || ev === "add_to_cart") return "Cart";
  
  if (ev === "view") {
    if (prod && prod !== "undefined" && prod !== "") return "Product";
    if (cat && cat !== "home" && cat !== "landing" && cat !== "undefined" && cat !== "") return "Category";
    return "Home";
  }
  
  if (ev === "home") return "Home";
  if (ev === "category") return "Category";
  if (ev === "product") return "Product";
  
  return "Home"; // default fallback
}

export default function CustomerJourneyCohort({
  metrics,
  filters,
  setFilters,
  isSimulating,
  uploadedData,
  activeTab
}: CustomerJourneyCohortProps) {
  const [activeSubTab, setActiveSubTab] = useState<"journey" | "retention">(
    activeTab === "cohort" ? "retention" : "journey"
  );
  const [plotlyLoaded, setPlotlyLoaded] = useState(false);
  const [isChartRendering, setIsChartRendering] = useState(false);
  const [activePathTab, setActivePathTab] = useState<"common" | "high" | "exits">("common");

  // Filter option definitions matching the visual style of conversion module
  const dateOptions = [
    { value: "30d", label: "Last 30 Days" },
    { value: "7d", label: "Last 7 Days" },
    { value: "90d", label: "Last 90 Days" }
  ];

  const deviceOptions = [
    { value: "all", label: "All Devices" },
    { value: "Desktop", label: "Desktop Terminals" },
    { value: "Mobile", label: "Mobile Browsers" },
    { value: "Tablet", label: "Tablet Displays" }
  ];

  const regionOptions = [
    { value: "all", label: "All Regions" },
    { value: "Americas", label: "Americas Segment" },
    { value: "Europe", label: "Europe Segment" },
    { value: "APAC", label: "APAC Segment" },
    { value: "MEA", label: "MEA Segment" }
  ];

  const channelOptions = [
    { value: "all", label: "All Referrals" },
    { value: "Google Organic", label: "Google Organic" },
    { value: "Meta Social", label: "Meta Social Ads" },
    { value: "Influencer", label: "Instagram Influencer" },
    { value: "Email Campaign", label: "Email Newsletter" },
    { value: "Direct", label: "Direct Traffic" }
  ];

  // Load Plotly CDN Dynamically
  useEffect(() => {
    if ((window as any).Plotly) {
      setPlotlyLoaded(true);
      return;
    }

    setIsChartRendering(true);
    const script = document.createElement("script");
    script.src = "https://cdn.plot.ly/plotly-2.24.1.min.js";
    script.async = true;
    script.onload = () => {
      setPlotlyLoaded(true);
      setIsChartRendering(false);
    };
    script.onerror = () => {
      console.error("Failed to load Plotly script.");
      setIsChartRendering(false);
    };
    document.head.appendChild(script);
  }, []);

  // Sync sub tab selection on active sidebar tab clicks
  useEffect(() => {
    setActiveSubTab(activeTab === "cohort" ? "retention" : "journey");
  }, [activeTab]);

  const [cohortMetricView, setCohortMetricView] = useState<"retention" | "repeatRate" | "lifetimeTrend">("retention");

  // -------------------------------------------------------------
  // COHORT ANALYSIS MATH ENGINE
  // -------------------------------------------------------------
  interface CohortMetrics {
    cohortName: string;
    size: number;
    retention: number[]; // Month 0, Month 1, Month 2, Month 3
    repeatRate: number[]; // % with multiple purchases up to Month X
    cumulativeRevenue: number[]; // Cumulative LTV ($)
    churnRate: number[]; // Churn Rate (100 - retention)
  }

  let computedCohorts: CohortMetrics[] = [];

  if (!isSimulating && uploadedData && uploadedData.length > 0) {
    // 1. Filter raw records representing purchases
    const purchases = (uploadedData || []).filter(record => {
      const isPurchase = record.event_type.toLowerCase() === "purchase" || record.event_type.toLowerCase() === "order";
      if (!isPurchase) return false;

      // Region Filter
      if (filters.region !== "all") {
        const matchRegion = record.region.toLowerCase().includes(filters.region.toLowerCase()) || 
                            filters.region.toLowerCase().includes(record.region.toLowerCase());
        if (!matchRegion) return false;
      }

      // Device Type Filter
      if (filters.device !== "all") {
        if (record.device_type.toLowerCase() !== filters.device.toLowerCase()) return false;
      }

      // Traffic Source Filter
      if (filters.channel !== "all") {
        const matchChannel = record.traffic_source.toLowerCase().includes(filters.channel.toLowerCase()) ||
                             filters.channel.toLowerCase().includes(record.traffic_source.toLowerCase());
        if (!matchChannel) return false;
      }

      return true;
    });

    // 2. Find earliest purchase date per user
    const firstPurchases = new Map<string, { date: Date; monthKey: string; monthName: string }>();
    
    purchases.forEach(rec => {
      const uId = rec.user_id || "unknown";
      const recDate = new Date(rec.timestamp);
      if (isNaN(recDate.getTime())) return;

      const existing = firstPurchases.get(uId);
      if (!existing || recDate < existing.date) {
        const y = recDate.getUTCFullYear();
        const m = recDate.getUTCMonth();
        const monthKey = `${y}-${String(m + 1).padStart(2, "0")}`; // e.g. "2026-03"
        const monthName = recDate.toLocaleDateString("en-US", { month: "short", year: "numeric" });
        firstPurchases.set(uId, { date: recDate, monthKey, monthName });
      }
    });

    // Group users by cohort month
    const cohortUserGroups = new Map<string, { cohortName: string; userIds: Set<string> }>();
    firstPurchases.forEach((val, uId) => {
      if (!cohortUserGroups.has(val.monthKey)) {
        cohortUserGroups.set(val.monthKey, { cohortName: val.monthName, userIds: new Set() });
      }
      cohortUserGroups.get(val.monthKey)!.userIds.add(uId);
    });

    // Sort cohort keys chronologically
    const sortedCohortKeys = Array.from(cohortUserGroups.keys()).sort();

    // 3. For each cohort, calculate retention & LTV over relative month 0, 1, 2, 3
    computedCohorts = sortedCohortKeys.map(cKey => {
      const grp = cohortUserGroups.get(cKey)!;
      const cohortName = grp.cohortName;
      const cohortUsers = grp.userIds;
      const cohortSize = cohortUsers.size || 1;

      // Identify corresponding year and month of cohort
      const [cY, cM] = cKey.split("-").map(Number);
      const activeUsersInMonths = [new Set<string>(), new Set<string>(), new Set<string>(), new Set<string>()];
      const revenuesInMonths = [0, 0, 0, 0];

      // Scan all purchases for users in this cohort
      purchases.forEach(rec => {
        const uId = rec.user_id || "unknown";
        if (!cohortUsers.has(uId)) return; // not in this cohort

        const recPercentDate = new Date(rec.timestamp);
        if (isNaN(recPercentDate.getTime())) return;

        const pY = recPercentDate.getUTCFullYear();
        const pM = recPercentDate.getUTCMonth();

        const diffMonths = (pY * 12 + pM) - (cY * 12 + (cM - 1));
        if (diffMonths >= 0 && diffMonths <= 3) {
          activeUsersInMonths[diffMonths].add(uId);
          revenuesInMonths[diffMonths] += Number(rec.revenue || 0);
        }
      });

      // Calculate final relative statistics
      const retention = [
        100,
        parseFloat(((activeUsersInMonths[1].size / cohortSize) * 100).toFixed(1)),
        parseFloat(((activeUsersInMonths[2].size / cohortSize) * 100).toFixed(1)),
        parseFloat(((activeUsersInMonths[3].size / cohortSize) * 100).toFixed(1))
      ];

      // Repeat purchase rate: % of cohort users who made overall cumulative repeat purchases up to Month X (>= 2 purchases total)
      const repeatUsersInMonths = [0, 0, 0, 0];
      
      cohortUsers.forEach(uId => {
        const userPurchases = purchases.filter(rec => rec.user_id === uId).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
        let purchaseCount = 0;
        
        userPurchases.forEach(rec => {
          const recPercentDate = new Date(rec.timestamp);
          const pY = recPercentDate.getUTCFullYear();
          const pM = recPercentDate.getUTCMonth();
          const diffMonths = (pY * 12 + pM) - (cY * 12 + (cM - 1));
          
          if (diffMonths >= 0 && diffMonths <= 3) {
            purchaseCount++;
            if (purchaseCount >= 2) {
              for (let m = diffMonths; m <= 3; m++) {
                repeatUsersInMonths[m]++;
              }
            }
          }
        });
      });

      const repeatRate = [
        parseFloat((Math.min(cohortSize, repeatUsersInMonths[0]) / cohortSize * 100).toFixed(1)),
        parseFloat((Math.min(cohortSize, repeatUsersInMonths[1]) / cohortSize * 100).toFixed(1)),
        parseFloat((Math.min(cohortSize, repeatUsersInMonths[2]) / cohortSize * 100).toFixed(1)),
        parseFloat((Math.min(cohortSize, repeatUsersInMonths[3]) / cohortSize * 100).toFixed(1))
      ];

      // Cumulative Lifetime spend trend (LTV)
      let cumRev = 0;
      const cumulativeRevenue = [0, 0, 0, 0].map((_, idx) => {
        cumRev += revenuesInMonths[idx];
        return parseFloat((cumRev / cohortSize).toFixed(2));
      });

      const churnRate = retention.map(r => parseFloat((100 - r).toFixed(1)));

      return {
        cohortName,
        size: cohortSize,
        retention,
        repeatRate,
        cumulativeRevenue,
        churnRate
      };
    });
  }

  // Fallback simulator cohorts when isSimulating is true or uploadedData is empty or yields no cohorts
  if (computedCohorts.length === 0) {
    const months = ["Jan 2026", "Feb 2026", "Mar 2026", "Apr 2026", "May 2026"];
    
    // Scale factor based on active filters
    let sizeScale = 1.0;
    let retentionBoost = 0;
    
    if (filters.device === "Desktop") {
      sizeScale = 1.1;
      retentionBoost = 4.5;
    } else if (filters.device === "Mobile") {
      sizeScale = 1.25;
      retentionBoost = -5.0;
    }

    if (filters.channel === "Email Campaign") {
      retentionBoost += 8.0;
    } else if (filters.channel === "Meta Social") {
      sizeScale *= 1.2;
      retentionBoost -= 3.5;
    }

    if (filters.region === "Americas") {
      retentionBoost += 2.5;
    } else if (filters.region === "MEA") {
      retentionBoost -= 4.0;
    }

    computedCohorts = months.map((month, idx) => {
      const baseSizes = [1250, 1420, 1510, 1680, 1950];
      const size = Math.round(baseSizes[idx] * sizeScale);

      // Month retention curves around base average (Month 0 (100%), Month 1, Month 2, Month 3)
      const baseCurves = [
        [100, 24.2, 16.5, 12.8], // Jan
        [100, 26.8, 18.2, 14.1], // Feb
        [100, 22.4, 15.1, 11.2], // Mar
        [100, 25.1, 17.4, 12.9], // Apr
        [100, 27.5, 19.1, 13.8], // May
      ];

      const retention = baseCurves[idx].map((r, rIdx) => {
        if (rIdx === 0) return 100;
        let finalVal = r + retentionBoost;
        if (finalVal < 2) finalVal = 2;
        if (finalVal > 95) finalVal = 95;
        return parseFloat(finalVal.toFixed(1));
      });

      // Repeat purchase curve (cumulative % of people with multiple purchases)
      const repeatCurveBase = [5.5, 12.4, 18.2, 22.8];
      const repeatRate = repeatCurveBase.map((rep, rIdx) => {
        let val = rep + retentionBoost * 0.4 + (idx * 0.8);
        if (val < 1) val = 1;
        if (val > 80) val = 80;
        return parseFloat(val.toFixed(1));
      });

      // LTV trend (cumulative average spends per user)
      const averageSvs = [84.50, 89.20, 93.40, 95.80];
      const baseSpendInRelativeMonth = [
        averageSvs[idx % 4],
        averageSvs[idx % 4] * 0.35,
        averageSvs[idx % 4] * 0.28,
        averageSvs[idx % 4] * 0.22
      ];

      let runningSpendSum = 0;
      const cumulativeRevenue = baseSpendInRelativeMonth.map((s, rIdx) => {
        // Adjust spend based on retention curves
        const mult = (retention[rIdx] / 100) * 1.8 + 0.2;
        runningSpendSum += s * mult;
        return parseFloat(runningSpendSum.toFixed(2));
      });

      const churnRate = retention.map(r => parseFloat((100 - r).toFixed(1)));

      return {
        cohortName: month,
        size,
        retention,
        repeatRate,
        cumulativeRevenue,
        churnRate
      };
    });
  }

  // Draw/Redraw Plotly Cohort Heatmap
  useEffect(() => {
    if (!plotlyLoaded || activeSubTab !== "retention" || computedCohorts.length === 0) return;

    const timer = setTimeout(() => {
      const el = document.getElementById("plotly-cohort-heatmap-canvas");
      if (!el) return;

      const isDark = document.documentElement.classList.contains("dark");

      const xLabels = ["Month 0", "Month 1", "Month 2", "Month 3"];
      const reverseCohorts = [...computedCohorts].reverse();
      const yLabelsReverse = reverseCohorts.map(c => `${c.cohortName} (n=${c.size})`);
      
      let zValues: number[][] = [];
      let textValues: string[][] = [];
      let colorScaleColors: any[] = [];
      let titleName = "Retention Rate (%)";
      let isCurrency = false;

      if (cohortMetricView === "retention") {
        zValues = reverseCohorts.map(c => c.retention);
        textValues = reverseCohorts.map(c => c.retention.map(v => `${v}%`));
        titleName = "Retention Rate";
        colorScaleColors = isDark 
          ? [
              [0, 'rgba(99, 102, 241, 0.05)'],
              [0.2, 'rgba(99, 102, 241, 0.25)'],
              [0.5, 'rgba(99, 102, 241, 0.55)'],
              [0.8, 'rgba(99, 102, 241, 0.75)'],
              [1.0, 'rgba(79, 70, 229, 0.95)']
            ]
          : [
              [0, 'rgba(238, 242, 255, 0.5)'],
              [0.2, 'rgba(199, 210, 254, 0.7)'],
              [0.5, 'rgba(129, 140, 248, 0.8)'],
              [0.8, 'rgba(79, 70, 229, 0.9)'],
              [1.0, 'rgba(67, 56, 202, 1.0)']
            ];
      } else if (cohortMetricView === "repeatRate") {
        zValues = reverseCohorts.map(c => c.repeatRate);
        textValues = reverseCohorts.map(c => c.repeatRate.map(v => `${v}%`));
        titleName = "Repeat Purchase Rate";
        colorScaleColors = isDark 
          ? [
              [0, 'rgba(6, 182, 212, 0.05)'],
              [0.2, 'rgba(6, 182, 212, 0.25)'],
              [0.5, 'rgba(6, 182, 212, 0.55)'],
              [0.8, 'rgba(6, 182, 212, 0.75)'],
              [1.0, 'rgba(8, 145, 178, 0.95)']
            ]
          : [
              [0, 'rgba(236, 254, 255, 0.5)'],
              [0.2, 'rgba(165, 243, 252, 0.7)'],
              [0.5, 'rgba(34, 211, 238, 0.8)'],
              [0.8, 'rgba(13, 148, 136, 0.9)'],
              [1.0, 'rgba(15, 118, 110, 1.0)']
            ];
      } else {
        zValues = reverseCohorts.map(c => c.cumulativeRevenue);
        textValues = reverseCohorts.map(c => c.cumulativeRevenue.map(v => `$${v.toFixed(2)}`));
        titleName = "Customer Lifetime Spend";
        isCurrency = true;
        colorScaleColors = isDark 
          ? [
              [0, 'rgba(16, 185, 129, 0.05)'],
              [0.2, 'rgba(16, 185, 129, 0.25)'],
              [0.5, 'rgba(16, 185, 129, 0.55)'],
              [0.8, 'rgba(16, 185, 129, 0.75)'],
              [1.0, 'rgba(4, 120, 87, 0.95)']
            ]
          : [
              [0, 'rgba(240, 253, 250, 0.5)'],
              [0.2, 'rgba(187, 247, 208, 0.7)'],
              [0.5, 'rgba(74, 222, 128, 0.8)'],
              [0.8, 'rgba(22, 163, 74, 0.9)'],
              [1.0, 'rgba(21, 128, 61, 1.0)']
            ];
      }

      const data = [
        {
          z: zValues,
          x: xLabels,
          y: yLabelsReverse,
          type: "heatmap",
          hoverongaps: false,
          colorscale: colorScaleColors,
          showscale: true,
          colorbar: {
            title: titleName,
            titleside: "right",
            thickness: 12,
            ticksuffix: isCurrency ? "" : "%",
            tickprefix: isCurrency ? "$" : "",
            len: 0.82
          }
        }
      ];

      const annotations: any[] = [];
      for (let y = 0; y < yLabelsReverse.length; y++) {
        for (let x = 0; x < xLabels.length; x++) {
          const rawVal = zValues[y][x];
          const textLabel = textValues[y][x];
          const isHighValue = cohortMetricView === "lifetimeTrend" 
            ? rawVal > 150 
            : rawVal > 45;

          annotations.push({
            x: xLabels[x],
            y: yLabelsReverse[y],
            text: textLabel,
            font: {
              family: "Inter, sans-serif",
              size: 11,
              color: isHighValue ? "#ffffff" : (isDark ? "#cbd5e1" : "#1f2937"),
              weight: "bold"
            },
            showarrow: false,
          });
        }
      }

      const layout = {
        margin: { l: 150, r: 20, b: 50, t: 30 },
        paper_bgcolor: "transparent",
        plot_bgcolor: "transparent",
        font: {
          color: isDark ? "#cbd5e1" : "#27272a",
          family: "Inter, system-ui, sans-serif",
          size: 11
        },
        annotations: annotations,
        xaxis: {
          side: "bottom",
          gridcolor: isDark ? "#27272a" : "#f4f4f5",
          zeroline: false
        },
        yaxis: {
          gridcolor: isDark ? "#27272a" : "#f4f4f5",
          zeroline: false
        }
      };

      const config = {
        responsive: true,
        displayModeBar: false
      };

      try {
        setIsChartRendering(true);
        (window as any).Plotly.newPlot(el, data, layout as any, config);
        setIsChartRendering(false);
      } catch (err) {
        console.error("Plotly cohort heatmap drawing failure:", err);
        setIsChartRendering(false);
      }
    }, 150);

    return () => clearTimeout(timer);
  }, [plotlyLoaded, activeSubTab, computedCohorts, cohortMetricView]);

  // -------------------------------------------------------------
  // JOURNEY CORE MATH ENGINE
  // -------------------------------------------------------------
  let cHome = 0;
  let cCategory = 0;
  let cExitHome = 0;
  let cProduct = 0;
  let cExitCategory = 0;
  let cCart = 0;
  let cExitProduct = 0;
  let cCheckout = 0;
  let cExitCart = 0;
  let cPurchase = 0;
  let cExitCheckout = 0;

  let commonPaths: { path: string; count: number; percentage: number }[] = [];
  let highConvertingPaths: { path: string; count: number; conversionRate: number }[] = [];
  let exitPaths: { path: string; count: number; percentage: number; stage: string }[] = [];

  if (isSimulating || uploadedData.length === 0) {
    // ---- SIMULATED MATH (Consistent with filter adjustments) ----
    let visitorsCount = metrics.revenue / (metrics.aov || 85) / (metrics.conversionRate / 100 || 0.0245);
    if (!visitorsCount || isNaN(visitorsCount) || visitorsCount <= 0) {
      visitorsCount = 184500;
    }
    visitorsCount = Math.round(visitorsCount);

    // Filter adjustments for simulator
    let rateToCategory = 0.76;
    let rateToProduct = 0.72;
    let rateToCart = 0.28;
    let rateToCheckout = 0.42;
    let rateToPurchase = parseFloat(((metrics.orders / (metrics.orders / 0.32)) || 0.32).toFixed(3));

    // Refinement via active filters
    if (filters.device === "Desktop") {
      rateToCategory = 0.81;
      rateToProduct = 0.78;
      rateToCart = 0.34;
      rateToCheckout = 0.48;
      rateToPurchase = 0.39;
    } else if (filters.device === "Mobile") {
      rateToCategory = 0.71;
      rateToProduct = 0.65;
      rateToCart = 0.24;
      rateToCheckout = 0.36;
      rateToPurchase = 0.24;
    }

    if (filters.channel === "Email Campaign") {
      rateToCategory = 0.85;
      rateToProduct = 0.80;
      rateToCart = 0.39;
      rateToCheckout = 0.54;
      rateToPurchase = 0.45;
    } else if (filters.channel === "Meta Social") {
      rateToCategory = 0.74;
      rateToProduct = 0.68;
      rateToCart = 0.23;
      rateToCheckout = 0.38;
      rateToPurchase = 0.26;
    }

    if (filters.region === "Americas") {
      rateToPurchase += 0.04;
    } else if (filters.region === "MEA") {
      rateToPurchase -= 0.05;
    }

    cHome = visitorsCount;
    cCategory = Math.round(cHome * rateToCategory);
    cExitHome = cHome - cCategory;

    cProduct = Math.round(cCategory * rateToProduct);
    cExitCategory = cCategory - cProduct;

    cCart = Math.round(cProduct * rateToCart);
    cExitProduct = cProduct - cCart;

    cCheckout = Math.round(cCart * rateToCheckout);
    cExitCart = cCart - cCheckout;

    cPurchase = Math.round(cCheckout * rateToPurchase);
    if (cPurchase >= cCheckout) cPurchase = Math.round(cCheckout * 0.4);
    cExitCheckout = cCheckout - cPurchase;

    // Generated simulated paths
    commonPaths = [
      {
        path: "Home → Exit",
        count: cExitHome,
        percentage: parseFloat(((cExitHome / cHome) * 100).toFixed(1))
      },
      {
        path: "Home → Category → Exit",
        count: cExitCategory,
        percentage: parseFloat(((cExitCategory / cHome) * 100).toFixed(1))
      },
      {
        path: "Home → Category → Product → Exit",
        count: cExitProduct,
        percentage: parseFloat(((cExitProduct / cHome) * 100).toFixed(1))
      },
      {
        path: "Home → Category → Product → Cart → Exit",
        count: cExitCart,
        percentage: parseFloat(((cExitCart / cHome) * 100).toFixed(1))
      },
      {
        path: "Home → Category → Product → Cart → Checkout → Exit",
        count: cExitCheckout,
        percentage: parseFloat(((cExitCheckout / cHome) * 100).toFixed(1))
      },
      {
        path: "Home → Category → Product → Cart → Checkout → Purchase",
        count: cPurchase,
        percentage: parseFloat(((cPurchase / cHome) * 100).toFixed(1))
      }
    ].sort((a, b) => b.count - a.count);

    highConvertingPaths = [
      {
        path: "Home → Category → Product → Cart → Checkout → Purchase",
        count: Math.round(cPurchase * 0.74),
        conversionRate: parseFloat((rateToCategory * rateToProduct * rateToCart * rateToCheckout * rateToPurchase * 100).toFixed(2))
      },
      {
        path: "Home → Product → Cart → Checkout → Purchase",
        count: Math.round(cPurchase * 0.18),
        conversionRate: parseFloat((rateToProduct * rateToCart * rateToCheckout * rateToPurchase * 100).toFixed(2))
      },
      {
        path: "Category → Product → Cart → Checkout → Purchase",
        count: Math.round(cPurchase * 0.08),
        conversionRate: parseFloat((rateToProduct * rateToCart * rateToCheckout * rateToPurchase * 1.12 * 100).toFixed(2))
      }
    ];

    exitPaths = [
      {
        path: "Home → Exit",
        count: cExitHome,
        percentage: parseFloat(((cExitHome / cHome) * 100).toFixed(1)),
        stage: "Homepage Exit"
      },
      {
        path: "Cart → Exit",
        count: cExitCart,
        percentage: parseFloat(((cExitCart / cCart) * 100).toFixed(1)),
        stage: "Cart Abandonment"
      },
      {
        path: "Category → Exit",
        count: cExitCategory,
        percentage: parseFloat(((cExitCategory / cCategory) * 100).toFixed(1)),
        stage: "Directory Bounces"
      },
      {
        path: "Product → Exit",
        count: cExitProduct,
        percentage: parseFloat(((cExitProduct / cProduct) * 100).toFixed(1)),
        stage: "Review Abandonment"
      },
      {
        path: "Checkout → Exit",
        count: cExitCheckout,
        percentage: parseFloat(((cExitCheckout / cCheckout) * 100).toFixed(1)),
        stage: "Order Friction drops"
      }
    ].sort((a, b) => b.count - a.count);

  } else {
    // ---- REAL DATA EXTRACTION FROM INGESTED LOGS ----
    // Filter records dynamically
    const timestamps = uploadedData.map(r => new Date(r.timestamp).getTime()).filter(t => !isNaN(t));
    const latestTime = timestamps.length > 0 ? timestamps.reduce((max, t) => t > max ? t : max, timestamps[0]) : Date.now();
    const daysLimit = filters.dateRange === "7d" ? 7 : filters.dateRange === "90d" ? 90 : 30;
    const milliLimit = daysLimit * 24 * 60 * 60 * 1000;

    const filtered = uploadedData.filter(record => {
      // Date Range Limit
      const recTime = new Date(record.timestamp).getTime();
      if (isNaN(recTime)) return false;
      if (latestTime - recTime > milliLimit) return false;

      // Region Filter
      if (filters.region !== "all") {
        const matchRegion = record.region.toLowerCase().includes(filters.region.toLowerCase()) || 
                            filters.region.toLowerCase().includes(record.region.toLowerCase());
        if (!matchRegion) return false;
      }

      // Device Type
      if (filters.device !== "all") {
        if (record.device_type.toLowerCase() !== filters.device.toLowerCase()) return false;
      }

      // Traffic Referral Channel
      if (filters.channel !== "all") {
        const matchChannel = record.traffic_source.toLowerCase().includes(filters.channel.toLowerCase()) ||
                             filters.channel.toLowerCase().includes(record.traffic_source.toLowerCase());
        if (!matchChannel) return false;
      }

      // Specific Catalog Node
      if (filters.product !== "all") {
        const matchProduct = record.product_name.toLowerCase().includes(filters.product.toLowerCase());
        if (!matchProduct) return false;
      }

      return true;
    });

    // Trace sequences per user session
    interface UserSessionTracer {
      sessionId: string;
      events: IngestedRecord[];
    }

    const sessionsMap = new Map<string, IngestedRecord[]>();
    filtered.forEach(rec => {
      const sid = rec.session_id || "unknown";
      if (!sessionsMap.has(sid)) {
        sessionsMap.set(sid, []);
      }
      sessionsMap.get(sid)!.push(rec);
    });

    // 1. Calculate linear stage milestones reached per session
    const sessionsList = Array.from(sessionsMap.entries());
    cHome = sessionsList.length || 1; // Safeguard

    sessionsList.forEach(([sid, records]) => {
      // Sort cronologically
      records.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
      
      const sessionStages = records.map(r => getStageName(r));
      
      const hasCategory = sessionStages.some(s => s === "Category" || s === "Product" || s === "Cart" || s === "Checkout" || s === "Purchase");
      const hasProduct = sessionStages.some(s => s === "Product" || s === "Cart" || s === "Checkout" || s === "Purchase");
      const hasCart = sessionStages.some(s => s === "Cart" || s === "Checkout" || s === "Purchase");
      const hasCheckout = sessionStages.some(s => s === "Checkout" || s === "Purchase");
      const hasPurchase = sessionStages.some(s => s === "Purchase");

      if (hasCategory) cCategory++;
      if (hasProduct) cProduct++;
      if (hasCart) cCart++;
      if (hasCheckout) cCheckout++;
      if (hasPurchase) cPurchase++;
    });

    cExitHome = cHome - cCategory;
    cExitCategory = cCategory - cProduct;
    cExitProduct = cProduct - cCart;
    cExitCart = cCart - cCheckout;
    cExitCheckout = cCheckout - cPurchase;

    // 2. Mine actual raw chronological pathways
    const pathCounters = new Map<string, number>();
    const highConvertingCounter = new Map<string, number>();
    const exitStageCounter = new Map<string, { count: number; lastStage: string }>();

    sessionsList.forEach(([sid, records]) => {
      records.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
      
      // Chronological unique states mapped sequentially
      const uniqueStatesInChronology: string[] = [];
      records.forEach(rec => {
        const stage = getStageName(rec);
        if (uniqueStatesInChronology.length === 0 || uniqueStatesInChronology[uniqueStatesInChronology.length - 1] !== stage) {
          uniqueStatesInChronology.push(stage);
        }
      });

      if (uniqueStatesInChronology.length === 0) return;

      const pathStr = uniqueStatesInChronology.join(" → ");
      const isConvertedPath = uniqueStatesInChronology.includes("Purchase");

      // General path metrics
      pathCounters.set(pathStr, (pathCounters.get(pathStr) || 0) + 1);

      if (isConvertedPath) {
        highConvertingCounter.set(pathStr, (highConvertingCounter.get(pathStr) || 0) + 1);
      } else {
        const lastStageName = uniqueStatesInChronology[uniqueStatesInChronology.length - 1];
        const exitPathStr = uniqueStatesInChronology.join(" → ") + " → Exit";
        
        const grp = exitStageCounter.get(exitPathStr) || { count: 0, lastStage: lastStageName };
        grp.count++;
        exitStageCounter.set(exitPathStr, grp);
      }
    });

    // Map dictionaries to visual arrays
    commonPaths = Array.from(pathCounters.entries()).map(([path, count]) => ({
      path,
      count,
      percentage: parseFloat(((count / cHome) * 100).toFixed(1))
    })).sort((a, b) => b.count - a.count).slice(0, 6);

    highConvertingPaths = Array.from(highConvertingCounter.entries()).map(([path, count]) => {
      // Find starting node count to calculate path conversions accurately
      const firstNode = path.split(" → ")[0];
      const startCount = sessionsList.filter(([_, recs]) => {
        const firstRec = recs[0];
        return firstRec && getStageName(firstRec) === firstNode;
      }).length || cHome;

      return {
        path,
        count,
        conversionRate: parseFloat(((count / startCount) * 100).toFixed(2))
      };
    }).sort((a, b) => b.count - a.count).slice(0, 4);

    exitPaths = Array.from(exitStageCounter.entries()).map(([path, grp]) => {
      // Base rate
      let stageBaseline = cHome;
      if (grp.lastStage === "Category") stageBaseline = cCategory || 1;
      if (grp.lastStage === "Product") stageBaseline = cProduct || 1;
      if (grp.lastStage === "Cart") stageBaseline = cCart || 1;
      if (grp.lastStage === "Checkout") stageBaseline = cCheckout || 1;

      return {
        path,
        count: grp.count,
        percentage: parseFloat(((grp.count / stageBaseline) * 100).toFixed(1)),
        stage: grp.lastStage + " Leakage"
      };
    }).sort((a, b) => b.count - a.count).slice(0, 5);
  }

  // Set default values if filters zero-out state
  if (cHome === 0) cHome = 1;

  // Draw/Redraw Plotly Sankey Graphic on component triggers
  useEffect(() => {
    if (!plotlyLoaded || activeSubTab !== "journey") return;

    const timer = setTimeout(() => {
      const el = document.getElementById("plotly-sankey-canvas");
      if (!el) return;

      const isDark = document.documentElement.classList.contains("dark");

      const data = [
        {
          type: "sankey",
          orientation: "h",
          valueformat: ".0f",
          valuesuffix: " users",
          node: {
            pad: 18,
            thickness: 25,
            line: {
              color: isDark ? "#27272a" : "#e4e4e7",
              width: 1
            },
            label: [
              "1. Home Entrance",
              "2. Category Browse",
              "3. Product Details",
              "4. Added to Cart",
              "5. Checkout Begun",
              "6. Purchase Completed",
              "Exited at Homepage",
              "Exited after Category",
              "Exited after Product",
              "Exited after Cart",
              "Exited after Checkout"
            ],
            color: [
              "#0ea5e9", // Home
              "#06b6d4", // Category
              "#3b82f6", // Product
              "#6366f1", // Cart
              "#8b5cf6", // Checkout
              "#10b981", // Purchase
              isDark ? "rgba(239, 68, 68, 0.45)" : "rgba(239, 68, 68, 0.15)",   // Exits in rose hues
              isDark ? "rgba(244, 63, 94, 0.45)" : "rgba(244, 63, 94, 0.15)",
              isDark ? "rgba(236, 72, 153, 0.45)" : "rgba(236, 72, 153, 0.15)",
              isDark ? "rgba(217, 70, 239, 0.45)" : "rgba(217, 70, 239, 0.15)",
              isDark ? "rgba(168, 85, 247, 0.45)" : "rgba(168, 85, 247, 0.15)",
            ]
          },
          link: {
            source: [0, 0, 1, 1, 2, 2, 3, 3, 4, 4],
            target: [1, 6, 2, 7, 3, 8, 4, 9, 5, 10],
            value: [
              cCategory, cExitHome,
              cProduct, cExitCategory,
              cCart, cExitProduct,
              cCheckout, cExitCart,
              cPurchase, cExitCheckout
            ],
            color: [
              isDark ? "rgba(14, 165, 233, 0.22)" : "rgba(14, 165, 233, 0.08)",
              isDark ? "rgba(239, 68, 68, 0.25)" : "rgba(239, 68, 68, 0.08)",
              isDark ? "rgba(6, 182, 212, 0.22)" : "rgba(6, 182, 212, 0.08)",
              isDark ? "rgba(244, 63, 94, 0.25)" : "rgba(244, 63, 94, 0.08)",
              isDark ? "rgba(59, 130, 246, 0.22)" : "rgba(59, 130, 246, 0.08)",
              isDark ? "rgba(236, 72, 153, 0.25)" : "rgba(236, 72, 153, 0.08)",
              isDark ? "rgba(99, 102, 241, 0.22)" : "rgba(99, 102, 241, 0.08)",
              isDark ? "rgba(217, 70, 239, 0.25)" : "rgba(217, 70, 239, 0.08)",
              isDark ? "rgba(139, 92, 246, 0.22)" : "rgba(139, 92, 246, 0.08)",
              isDark ? "rgba(168, 85, 247, 0.25)" : "rgba(168, 85, 247, 0.08)"
            ]
          }
        }
      ];

      const layout = {
        margin: { l: 20, r: 20, b: 20, t: 20 },
        paper_bgcolor: "transparent",
        plot_bgcolor: "transparent",
        font: {
          color: isDark ? "#cbd5e1" : "#27272a",
          family: "Inter, system-ui, sans-serif",
          size: 11
        }
      };

      const config = {
        responsive: true,
        displayModeBar: false
      };

      try {
        setIsChartRendering(true);
        (window as any).Plotly.newPlot(el, data, layout, config);
        setIsChartRendering(false);
      } catch (err) {
        console.error("Plotly drawing failure:", err);
        setIsChartRendering(false);
      }
    }, 120);

    return () => clearTimeout(timer);
  }, [plotlyLoaded, activeSubTab, filters, isSimulating, uploadedData]);

  // Heatmap helper for Cohorts
  const getHeatmapColorClass = (val: number) => {
    if (val === 100) return "bg-indigo-600/90 text-white font-bold border-r border-indigo-550";
    if (val > 25) return "bg-indigo-500/60 text-white font-medium border-r border-indigo-400";
    if (val > 15) return "bg-indigo-500/35 text-indigo-900 border-r border-indigo-200 dark:text-indigo-200";
    if (val > 9) return "bg-indigo-500/15 text-indigo-700 border-r border-indigo-100 dark:text-indigo-300";
    if (val === 0) return "bg-gray-100 dark:bg-zinc-850 text-gray-400 font-mono border-r border-zinc-800";
    return "bg-indigo-500/5 text-gray-400 font-mono text-[9px] border-r border-gray-100 dark:border-zinc-850";
  };

  return (
    <div id="customer-journey-cohort-root" className="space-y-6">
      
      {/* 1. Header Layout */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-gray-200/50 dark:border-zinc-800/80 pb-4">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <GitMerge className="h-5 w-5 text-indigo-500" />
            Customer Journey & Retention Intelligence
          </h2>
          <p className="text-xs text-gray-500 dark:text-zinc-400 mt-1">
            Map touchpoint transitions using interactive Sankey flows, trace common pathways, and examine returning user indices.
          </p>
        </div>

        {/* Global tab routing selection */}
        <div className="flex bg-gray-100 dark:bg-zinc-900 p-1 rounded-xl text-xs font-semibold self-stretch md:self-auto shadow-xs border border-gray-200/30 dark:border-zinc-805">
          <button
            onClick={() => setActiveSubTab("journey")}
            className={`flex-1 flex items-center justify-center gap-2 p-2 px-4 rounded-lg transition-all ${
              activeSubTab === "journey"
                ? "bg-white dark:bg-zinc-800 text-indigo-600 dark:text-cyan-400 font-bold shadow-xs animate-fadeIn"
                : "text-gray-500 dark:text-zinc-400 hover:text-gray-800 dark:hover:text-zinc-200"
            }`}
          >
            <GitMerge className="h-4 w-4" />
            <span>Journey Paths Map</span>
          </button>
          <button
            onClick={() => setActiveSubTab("retention")}
            className={`flex-1 flex items-center justify-center gap-2 p-2 px-4 rounded-lg transition-all ${
              activeSubTab === "retention"
                ? "bg-white dark:bg-zinc-800 text-indigo-600 dark:text-cyan-400 font-bold shadow-xs animate-fadeIn"
                : "text-gray-400 dark:text-zinc-450 hover:text-gray-800 dark:hover:text-zinc-200"
            }`}
          >
            <Grid3X3 className="h-4 w-4" />
            <span>Cohort Heatmaps</span>
          </button>
        </div>
      </div>

      {activeSubTab === "journey" ? (
        <div className="space-y-6 animate-fadeIn">
          
          {/* 2. Interactive Filter Bar */}
          <div className="p-4 rounded-xl bg-white dark:bg-zinc-900 border border-gray-200/50 dark:border-zinc-850 space-y-3 shadow-xs">
            <div className="flex items-center gap-2 text-[10px] font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
              <Filter className="h-3.5 w-3.5" />
              <span>Interactive Filter Rails</span>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
              {/* Date Selector */}
              <div>
                <label className="block text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase mb-1">Date Interval</label>
                <select
                  id="journey-filter-date"
                  value={filters.dateRange}
                  onChange={(e) => setFilters({ ...filters, dateRange: e.target.value })}
                  className="w-full text-xs font-semibold rounded-xl bg-gray-50 border border-gray-200 dark:border-zinc-850 dark:bg-zinc-855 p-2 text-gray-700 dark:text-zinc-200 focus:outline-none focus:border-indigo-500 transition-colors"
                >
                  {dateOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </div>

              {/* Region Selector */}
              <div>
                <label className="block text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase mb-1">Geographic Region</label>
                <select
                  id="journey-filter-region"
                  value={filters.region}
                  onChange={(e) => setFilters({ ...filters, region: e.target.value })}
                  className="w-full text-xs font-semibold rounded-xl bg-gray-50 border border-gray-200 dark:border-zinc-850 dark:bg-zinc-855 p-2 text-gray-700 dark:text-zinc-200 focus:outline-none focus:border-indigo-500 transition-colors"
                >
                  {regionOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </div>

              {/* Traffic Source Selector */}
              <div>
                <label className="block text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase mb-1">Acquisition Channel</label>
                <select
                  id="journey-filter-channel"
                  value={filters.channel}
                  onChange={(e) => setFilters({ ...filters, channel: e.target.value })}
                  className="w-full text-xs font-semibold rounded-xl bg-gray-50 border border-gray-200 dark:border-zinc-850 dark:bg-zinc-855 p-2 text-gray-700 dark:text-zinc-200 focus:outline-none focus:border-indigo-500 transition-colors"
                >
                  {channelOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </div>

              {/* Device Type Selector */}
              <div>
                <label className="block text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase mb-1">Terminal Device</label>
                <select
                  id="journey-filter-device"
                  value={filters.device}
                  onChange={(e) => setFilters({ ...filters, device: e.target.value })}
                  className="w-full text-xs font-semibold rounded-xl bg-gray-50 border border-gray-200 dark:border-zinc-850 dark:bg-zinc-855 p-2 text-gray-700 dark:text-zinc-200 focus:outline-none focus:border-indigo-500 transition-colors"
                >
                  {deviceOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </div>
            </div>
          </div>

          {/* 3. Sankey Plotly Container (Interactive) */}
          <div className="p-6 rounded-2xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 flex flex-col justify-between">
            <div className="border-b border-gray-100 dark:border-zinc-800/80 pb-3 flex justify-between items-center">
              <div>
                <h3 className="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                  <Layers className="h-4.5 w-4.5 text-indigo-500 animate-pulse" />
                  <span>Sankey Sequence Flowchart Map</span>
                </h3>
                <p className="text-[10px] text-gray-400 mt-0.5">Horizontal flows mapped along user actions. Hues specify progression (primary blue) vs. dropping off exits (red / rose).</p>
              </div>
              
              {isChartRendering && (
                <span className="text-[10px] font-mono text-gray-400 flex items-center gap-1">
                  <RefreshCw className="h-3 w-3 animate-spin text-indigo-500" />
                  Drawing nodes...
                </span>
              )}
            </div>

            <div className="my-2 relative overflow-hidden flex items-center justify-center min-h-[380px]">
              {/* Plotly Canvas hooks */}
              <div id="plotly-sankey-canvas" className="w-full h-96 min-h-[380px]" />
              
              {/* Fallback progress indicator */}
              {!plotlyLoaded && (
                <div className="absolute inset-0 bg-white/70 dark:bg-zinc-900/70 flex flex-col items-center justify-center gap-2">
                  <RefreshCw className="h-8 w-8 animate-spin text-indigo-500" />
                  <span className="text-[11px] font-bold text-gray-500 dark:text-zinc-400 font-mono">Loading plot modules...</span>
                </div>
              )}
            </div>

            <p className="text-[9.5px] text-gray-400 italic text-center font-mono">
              * Hover over the nodes and links to reveal granular user counts, transitioning rates, and direct drop volumes.
            </p>
          </div>

          {/* 4. Path Analysis Tabs and Lists (Bento Grid Style) */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Left Col - Navigation Options */}
            <div className="lg:col-span-1 p-5 rounded-2xl border border-gray-205/65 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 text-left space-y-4">
              <div>
                <h3 className="text-xs font-black text-gray-400 dark:text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
                  <GitMerge className="h-4 w-4 text-cyan-500" />
                  <span>Interactive Pathway Tracker</span>
                </h3>
                <p className="text-[11px] text-gray-500 dark:text-zinc-400 leading-normal mt-1">
                  Choose a logic segment to analyze chronological patterns and funnel behaviors.
                </p>
              </div>

              <div className="flex flex-col gap-2 pt-2">
                <button
                  onClick={() => setActivePathTab("common")}
                  className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                    activePathTab === "common"
                      ? "bg-indigo-50/20 border-indigo-200/50 dark:bg-indigo-950/10 dark:border-indigo-900/30 text-indigo-700 dark:text-cyan-400"
                      : "bg-gray-50/50 border-gray-100 dark:bg-zinc-850/20 dark:border-zinc-800 text-gray-600 dark:text-zinc-300"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Layers className="h-4.5 w-4.5" />
                    <div className="text-xs">
                      <p className="font-bold">Most Common Paths</p>
                      <span className="text-[10px] text-gray-400">Recurring customer journeys</span>
                    </div>
                  </div>
                  <ArrowRight className="h-3.5 w-3.5 opacity-60" />
                </button>

                <button
                  onClick={() => setActivePathTab("high")}
                  className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                    activePathTab === "high"
                      ? "bg-indigo-50/20 border-indigo-200/50 dark:bg-indigo-950/10 dark:border-indigo-900/30 text-indigo-700 dark:text-cyan-400"
                      : "bg-gray-50/50 border-gray-100 dark:bg-zinc-850/20 dark:border-zinc-800 text-gray-600 dark:text-zinc-300"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <TrendingUp className="h-4.5 w-4.5 text-emerald-500" />
                    <div className="text-xs">
                      <p className="font-bold">High-Converting Paths</p>
                      <span className="text-[10px] text-gray-400">Routes yielding purchases</span>
                    </div>
                  </div>
                  <ArrowRight className="h-3.5 w-3.5 opacity-60" />
                </button>

                <button
                  onClick={() => setActivePathTab("exits")}
                  className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                    activePathTab === "exits"
                      ? "bg-indigo-50/20 border-indigo-200/50 dark:bg-indigo-950/10 dark:border-indigo-900/30 text-indigo-700 dark:text-cyan-400"
                      : "bg-gray-50/50 border-gray-101 dark:bg-zinc-850/20 dark:border-zinc-800 text-gray-600 dark:text-zinc-300"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <XCircle className="h-4.5 w-4.5 text-rose-500" />
                    <div className="text-xs">
                      <p className="font-bold">Primary Exit Paths</p>
                      <span className="text-[10px] text-gray-400">Leakage & checkout barriers</span>
                    </div>
                  </div>
                  <ArrowRight className="h-3.5 w-3.5 opacity-60" />
                </button>
              </div>

              <div className="p-3 bg-indigo-500/5 border border-indigo-500/10 rounded-xl text-[10px] text-indigo-650 dark:text-indigo-400 flex gap-2">
                <Sparkles className="h-4 w-4 shrink-0 mt-0.5" />
                <p className="leading-normal font-medium">
                  <strong>Conversion Tip:</strong> Direct organic channels are currently experiencing 4% lower exit rates than standard media channels. Optimize retargeting workflows.
                </p>
              </div>
            </div>

            {/* Right Cols - Dynamic List Render (2 Columns) */}
            <div className="lg:col-span-2 p-5 rounded-2xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 text-left">
              <div className="border-b border-gray-100 dark:border-zinc-850 pb-3 flex justify-between items-center">
                <div>
                  <h4 className="text-sm font-bold text-gray-900 dark:text-white capitalize">
                    {activePathTab === "common" && "Most Common User Paths"}
                    {activePathTab === "high" && "High-Converting Sequences"}
                    {activePathTab === "exits" && "Major Leakage Exit Paths"}
                  </h4>
                  <p className="text-[10px] text-gray-400 mt-0.5">
                    {activePathTab === "common" && "Top chronologically recorded pathway sequences across filtered sessions."}
                    {activePathTab === "high" && "Frictionless paths resulting in finalized transactions and order generation."}
                    {activePathTab === "exits" && "Main dropoff points and sequences describing where users left the checkout lifecycle."}
                  </p>
                </div>
                <span className="text-[10px] font-mono text-indigo-600 bg-indigo-500/10 p-1 px-2.5 rounded-full font-bold">
                  {activePathTab === "common" && "Top 6 paths"}
                  {activePathTab === "high" && "High intent"}
                  {activePathTab === "exits" && "Top 5 leaks"}
                </span>
              </div>

              <div className="mt-4 space-y-3">
                {activePathTab === "common" && commonPaths.map((item, idx) => (
                  <div key={idx} className="p-3 rounded-xl border border-gray-100/60 dark:border-zinc-850/60 bg-gray-50/20 dark:bg-zinc-850/10 flex items-center justify-between text-xs hover:border-gray-200 dark:hover:border-zinc-750 transition-all">
                    <div className="min-w-0 pr-3">
                      <p className="font-mono text-gray-900 dark:text-white font-bold tracking-tight truncate max-w-[420px]">{item.path}</p>
                      <span className="text-[10px] text-gray-400 mt-1 block">Accumulated Frequency: <strong className="font-semibold text-gray-700 dark:text-zinc-250">{item.count.toLocaleString()} sessions</strong></span>
                    </div>
                    <span className="shrink-0 text-xs font-black font-mono text-indigo-500 bg-indigo-500/5 border border-indigo-500/10 p-1 px-2.5 rounded-lg">
                      {item.percentage}%
                    </span>
                  </div>
                ))}

                {activePathTab === "high" && highConvertingPaths.map((item, idx) => (
                  <div key={idx} className="p-3 rounded-xl border border-emerald-100/30 dark:border-emerald-900/20 bg-emerald-500/5 flex items-center justify-between text-xs hover:bg-emerald-500/10 transition-colors">
                    <div className="min-w-0 pr-3">
                      <p className="font-mono text-emerald-700 dark:text-emerald-400 font-bold tracking-tight truncate max-w-[420px]">{item.path}</p>
                      <div className="flex items-center gap-3 text-[10px] text-gray-400 mt-1 font-semibold">
                        <span>Completes: <strong className="text-emerald-600 font-bold">{item.count.toLocaleString()} sessions</strong></span>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="text-xs font-black font-mono text-emerald-600 bg-emerald-500/10 border border-emerald-500/20 p-1 px-2.5 rounded-lg">
                        {item.conversionRate}% conv
                      </span>
                    </div>
                  </div>
                ))}

                {activePathTab === "exits" && exitPaths.map((item, idx) => (
                  <div key={idx} className="p-3 rounded-xl border border-rose-100/30 dark:border-rose-900/20 bg-rose-500/5 flex items-center justify-between text-xs hover:bg-rose-500/10 transition-colors">
                    <div className="min-w-0 pr-3">
                      <p className="font-mono text-rose-700 dark:text-rose-455 font-bold tracking-tight truncate max-w-[420px]">{item.path}</p>
                      <span className="text-[10px] text-gray-400 mt-1 block">Friction Target: <strong className="font-bold text-gray-500">{item.stage}</strong> | Exit Volume: <strong className="text-rose-600 font-bold">{item.count.toLocaleString()} Sessions</strong></span>
                    </div>
                    <span className="shrink-0 text-xs font-black font-mono text-rose-500 bg-rose-500/10 border border-rose-500/20 p-1 px-2.5 rounded-lg">
                      {item.percentage}% exit rate
                    </span>
                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* 5. In-Depth Granular Funnel & Exit Ledger */}
          <div className="p-5 rounded-2xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 text-left">
            <div className="border-b border-gray-150 dark:border-zinc-850 pb-3 flex justify-between items-center">
              <div>
                <h3 className="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2">
                  <Receipt className="h-4.5 w-4.5 text-gray-500" />
                  <span>Granular Journey Ledger Index</span>
                </h3>
                <p className="text-[10px] text-gray-400 mt-0.5">Consolidated flow indicators detailing journey counts, milestone conversions, and leakages.</p>
              </div>
            </div>

            <div className="mt-4 overflow-x-auto">
              <table className="w-full text-xs text-left text-gray-500 dark:text-zinc-400">
                <thead className="text-[9.5px] font-black uppercase text-gray-400 dark:text-zinc-500 border-b border-gray-150 dark:border-zinc-800">
                  <tr>
                    <th scope="col" className="py-2.5 px-2">Touchpoint Stage</th>
                    <th scope="col" className="py-2.5 px-2 text-right">Journey volume (Count)</th>
                    <th scope="col" className="py-2.5 px-2 text-right">Step-to-Step conversion</th>
                    <th scope="col" className="py-2.5 px-2 text-right">Cumulative conversion</th>
                    <th scope="col" className="py-2.5 px-2 text-right">Drops & Exit count</th>
                    <th scope="col" className="py-2.5 px-2 text-right">Exit Rate</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-150 dark:divide-zinc-850 font-medium">
                  {/* Row 1: Home */}
                  <tr className="hover:bg-gray-55/40 dark:hover:bg-zinc-850/10 transition-colors">
                    <td className="py-3 px-2 font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                      <div className="h-2 w-2 rounded-full bg-sky-500" />
                      <span>1. Home Entrance</span>
                    </td>
                    <td className="py-3 px-2 text-right font-bold text-gray-950 dark:text-zinc-150 font-mono">{cHome.toLocaleString()}</td>
                    <td className="py-3 px-2 text-right font-mono text-cyan-500">{((cCategory / cHome) * 100).toFixed(1)}%</td>
                    <td className="py-3 px-2 text-right font-mono text-indigo-500">100.0%</td>
                    <td className="py-3 px-2 text-right font-mono text-rose-500">{cExitHome.toLocaleString()}</td>
                    <td className="py-3 px-2 text-right font-mono text-rose-500">{((cExitHome / cHome) * 100).toFixed(1)}%</td>
                  </tr>

                  {/* Row 2: Category */}
                  <tr className="hover:bg-gray-55/40 dark:hover:bg-zinc-850/10 transition-colors">
                    <td className="py-3 px-2 font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                      <div className="h-2 w-2 rounded-full bg-cyan-500" />
                      <span>2. Category Browse</span>
                    </td>
                    <td className="py-3 px-2 text-right font-bold text-gray-950 dark:text-zinc-150 font-mono">{cCategory.toLocaleString()}</td>
                    <td className="py-3 px-2 text-right font-mono text-cyan-500">{cCategory > 0 ? ((cProduct / cCategory) * 100).toFixed(1) : 0}%</td>
                    <td className="py-3 px-2 text-right font-mono text-indigo-500">{((cCategory / cHome) * 100).toFixed(1)}%</td>
                    <td className="py-3 px-2 text-right font-mono text-rose-500">{cExitCategory.toLocaleString()}</td>
                    <td className="py-3 px-2 text-right font-mono text-rose-500">{cCategory > 0 ? ((cExitCategory / cCategory) * 100).toFixed(1) : 0}%</td>
                  </tr>

                  {/* Row 3: Product */}
                  <tr className="hover:bg-gray-55/40 dark:hover:bg-zinc-850/10 transition-colors">
                    <td className="py-3 px-2 font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                      <div className="h-2 w-2 rounded-full bg-blue-500" />
                      <span>3. Product Details</span>
                    </td>
                    <td className="py-3 px-2 text-right font-bold text-gray-950 dark:text-zinc-150 font-mono">{cProduct.toLocaleString()}</td>
                    <td className="py-3 px-2 text-right font-mono text-cyan-500">{cProduct > 0 ? ((cCart / cProduct) * 100).toFixed(1) : 0}%</td>
                    <td className="py-3 px-2 text-right font-mono text-indigo-500">{((cProduct / cHome) * 100).toFixed(1)}%</td>
                    <td className="py-3 px-2 text-right font-mono text-rose-500">{cExitProduct.toLocaleString()}</td>
                    <td className="py-3 px-2 text-right font-mono text-rose-500">{cProduct > 0 ? ((cExitProduct / cProduct) * 100).toFixed(1) : 0}%</td>
                  </tr>

                  {/* Row 4: Cart */}
                  <tr className="hover:bg-gray-55/40 dark:hover:bg-zinc-850/10 transition-colors">
                    <td className="py-3 px-2 font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                      <div className="h-2 w-2 rounded-full bg-indigo-500" />
                      <span>4. Added to Cart</span>
                    </td>
                    <td className="py-3 px-2 text-right font-bold text-gray-950 dark:text-zinc-150 font-mono">{cCart.toLocaleString()}</td>
                    <td className="py-3 px-2 text-right font-mono text-cyan-500">{cCart > 0 ? ((cCheckout / cCart) * 100).toFixed(1) : 0}%</td>
                    <td className="py-3 px-2 text-right font-mono text-indigo-500">{((cCart / cHome) * 100).toFixed(1)}%</td>
                    <td className="py-3 px-2 text-right font-mono text-rose-500">{cExitCart.toLocaleString()}</td>
                    <td className="py-3 px-2 text-right font-mono text-rose-500">{cCart > 0 ? ((cExitCart / cCart) * 100).toFixed(1) : 0}%</td>
                  </tr>

                  {/* Row 5: Checkout */}
                  <tr className="hover:bg-gray-55/40 dark:hover:bg-zinc-850/10 transition-colors">
                    <td className="py-3 px-2 font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                      <div className="h-2 w-2 rounded-full bg-violet-500" />
                      <span>5. Checkout Begun</span>
                    </td>
                    <td className="py-3 px-2 text-right font-bold text-gray-950 dark:text-zinc-150 font-mono">{cCheckout.toLocaleString()}</td>
                    <td className="py-3 px-2 text-right font-mono text-cyan-500">{cCheckout > 0 ? ((cPurchase / cCheckout) * 100).toFixed(1) : 0}%</td>
                    <td className="py-3 px-2 text-right font-mono text-indigo-500">{((cCheckout / cHome) * 100).toFixed(1)}%</td>
                    <td className="py-3 px-2 text-right font-mono text-rose-500">{cExitCheckout.toLocaleString()}</td>
                    <td className="py-3 px-2 text-right font-mono text-rose-500">{cCheckout > 0 ? ((cExitCheckout / cCheckout) * 100).toFixed(1) : 0}%</td>
                  </tr>

                  {/* Row 6: Purchase */}
                  <tr className="hover:bg-gray-55/40 dark:hover:bg-zinc-850/15 bg-emerald-500/5 text-emerald-950 dark:text-emerald-200 transition-colors font-semibold">
                    <td className="py-3 px-2 font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                      <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                      <span>6. Purchase Completed</span>
                    </td>
                    <td className="py-3 px-2 text-right font-bold font-mono text-emerald-600 dark:text-emerald-405">{cPurchase.toLocaleString()}</td>
                    <td className="py-3 px-2 text-right font-mono text-emerald-500">Terminal node</td>
                    <td className="py-3 px-2 text-right font-mono text-emerald-600 dark:text-emerald-405">{((cPurchase / cHome) * 100).toFixed(2)}%</td>
                    <td className="py-3 px-2 text-right font-mono text-gray-400">0</td>
                    <td className="py-3 px-2 text-right font-mono text-gray-400">0%</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

        </div>
      ) : (
        <div className="space-y-6 animate-fadeIn">
          {/* Header Description */}
          <div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <Grid3X3 className="h-5 w-5 text-indigo-500" />
              Customer Retention Cohort Intelligence Matrix
            </h2>
            <p className="text-xs text-gray-500 dark:text-zinc-400 mt-1">
              Analyze returning customer cohorts grouped by first purchase month. Monitor repeat purchasing ratios, customer lifetime trend curves, and MoM churn drop-offs.
            </p>
          </div>

          {/* Interactive KPI Summary Cards */}
          {computedCohorts.length > 0 && (() => {
            const totalCohortUsers = computedCohorts.reduce((acc, c) => acc + c.size, 0);
            const avgM1Retention = parseFloat((computedCohorts.reduce((acc, c) => acc + c.retention[1], 0) / computedCohorts.length).toFixed(1));
            const avgM3Ltv = parseFloat((computedCohorts.reduce((acc, c) => acc + c.cumulativeRevenue[3], 0) / computedCohorts.length).toFixed(2));
            const avgRepeatM1 = parseFloat((computedCohorts.reduce((acc, c) => acc + c.repeatRate[1], 0) / computedCohorts.length).toFixed(1));

            return (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div id="cohort-stat-users" className="p-4 rounded-xl bg-white dark:bg-zinc-900 border border-gray-200/50 dark:border-zinc-850 flex items-center gap-4 shadow-sm">
                  <div className="p-2.5 rounded-lg bg-indigo-500/10 text-indigo-505 dark:text-indigo-400">
                    <Users className="h-5 w-5" />
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-wider">Cohort Base Users</span>
                    <p className="text-lg font-extrabold text-gray-900 dark:text-white mt-0.5">{totalCohortUsers.toLocaleString()}</p>
                    <span className="text-[9px] text-gray-400 font-mono">Unique tracked purchasers</span>
                  </div>
                </div>

                <div id="cohort-stat-retention" className="p-4 rounded-xl bg-white dark:bg-zinc-900 border border-gray-200/50 dark:border-zinc-850 flex items-center gap-4 shadow-sm">
                  <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-wider">Avg Month 1 Retention</span>
                    <p className="text-lg font-extrabold text-gray-900 dark:text-white mt-0.5">{avgM1Retention}%</p>
                    <span className="text-[9px] text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-0.5">
                      Healthy returning baseline
                    </span>
                  </div>
                </div>

                <div id="cohort-stat-repeat" className="p-4 rounded-xl bg-white dark:bg-zinc-900 border border-gray-200/50 dark:border-zinc-850 flex items-center gap-4 shadow-sm">
                  <div className="p-2.5 rounded-lg bg-cyan-500/10 text-cyan-500 dark:text-cyan-400">
                    <RefreshCw className="h-5 w-5" />
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-wider">Repeat Buy Ratio</span>
                    <p className="text-lg font-extrabold text-gray-900 dark:text-white mt-0.5">{avgRepeatM1}%</p>
                    <span className="text-[9px] text-cyan-600 dark:text-cyan-400 font-semibold">Multiple orders frequency</span>
                  </div>
                </div>

                <div id="cohort-stat-ltv" className="p-4 rounded-xl bg-white dark:bg-zinc-900 border border-gray-200/50 dark:border-zinc-850 flex items-center gap-4 shadow-sm">
                  <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-500 dark:text-amber-400">
                    <ShoppingBag className="h-5 w-5" />
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-wider">Avg Month 3 LTV</span>
                    <p className="text-lg font-extrabold text-gray-900 dark:text-white mt-0.5">${avgM3Ltv.toLocaleString()}</p>
                    <span className="text-[9px] text-gray-400 font-semibold">Average spending per user</span>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Interactive Heatmap Controls & Chart Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left/Middle Column (Heatmap Block) */}
            <div className="lg:col-span-2 p-5 rounded-2xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 flex flex-col transition-all">
              <div className="border-b border-gray-100 dark:border-zinc-800/80 pb-3 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                <div>
                  <h3 className="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                    <Grid3X3 className="h-4.5 w-4.5 text-indigo-500" />
                    <span>Interactive Plotly Cohort Heatmap</span>
                  </h3>
                  <p className="text-[10px] text-gray-400 mt-0.5">Visually isolate retention weights, loyalty multipliers, or compound spending levels over time.</p>
                </div>

                {/* Plotly Metric Toggles */}
                <div className="flex bg-gray-100 dark:bg-zinc-850 p-0.5 rounded-lg border border-gray-200/50 dark:border-zinc-800 text-[10px] font-bold shadow-xs">
                  <button
                    onClick={() => setCohortMetricView("retention")}
                    className={`px-3 py-1.5 rounded-md transition-all ${
                      cohortMetricView === "retention"
                        ? "bg-indigo-600 text-white font-black shadow-xs"
                        : "text-gray-500 hover:text-gray-900 dark:text-zinc-400 dark:hover:text-zinc-200"
                    }`}
                  >
                    Retention Rate
                  </button>
                  <button
                    onClick={() => setCohortMetricView("repeatRate")}
                    className={`px-3 py-1.5 rounded-md transition-all ${
                      cohortMetricView === "repeatRate"
                        ? "bg-indigo-600 text-white font-black shadow-xs"
                        : "text-gray-500 hover:text-gray-900 dark:text-zinc-400 dark:hover:text-zinc-200"
                    }`}
                  >
                    Repeat Rate
                  </button>
                  <button
                    onClick={() => setCohortMetricView("lifetimeTrend")}
                    className={`px-3 py-1.5 rounded-md transition-all ${
                      cohortMetricView === "lifetimeTrend"
                        ? "bg-indigo-600 text-white font-black shadow-xs"
                        : "text-gray-500 hover:text-gray-900 dark:text-zinc-400 dark:hover:text-zinc-200"
                    }`}
                  >
                    LTV Trend ($)
                  </button>
                </div>
              </div>

              <div id="cohort-heatmap-panel" className="my-4 relative min-h-[350px] flex items-center justify-center">
                <div id="plotly-cohort-heatmap-canvas" className="w-full h-96 min-h-[350px]" />
                
                {/* Fallback indicator */}
                {!plotlyLoaded && (
                  <div className="absolute inset-0 bg-white/75 dark:bg-zinc-900/75 flex flex-col items-center justify-center gap-2">
                    <RefreshCw className="h-7 w-7 animate-spin text-indigo-500" />
                    <span className="text-[11px] font-bold text-gray-500 dark:text-zinc-400 font-mono">Initializing Heatmap nodes...</span>
                  </div>
                )}
              </div>
              
              <div className="text-[10px] text-gray-400 italic text-center font-mono mt-auto pt-2 border-t border-gray-100 dark:border-zinc-800">
                ⭐ {cohortMetricView === "retention" && "Heatmap expresses the percentage of total cohort base users who remain active/repurchase in relative Month X."}
                {cohortMetricView === "repeatRate" && "Heatmap presents cumulative repeat purchaser proportions (>= 2 purchases total across operations up to Month X)."}
                {cohortMetricView === "lifetimeTrend" && "Heatmap illustrates compound average cumulative customer lifetime spend (LTV) generated per customer in that month."}
              </div>
            </div>

            {/* Right Column (Churn Analysis & Diagnostics) */}
            <div className="lg:col-span-1 p-5 rounded-2xl border border-gray-25/65 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 flex flex-col justify-between text-left">
              <div className="space-y-4">
                <div className="border-b border-gray-100 dark:border-zinc-850 pb-3">
                  <h3 className="text-xs font-black text-gray-400 dark:text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
                    <AlertTriangle className="h-4 w-4 text-amber-500" />
                    <span>In-Depth Churn Diagnostics</span>
                  </h3>
                  <p className="text-[11px] text-gray-500 dark:text-zinc-400 mt-1 leading-normal">
                    Assess relative month-over-month drop-off markers to isolate friction bottlenecks.
                  </p>
                </div>

                {computedCohorts.length > 0 && (() => {
                  const m1RetList = computedCohorts.map(c => c.retention[1]);
                  const m2RetList = computedCohorts.map(c => c.retention[2]);
                  const m3RetList = computedCohorts.map(c => c.retention[3]);

                  const avgM1Ret = m1RetList.reduce((acc, v) => acc + v, 0) / m1RetList.length;
                  const avgM2Ret = m2RetList.reduce((acc, v) => acc + v, 0) / m2RetList.length;
                  const avgM3Ret = m3RetList.reduce((acc, v) => acc + v, 0) / m3RetList.length;

                  // MoM relative drops
                  const step0To1Churn = parseFloat((100 - avgM1Ret).toFixed(1));
                  const step1To2Churn = parseFloat((avgM1Ret > 0 ? ((avgM1Ret - avgM2Ret) / avgM1Ret) * 100 : 0).toFixed(1));
                  const step2To3Churn = parseFloat((avgM2Ret > 0 ? ((avgM2Ret - avgM3Ret) / avgM2Ret) * 100 : 0).toFixed(1));

                  return (
                    <div className="space-y-4">
                      {/* Churn Funnel Progress indicators */}
                      <div className="space-y-2">
                        <div>
                          <div className="flex justify-between text-[11px] font-bold text-gray-700 dark:text-zinc-300 mb-1">
                            <span>Month 0 → Month 1 Immediate Churn</span>
                            <span className="text-rose-500 font-mono font-black">{step0To1Churn}%</span>
                          </div>
                          <div className="w-full bg-gray-100 dark:bg-zinc-800 h-2 rounded-full overflow-hidden">
                            <div className="bg-rose-500 h-2 rounded-full" style={{ width: `${Math.min(100, step0To1Churn)}%` }} />
                          </div>
                          <span className="text-[9px] text-gray-400 mt-0.5 block">First loyalty barrier. High immediate friction indicates acquisition mismatch.</span>
                        </div>

                        <div>
                          <div className="flex justify-between text-[11px] font-bold text-gray-700 dark:text-zinc-300 mb-1">
                            <span>Month 1 → Month 2 MoM Drop-Off</span>
                            <span className="text-amber-500 font-mono font-black">{step1To2Churn}%</span>
                          </div>
                          <div className="w-full bg-gray-100 dark:bg-zinc-800 h-2 rounded-full overflow-hidden">
                            <div className="bg-amber-500 h-2 rounded-full" style={{ width: `${Math.min(100, step1To2Churn)}%` }} />
                          </div>
                          <span className="text-[9px] text-gray-400 mt-0.5 block">Relative drop among initial returning users. Check post-purchase email workflows.</span>
                        </div>

                        <div>
                          <div className="flex justify-between text-[11px] font-bold text-gray-700 dark:text-zinc-300 mb-1">
                            <span>Month 2 → Month 3 Stabilizing Drop</span>
                            <span className="text-indigo-400 font-mono font-black">{step2To3Churn}%</span>
                          </div>
                          <div className="w-full bg-gray-100 dark:bg-zinc-800 h-2 rounded-full overflow-hidden">
                            <div className="bg-indigo-400 h-2 rounded-full" style={{ width: `${Math.min(100, step2To3Churn)}%` }} />
                          </div>
                          <span className="text-[9px] text-gray-400 mt-0.5 block">A small stabilizing drop denotes long-term user maturity.</span>
                        </div>
                      </div>

                      {/* Churn Alert notifications */}
                      {step0To1Churn > 70 && (
                        <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl flex gap-2 text-rose-700 dark:text-rose-300 text-[10px]">
                          <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                          <div>
                            <strong>Critical Month 1 Dropoff:</strong>
                            <p className="mt-0.5 leading-normal">Immediate drop is {step0To1Churn}%. Introduce post-purchase automated loyalty vouchers or discount triggers right in week 1 to combat high bounce levels.</p>
                          </div>
                        </div>
                      )}

                      {step2To3Churn < 15 && (
                        <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex gap-2 text-emerald-700 dark:text-emerald-300 text-[10px]">
                          <CheckCircle className="h-4 w-4 shrink-0 mt-0.5" />
                          <div>
                            <strong>Loyalty Core Stabilized:</strong>
                            <p className="mt-0.5 leading-normal">Month 3 drop is low ({step2To3Churn}% relative). Spender retention has successfully flattened out, yielding recurring LTV predictability.</p>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })()}
              </div>

              {/* Advice Box */}
              <div className="p-3 bg-indigo-500/5 border border-indigo-500/10 rounded-xl text-[10px] text-indigo-750 dark:text-indigo-400 flex gap-2 mt-4">
                <Sparkles className="h-4 w-4 shrink-0 mt-0.5 text-indigo-500" />
                <p className="leading-normal font-medium">
                  <strong>Retention Strategy:</strong> Subscribing cohorts display 3.5x higher LTV trends across Month 3. Highlight subscription triggers inside the checkout sequence.
                </p>
              </div>
            </div>
          </div>

          {/* Detailed Cohort Matrix Table (Month 0 to Month 3) */}
          <div className="p-5 rounded-2xl border border-gray-200/50 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 text-left transition-all">
            <div className="border-b border-gray-150 dark:border-zinc-850 pb-3 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <h3 className="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2">
                  <Grid3X3 className="h-4.5 w-4.5 text-gray-500" />
                  <span>Cohort Master Grid Ledger</span>
                </h3>
                <p className="text-[10px] text-gray-400 mt-0.5">
                  Consolidated monthly matrix tracking individual cohort progress indices across relative months.
                </p>
              </div>

              {/* Mode visual label */}
              <span className="text-[10px] font-mono text-indigo-600 bg-indigo-500/10 p-1 px-2.5 rounded-full font-bold">
                Table View: {cohortMetricView === "retention" ? "Retention Rate (%)" : cohortMetricView === "repeatRate" ? "Repeat Order Rate (%)" : "Cumulative Spend Average ($)"}
              </span>
            </div>

            <div className="mt-4 overflow-x-auto">
              <table className="w-full text-xs text-left border-collapse min-w-[750px]">
                <thead>
                  <tr className="border-b border-gray-150 dark:border-zinc-800 text-[10px] text-gray-400 font-mono uppercase tracking-wider">
                    <th scope="col" className="py-2.5 px-3">Cohort Month</th>
                    <th scope="col" className="py-2.5 px-3">Base Size (n)</th>
                    <th scope="col" className="py-2.5 px-3 text-center bg-gray-50/50 dark:bg-zinc-850/30">Month 0 (Base)</th>
                    <th scope="col" className="py-2.5 px-3 text-center bg-gray-50/50 dark:bg-zinc-850/30 font-bold text-indigo-600 dark:text-indigo-400">Month 1</th>
                    <th scope="col" className="py-2.5 px-3 text-center bg-gray-50/50 dark:bg-zinc-850/30">Month 2</th>
                    <th scope="col" className="py-2.5 px-3 text-center bg-gray-50/50 dark:bg-zinc-850/30 font-bold text-cyan-600 dark:text-cyan-400">Month 3</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-zinc-850 font-medium">
                  {computedCohorts.map((coh, idx) => {
                    // Soft color styling generators for cell backgrounds
                    const getCellBgClass = (val: number, isBase: boolean) => {
                      if (isBase) return "bg-gray-50/20 dark:bg-zinc-850/10 font-bold text-gray-900 dark:text-white";
                      if (cohortMetricView === "retention") {
                        if (val > 25) return "bg-indigo-500/25 text-indigo-800 dark:text-indigo-200 border-r border-indigo-50/50 dark:border-zinc-800/20";
                        if (val > 15) return "bg-indigo-500/15 text-indigo-700 dark:text-indigo-300 border-r border-indigo-50/30 dark:border-zinc-800/20";
                        if (val > 8) return "bg-indigo-500/8 text-indigo-600 dark:text-indigo-400 border-r border-indigo-50/25 dark:border-zinc-800/20";
                        return "bg-indigo-500/4 text-gray-400 dark:text-zinc-500 border-r border-indigo-50/10";
                      } else if (cohortMetricView === "repeatRate") {
                        if (val > 20) return "bg-cyan-500/25 text-cyan-800 dark:text-cyan-200 border-r border-cyan-50/50 dark:border-zinc-800/20";
                        if (val > 12) return "bg-cyan-500/15 text-cyan-700 dark:text-cyan-300 border-r border-cyan-50/30 dark:border-zinc-800/20";
                        if (val > 6) return "bg-cyan-500/8 text-cyan-600 dark:text-cyan-400 border-r border-cyan-50/25 dark:border-zinc-800/20";
                        return "bg-cyan-500/4 text-gray-400 dark:text-zinc-500 border-r border-cyan-50/10";
                      } else { // LTV Spend Trend
                        if (val > 150) return "bg-emerald-500/20 text-emerald-800 dark:text-emerald-200 border-r border-emerald-50/50 dark:border-zinc-800/20";
                        if (val > 100) return "bg-emerald-500/12 text-emerald-700 dark:text-emerald-300 border-r border-emerald-50/30 dark:border-zinc-800/20";
                        if (val > 50) return "bg-emerald-500/7 text-emerald-600 dark:text-emerald-400 border-r border-emerald-50/25 dark:border-zinc-800/20";
                        return "bg-emerald-500/3 text-gray-400 dark:text-zinc-500 border-r border-emerald-50/10";
                      }
                    };

                    const renderCell = (v: number, isBase: boolean) => {
                      if (cohortMetricView === "lifetimeTrend") return `$${v.toFixed(2)}`;
                      return `${v}%`;
                    };

                    return (
                      <tr key={idx} className="hover:bg-gray-55/30 dark:hover:bg-zinc-850/10 transition-colors">
                        <td className="py-3 px-3 font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                          <div className={`h-2 h-2 rounded-full ${idx === 0 ? "bg-indigo-500" : idx === 1 ? "bg-blue-500" : "bg-cyan-500"}`} />
                          <span>{coh.cohortName}</span>
                        </td>
                        <td className="py-3 px-3 font-mono font-bold text-gray-500 dark:text-zinc-450">{coh.size.toLocaleString()} users</td>
                        <td className={`py-3 px-3 text-center font-mono ${getCellBgClass(coh.retention[0], true)}`}>
                          {cohortMetricView === "lifetimeTrend" ? `$${coh.cumulativeRevenue[0].toFixed(2)}` : "100.0%"}
                        </td>
                        <td className={`py-3 px-3 text-center font-mono font-semibold ${getCellBgClass(cohortMetricView === 'retention' ? coh.retention[1] : cohortMetricView === 'repeatRate' ? coh.repeatRate[1] : coh.cumulativeRevenue[1], false)}`}>
                          {renderCell(cohortMetricView === "retention" ? coh.retention[1] : cohortMetricView === "repeatRate" ? coh.repeatRate[1] : coh.cumulativeRevenue[1], false)}
                        </td>
                        <td className={`py-3 px-3 text-center font-mono ${getCellBgClass(cohortMetricView === 'retention' ? coh.retention[2] : cohortMetricView === 'repeatRate' ? coh.repeatRate[2] : coh.cumulativeRevenue[2], false)}`}>
                          {renderCell(cohortMetricView === "retention" ? coh.retention[2] : cohortMetricView === "repeatRate" ? coh.repeatRate[2] : coh.cumulativeRevenue[2], false)}
                        </td>
                        <td className={`py-3 px-3 text-center font-mono font-bold ${getCellBgClass(cohortMetricView === 'retention' ? coh.retention[3] : cohortMetricView === 'repeatRate' ? coh.repeatRate[3] : coh.cumulativeRevenue[3], false)}`}>
                          {renderCell(cohortMetricView === "retention" ? coh.retention[3] : cohortMetricView === "repeatRate" ? coh.repeatRate[3] : coh.cumulativeRevenue[3], false)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
