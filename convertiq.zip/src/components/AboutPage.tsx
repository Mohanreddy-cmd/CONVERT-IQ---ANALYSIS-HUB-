import React, { useState, useRef } from "react";
import {
  Sparkles,
  Upload,
  FileSpreadsheet,
  FileText,
  TrendingUp,
  Inbox,
  CheckCircle,
  HelpCircle,
  Cpu,
  BrainCircuit,
  ArrowRight,
  Gauge,
  Workflow,
  AlertCircle
} from "lucide-react";
import { IngestedRecord, UploadHistoryItem, ValidationSummary } from "../types";
import { parseCSV, parseExcel, parsePDFSimulated, validateDataset, formatToIngestedRecords } from "../utils/fileParser";

interface AboutPageProps {
  onDataParsed: (recordsCount: number, fileName: string, fileDataSummary: any, parsedRecords: IngestedRecord[]) => void;
  uploadHistory: UploadHistoryItem[];
  setUploadHistory: React.Dispatch<React.SetStateAction<UploadHistoryItem[]>>;
  onStartProcessing: () => void;
  conversionPreference: string;
  setConversionPreference: (preference: string) => void;
  triggerOnExploreDemo: () => void;
}

export default function AboutPage({
  onDataParsed,
  uploadHistory,
  setUploadHistory,
  onStartProcessing,
  conversionPreference,
  setConversionPreference,
  triggerOnExploreDemo
}: AboutPageProps) {
  const [dragActive, setDragActive] = useState(false);
  const [parsingProgress, setParsingProgress] = useState<number | null>(null);
  const [selectedFile, setSelectedFile] = useState<{
    name: string;
    size: string;
    count: number;
    format: "CSV" | "XLSX" | "PDF";
  } | null>(null);

  const [validationResult, setValidationResult] = useState<ValidationSummary | null>(null);
  const [parsedRecords, setParsedRecords] = useState<IngestedRecord[]>([]);
  const [validationError, setValidationError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Common quick-setting preferences for user convenience
  const quickPreferences = [
    "Maximize checkout completion rate and cart conversion",
    "Identify mobile cart abandonment and dropoff friction",
    "Boost repeat traffic and VIP cohort spend",
    "Identify geographic regions with lagging product views"
  ];

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelected(e.dataTransfer.files[0]);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileSelected(e.target.files[0]);
    }
  };

  const formatBytes = (bytes: number, decimals = 2) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ["Bytes", "KB", "MB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i];
  };

  const handleFileSelected = (file: File) => {
    const extension = file.name.split(".").pop()?.toLowerCase();
    const authorized = ["csv", "xlsx", "xls", "pdf"];
    
    if (!extension || !authorized.includes(extension)) {
      setValidationError("Unrecognized format. Please upload a valid CSV (.csv), Excel (.xlsx, .xls) or PDF report.");
      setSelectedFile(null);
      setValidationResult(null);
      setParsedRecords([]);
      return;
    }

    setValidationError(null);
    setParsingProgress(10);

    const reader = new FileReader();

    reader.onload = async (e) => {
      try {
        let rawRows: any[] = [];
        const fileFormat = extension === "pdf" ? "PDF" : (extension === "csv" ? "CSV" : "XLSX");

        if (fileFormat === "PDF") {
          // Parse PDF using layperson simulation mapper
          rawRows = parsePDFSimulated(file.name, formatBytes(file.size));
        } else if (fileFormat === "CSV") {
          const text = e.target?.result as string;
          rawRows = await parseCSV(text);
        } else {
          const arrayBuffer = e.target?.result as ArrayBuffer;
          rawRows = parseExcel(arrayBuffer);
        }

        // Run structured schema mappers and fuzzy indicators
        const summary = validateDataset(rawRows);
        setValidationResult(summary);

        const formatted = formatToIngestedRecords(rawRows);
        setParsedRecords(formatted);

        // Upload progress indicator animation for layout excitement
        let progressVal = 10;
        const interval = setInterval(() => {
          progressVal += 20;
          if (progressVal >= 100) {
            clearInterval(interval);
            setParsingProgress(null);
            setSelectedFile({
              name: file.name,
              size: formatBytes(file.size),
              count: rawRows.length,
              format: fileFormat
            });
          } else {
            setParsingProgress(progressVal);
          }
        }, 60);

      } catch (err: any) {
        setParsingProgress(null);
        setValidationError(`Analysis blockage: ${err.message || 'The data structure inside the file is empty or corrupted.'}`);
        setValidationResult(null);
        setParsedRecords([]);
      }
    };

    if (extension === "csv") {
      reader.readAsText(file);
    } else if (extension === "pdf") {
      // For files like PDF, we read metadata/bytes as custom simulation source
      reader.readAsText(file);
    } else {
      reader.readAsArrayBuffer(file);
    }
  };

  const executePipeline = async () => {
    if (!selectedFile || !validationResult) return;

    setParsingProgress(20);
    try {
      // POST mapped results to server or trigger immediate state alignment
      const response = await fetch("/api/generate-analytics", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          rawRows: parsedRecords,
          filters: {
            dateRange: "30d",
            region: "all",
            device: "all",
            product: "all",
            channel: "all",
            customerSegment: "all"
          }
        })
      });

      setParsingProgress(100);
      setTimeout(() => {
        setParsingProgress(null);
        
        const logItem: UploadHistoryItem = {
          id: "u" + Date.now(),
          filename: selectedFile.name,
          fileSize: selectedFile.size,
          recordCount: selectedFile.count,
          timestamp: new Date().toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" }),
          status: "success",
          format: selectedFile.format
        };

        setUploadHistory(prev => [logItem, ...prev]);
        onDataParsed(selectedFile.count, selectedFile.name, { rowCount: selectedFile.count, format: selectedFile.format }, parsedRecords);
        onStartProcessing();
      }, 400);

    } catch (apiErr: any) {
      console.error("Layout ingestion error:", apiErr);
      setValidationError(`Engine mapping error: ${apiErr.message || "Unable to map data to analytics schema."}`);
      setParsingProgress(null);
    }
  };

  return (
    <div id="about-page-root" className="space-y-8 animate-fadeIn max-w-5xl mx-auto">
      
      {/* 1. HERO SECTION & INTRODUCTION */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-tr from-slate-900 via-indigo-950 to-zinc-900 border border-slate-800/80 p-8 md:p-10 text-white shadow-xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-10 w-60 h-60 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 space-y-4 max-w-3xl">
          <div className="inline-flex items-center gap-1.5 py-1 px-3 rounded-full bg-cyan-500/10 border border-cyan-400/30 text-cyan-300 text-[10px] font-bold uppercase tracking-wider">
            <Cpu className="h-3.5 w-3.5 text-cyan-400" />
            <span>Layperson Automated Ingestion</span>
          </div>

          <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight">
            Meet <span className="bg-gradient-to-r from-cyan-450 via-cyan-300 to-indigo-300 bg-clip-text text-transparent">ConvertIQ</span>
          </h1>

          <p className="text-sm md:text-base text-zinc-300 leading-relaxed font-normal">
            An intelligent customer lifecycle analysis assistant designed for everyday entrepreneurs and business leaders. No coding, no query configurations, and no strict Excel constraints. Simply upload your log tables or reports and let ConvertIQ do the automatic heavy lifting!
          </p>

          <div className="flex flex-wrap gap-4 pt-2">
            <div className="flex items-center gap-2 text-xs text-zinc-300 font-semibold bg-white/5 border border-white/10 px-3.5 py-1.5 rounded-xl">
              <span className="h-2 w-2 rounded-full bg-cyan-450" />
              <span>Auto-Matches Any Header Names</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-zinc-300 font-semibold bg-white/5 border border-white/10 px-3.5 py-1.5 rounded-xl">
              <span className="h-2 w-2 rounded-full bg-indigo-400" />
              <span>Renders Excel Raw Previews</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-zinc-300 font-semibold bg-white/5 border border-white/10 px-3.5 py-1.5 rounded-xl">
              <span className="h-2 w-2 rounded-full bg-emerald-400" />
              <span>Performs Automated EDA</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. CORE INTERACTION AREA: UPLOAD & PREF INPUTS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* LEFT COLUMN: FILE INGESTION TERMINAL (8 COLS) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white dark:bg-zinc-900 border border-gray-150 dark:border-zinc-800 rounded-3xl p-6 shadow-sm space-y-5">
            <div>
              <h3 className="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <Upload className="h-4.5 w-4.5 text-indigo-500" />
                <span>1. Load Your Dataset (Excel, CSV, PDF)</span>
              </h3>
              <p className="text-xs text-gray-500 dark:text-zinc-400 mt-1">
                Drop your store spreadsheet file here. We fuzzy-map columns automatically, so any file compiles.
              </p>
            </div>

            {/* Drag & Drop Terminal */}
            <div
              id="file-ingester-terminal"
              onDragEnter={handleDrag}
              onDragOver={handleDrag}
              onDragLeave={handleDrag}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`cursor-pointer border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center text-center transition-all min-h-[180px] ${
                dragActive
                  ? "border-cyan-500 bg-cyan-500/5 dark:bg-cyan-550/10 scale-[0.98]"
                  : "border-gray-200 dark:border-zinc-800 hover:border-indigo-400 dark:hover:border-indigo-500/50 bg-gray-55/30 dark:bg-zinc-925/40"
              }`}
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileInputChange}
                className="hidden"
                accept=".csv,.xlsx,.xls,.pdf"
              />

              {parsingProgress !== null ? (
                <div className="space-y-3 w-full max-w-xs">
                  <div className="mx-auto h-10 w-10 rounded-full border-3 border-indigo-500/20 border-t-indigo-500 animate-spin" />
                  <div>
                    <p className="text-xs font-bold text-gray-950 dark:text-white">Analyzing Data Ingestion</p>
                    <p className="text-[10px] text-gray-550 dark:text-zinc-500 mt-0.5">Extracting metrics & fuzzy columns... {parsingProgress}%</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="mx-auto h-11 w-11 rounded-2xl bg-cyan-50 dark:bg-cyan-950/40 flex items-center justify-center border border-cyan-150 dark:border-cyan-900">
                    <Inbox className="h-5 w-5 text-cyan-600 dark:text-cyan-400 animate-bounce" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-gray-900 dark:text-white">Drag & drop files or click to browser</p>
                    <p className="text-[10px] text-gray-500 dark:text-zinc-400 mt-1 max-w-md leading-relaxed">
                      Select Microsoft Excel (<strong className="font-semibold text-gray-600 dark:text-zinc-300">.xlsx / .xls</strong>), Comma-separated (<strong className="font-semibold text-gray-600 dark:text-zinc-300">.csv</strong>), or standard Analyst reports (<strong className="font-semibold text-gray-600 dark:text-zinc-300">.pdf</strong>).
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Error alerts */}
            {validationError && (
              <div className="p-3 bg-rose-500/5 border border-rose-500/15 rounded-xl text-rose-800 dark:text-rose-400 text-xs flex gap-2">
                <AlertCircle className="h-4 w-4 text-rose-500 flex-shrink-0 mt-0.5" />
                <p>{validationError}</p>
              </div>
            )}

            {/* Predefined preview mapping report */}
            {selectedFile && validationResult && (
              <div className="p-4 bg-gray-50/55 dark:bg-zinc-850/40 border border-gray-150 dark:border-zinc-800 rounded-2xl space-y-3.5">
                <div className="flex justify-between items-center pb-2 border-b border-gray-200/50 dark:border-zinc-800">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-gray-900 dark:text-white">
                    {selectedFile.format === "CSV" && <FileSpreadsheet className="h-4.5 w-4.5 text-emerald-500" />}
                    {selectedFile.format === "XLSX" && <FileSpreadsheet className="h-4.5 w-4.5 text-cyan-500" />}
                    {selectedFile.format === "PDF" && <FileText className="h-4.5 w-4.5 text-rose-500" />}
                    <span className="truncate max-w-44">{selectedFile.name}</span>
                  </div>
                  <span className="text-[10px] font-bold text-indigo-650 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/50 px-2.5 py-0.5 rounded-full">
                    {selectedFile.size} • {selectedFile.count} rows
                  </span>
                </div>

                <div className="flex items-center gap-2 text-[11px] text-gray-500 dark:text-zinc-400">
                  <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0" />
                  <span>Schema auto-matched successfully! ConvertIQ is ready to map and compile indicators.</span>
                </div>

                {validationResult.errors.length > 0 && (
                  <div className="text-[10px] text-amber-600 dark:text-amber-400 bg-amber-500/5 p-2 rounded-lg font-mono">
                    {validationResult.errors[0]}
                  </div>
                )}

                <div className="flex gap-2 justify-end pt-1">
                  <button
                    onClick={() => {
                      setSelectedFile(null);
                      setValidationResult(null);
                      setParsedRecords([]);
                    }}
                    className="text-[10px] font-bold text-gray-500 hover:text-red-500 bg-gray-100 hover:bg-red-50 dark:bg-zinc-805 dark:hover:bg-red-950/25 p-2 px-3.5 rounded-xl cursor-pointer transition-all"
                  >
                    Discard
                  </button>
                  <button
                    id="about-execute-pipeline"
                    onClick={executePipeline}
                    className="text-[10px] font-bold text-white bg-gradient-to-r from-cyan-500 to-indigo-600 p-2 px-4 rounded-xl cursor-pointer transition-all shadow-md active:scale-95"
                  >
                    Generate Insights & Open Dashboard
                  </button>
                </div>
              </div>
            )}

            {/* Quick Demo Option */}
            <div className="relative flex items-center justify-center border-t border-gray-100 dark:border-zinc-800 pt-3">
              <span className="absolute bg-white dark:bg-zinc-900 px-3 text-[10px] font-bold text-gray-400 uppercase tracking-widest leading-none top-[-7px]">OR</span>
              <button
                id="about-demo-fast-btn"
                onClick={triggerOnExploreDemo}
                className="flex items-center gap-1 text-[11px] font-black text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
              >
                <span>Browse our preset ConvertIQ Demo dataset instead</span>
                <ArrowRight className="h-3 w-3" />
              </button>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: DYNAMIC LLM PREFERENTIAL TUNER (5 COLS) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white dark:bg-zinc-900 border border-gray-150 dark:border-zinc-800 rounded-3xl p-6 shadow-sm flex flex-col justify-between h-full space-y-5">
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-sm font-bold text-gray-900 dark:text-white pb-3 border-b border-gray-100 dark:border-zinc-805">
                <BrainCircuit className="h-5 w-5 text-indigo-500" />
                <span>2. Core Loss Preference (AI Input)</span>
              </div>

              <p className="text-xs text-gray-500 dark:text-zinc-400 leading-relaxed">
                Tell the Gemini LLM exactly which loss or conversion goal to optimize for. The dashboard suggestions, checklists, and chat adaptation will instantly focus on this preference!
              </p>

              {/* Text Area preference input */}
              <div className="space-y-2">
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-wider">My Preference Goal:</label>
                <textarea
                  id="conversion-preference-textarea"
                  value={conversionPreference}
                  onChange={(e) => setConversionPreference(e.target.value)}
                  className="w-full text-xs p-3 rounded-xl border border-gray-200 dark:border-zinc-800 bg-slate-55/30 dark:bg-zinc-950/60 focus:outline-none focus:border-indigo-500 min-h-[90px] font-medium leading-normal placeholder-gray-400 text-gray-800 dark:text-zinc-200"
                  placeholder="e.g. Optimize checkout flows, highlight mobile friction zones..."
                />
              </div>

              {/* Quick Preset Buttons */}
              <div className="space-y-2">
                <span className="block text-[9px] font-extrabold text-gray-400 uppercase tracking-widest">Or Click a Standard Preference Preset:</span>
                <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                  {quickPreferences.map((pref, index) => (
                    <button
                      key={index}
                      onClick={() => setConversionPreference(pref)}
                      className={`w-full text-left p-2.5 rounded-xl text-[10.5px] font-medium leading-snug border transition-all cursor-pointer ${
                        conversionPreference === pref
                          ? "bg-indigo-50/70 border-indigo-200 text-indigo-700 dark:bg-indigo-950/30 dark:border-indigo-900/40 dark:text-indigo-400 font-bold"
                          : "bg-gray-55/40 hover:bg-gray-55 dark:bg-zinc-925/30 border-gray-150 dark:border-zinc-805 text-gray-600 dark:text-zinc-450 hover:text-gray-900 hover:dark:text-white"
                      }`}
                    >
                      {pref}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-3 bg-indigo-500/[0.04] border border-indigo-500/10 rounded-2xl flex items-start gap-2.5">
              <Sparkles className="h-4.5 w-4.5 text-indigo-500 mt-0.5" />
              <div className="text-[10px] text-gray-500 dark:text-indigo-300 leading-normal">
                <strong className="font-bold">LLM Config Alert:</strong> When you modify your optimization preference, the AI Insights Panel & Optimizer tabs adjust statistical highlights automatically during extraction.
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* DATASET HEAD & TAIL PREVIEW (DYNAMICS EXTRACTIVE) */}
      {selectedFile && parsedRecords.length > 0 && (
        <div id="dataset-head-tail-preview-container" className="bg-white dark:bg-zinc-900 border border-gray-150 dark:border-zinc-800 rounded-3xl p-6 shadow-sm space-y-4 text-left">
          <div className="flex flex-col sm:flex-row justify-between sm:items-center border-b border-gray-100 dark:border-zinc-805 pb-3 gap-2">
            <div className="space-y-1">
              <h3 className="text-xs font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <FileSpreadsheet className="h-4.5 w-4.5 text-emerald-500" />
                <span>Dataset Structure Verification (Head & Tail Preview)</span>
              </h3>
              <p className="text-[11px] text-gray-400">
                Direct view of the first 5 records (Head) and the last 5 records (Tail) extracted from your file.
              </p>
            </div>
            <div className="text-[10px] font-mono bg-gray-100 dark:bg-zinc-800 p-1 px-3 rounded font-black text-indigo-600 dark:text-indigo-400 shrink-0">
              Validated {parsedRecords.length} Rows × 11 Dimensions
            </div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {/* HEAD TABLE */}
            <div className="space-y-2">
              <span className="inline-flex items-center gap-1.5 text-[9px] font-black text-cyan-600 dark:text-cyan-400 uppercase tracking-widest bg-cyan-500/10 px-2.5 py-0.5 rounded font-bold">
                <span>HEAD: First 5 Records</span>
              </span>
              <div className="overflow-x-auto border border-gray-150 dark:border-zinc-800 rounded-xl bg-gray-55/10 dark:bg-zinc-950/20">
                <table className="w-full text-left text-[10px] border-collapse">
                  <thead className="bg-gray-100 dark:bg-zinc-900 border-b border-gray-150 dark:border-zinc-800 text-gray-500 dark:text-zinc-400 font-bold uppercase tracking-tight">
                    <tr>
                      <th className="p-2 pl-3 font-semibold border-r border-gray-150 dark:border-zinc-800/80">User ID</th>
                      <th className="p-2 font-semibold border-r border-gray-150 dark:border-zinc-800/80">Product Name</th>
                      <th className="p-2 font-semibold border-r border-gray-150 dark:border-zinc-800/80">Event</th>
                      <th className="p-2 text-right pr-3 font-semibold">Revenue</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-150 dark:divide-zinc-805 text-gray-700 dark:text-zinc-300">
                    {parsedRecords.slice(0, 5).map((rec, rIdx) => (
                      <tr key={rIdx} className="hover:bg-gray-150/40 dark:hover:bg-zinc-900/40 text-[10.5px]">
                        <td className="p-2 pl-3 font-mono text-[9px] max-w-16 truncate border-r border-gray-150 dark:border-zinc-800/80">{rec.user_id}</td>
                        <td className="p-2 truncate max-w-28 border-r border-gray-150 dark:border-zinc-800/80" title={rec.product_name}>{rec.product_name}</td>
                        <td className="p-2 border-r border-gray-150 dark:border-zinc-800/80">
                          <span className={`inline-block text-[8px] font-bold uppercase tracking-tight px-1.5 py-0.2 rounded ${
                            rec.event_type === "purchase" ? "bg-emerald-500/10 text-emerald-500" :
                            rec.event_type === "checkout" ? "bg-amber-500/10 text-amber-500" :
                            rec.event_type === "cart" ? "bg-blue-500/10 text-blue-500" :
                            "bg-gray-400/10 text-gray-400"
                          }`}>{rec.event_type}</span>
                        </td>
                        <td className="p-2 text-right pr-3 font-mono font-bold text-gray-905 dark:text-zinc-150">{rec.revenue > 0 ? `$${rec.revenue.toFixed(2)}` : "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* TAIL TABLE */}
            <div className="space-y-2">
              <span className="inline-flex items-center gap-1.5 text-[9px] font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-widest bg-indigo-500/10 px-2.5 py-0.5 rounded font-bold">
                <span>TAIL: Last 5 Records</span>
              </span>
              <div className="overflow-x-auto border border-gray-150 dark:border-zinc-800 rounded-xl bg-gray-55/10 dark:bg-zinc-950/20">
                <table className="w-full text-left text-[10px] border-collapse">
                  <thead className="bg-gray-100 dark:bg-zinc-900 border-b border-gray-150 dark:border-zinc-800 text-gray-500 dark:text-zinc-400 font-bold uppercase tracking-tight">
                    <tr>
                      <th className="p-2 pl-3 font-semibold border-r border-gray-150 dark:border-zinc-800/80">User ID</th>
                      <th className="p-2 font-semibold border-r border-gray-150 dark:border-zinc-800/80">Product Name</th>
                      <th className="p-2 font-semibold border-r border-gray-150 dark:border-zinc-800/80">Event</th>
                      <th className="p-2 text-right pr-3 font-semibold">Revenue</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-150 dark:divide-zinc-805 text-gray-700 dark:text-zinc-300">
                    {parsedRecords.slice(-5).map((rec, rIdx) => (
                      <tr key={rIdx} className="hover:bg-gray-150/40 dark:hover:bg-zinc-900/40 text-[10.5px]">
                        <td className="p-2 pl-3 font-mono text-[9px] max-w-16 truncate border-r border-gray-150 dark:border-zinc-800/80">{rec.user_id}</td>
                        <td className="p-2 truncate max-w-28 border-r border-gray-150 dark:border-zinc-800/80" title={rec.product_name}>{rec.product_name}</td>
                        <td className="p-2 border-r border-gray-150 dark:border-zinc-800/80">
                          <span className={`inline-block text-[8px] font-bold uppercase tracking-tight px-1.5 py-0.1 rounded ${
                            rec.event_type === "purchase" ? "bg-emerald-500/10 text-emerald-500" :
                            rec.event_type === "checkout" ? "bg-amber-500/10 text-amber-500" :
                            rec.event_type === "cart" ? "bg-blue-500/10 text-blue-500" :
                            "bg-gray-400/10 text-gray-400"
                          }`}>{rec.event_type}</span>
                        </td>
                        <td className="p-2 text-right pr-3 font-mono font-bold text-gray-905 dark:text-zinc-150">{rec.revenue > 0 ? `$${rec.revenue.toFixed(2)}` : "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. STEPS WORKFLOW DISPLAY */}
      <div className="bg-white/40 dark:bg-zinc-900/10 rounded-2xl p-6 border border-gray-150 dark:border-zinc-900 text-center">
        <h3 className="text-xs font-black text-gray-400 uppercase tracking-wider mb-6">Optimizing In 3 Layperson Steps:</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="flex flex-col items-center space-y-2">
            <div className="h-9 w-9 rounded-full bg-cyan-100 dark:bg-cyan-950/40 flex items-center justify-center text-cyan-600 dark:text-cyan-400 font-extrabold text-sm">1</div>
            <h4 className="text-xs font-black text-gray-900 dark:text-white">Load Reporting Data</h4>
            <p className="text-[10px] text-gray-500 dark:text-zinc-400 leading-relaxed max-w-xs">Drop any CSV log, XLS file, or PDF summary. ConvertIQ automates header alignment instantly.</p>
          </div>
          <div className="flex flex-col items-center space-y-2">
            <div className="h-9 w-9 rounded-full bg-indigo-100 dark:bg-indigo-950/40 flex items-center justify-center text-indigo-650 dark:text-indigo-450 font-extrabold text-sm">2</div>
            <h4 className="text-xs font-black text-gray-900 dark:text-white">Configure AI preference</h4>
            <p className="text-[10px] text-gray-500 dark:text-zinc-400 leading-relaxed max-w-xs">Set your particular ecommerce target, aligning live metrics boards and correlation lists.</p>
          </div>
          <div className="flex flex-col items-center space-y-2">
            <div className="h-9 w-9 rounded-full bg-indigo-100 dark:bg-indigo-950/40 flex items-center justify-center text-indigo-650 dark:text-indigo-450 font-extrabold text-sm">3</div>
            <h4 className="text-xs font-black text-gray-900 dark:text-white">Review Excel & EDA Side-by-Side</h4>
            <p className="text-[10px] text-gray-500 dark:text-zinc-400 leading-relaxed max-w-xs">Observe live tabular rows right next to active funnels, review complete statistics, and print custom PDF reports.</p>
          </div>
        </div>
      </div>

    </div>
  );
}
