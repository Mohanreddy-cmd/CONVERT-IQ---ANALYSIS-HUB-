import { useState } from "react";
import {
  BarChart3,
  TrendingUp,
  Inbox,
  ChevronLeft,
  HelpCircle,
  Sparkles,
  Layers,
  FileSpreadsheet,
  BrainCircuit,
  FileText
} from "lucide-react";
import { ActiveTab } from "../types";

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  isCollapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
}

export default function Sidebar({
  activeTab,
  setActiveTab,
  isCollapsed,
  setCollapsed,
}: SidebarProps) {
  // Simple, clean layperson workflow groups
  const menuGroups = [
    {
      group: "Ingestion Portal",
      items: [
        {
          id: "about" as ActiveTab,
          label: "About & Upload",
          icon: Inbox,
        },
      ],
    },
    {
      group: "Operational Analytics",
      items: [
        {
          id: "dashboard" as ActiveTab,
          label: "Spreadsheet Dashboard",
          icon: BarChart3,
        },
        {
          id: "eda" as ActiveTab,
          label: "Automated EDA",
          icon: FileSpreadsheet,
        },
        {
          id: "reports" as ActiveTab,
          label: "Executive Report Hub",
          icon: FileText,
        },
      ],
    },
    {
      group: "AI Command Model",
      items: [
        {
          id: "customAnalysis" as ActiveTab,
          label: "Custom Analysis Prompt",
          icon: BrainCircuit,
        },
        {
          id: "optimizer" as ActiveTab,
          label: "AI Genius Optimizer",
          icon: Sparkles,
        },
      ],
    },
  ];

  return (
    <aside
      id="sidebar-container"
      className={`fixed top-0 left-0 bottom-0 z-40 bg-zinc-950 text-zinc-100 flex flex-col justify-between border-r border-zinc-800/70 transition-all duration-300 ease-in-out ${
        isCollapsed ? "w-16" : "w-64"
      }`}
    >
      {/* Brand Logo & Header */}
      <div>
        <div className="h-16 flex items-center justify-between px-4 border-b border-zinc-800/60 bg-zinc-950/90 backdrop-blur">
          <div
            className="flex items-center gap-2.5 cursor-pointer"
            onClick={() => setActiveTab("about")}
          >
            <div className="h-9 w-9 rounded-xl flex items-center justify-center bg-gradient-to-tr from-cyan-500 to-indigo-600 text-white font-black text-sm tracking-tighter shadow-md shadow-indigo-500/20">
              C
            </div>
            {!isCollapsed && (
              <span className="font-extrabold text-sm tracking-tight bg-gradient-to-r from-zinc-50 via-zinc-100 to-zinc-300 bg-clip-text text-transparent flex items-center gap-1">
                Convert<span className="text-cyan-400">IQ</span>
              </span>
            )}
          </div>
          <button
            id="sidebar-collapse-btn"
            onClick={() => setCollapsed(!isCollapsed)}
            className="p-1 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800/60 focus:outline-none"
          >
            <ChevronLeft className={`h-4.5 w-4.5 transition-transform duration-300 ${isCollapsed ? "rotate-180" : ""}`} />
          </button>
        </div>

        {/* Navigation Categories */}
        <nav className="p-3 space-y-5 overflow-y-auto max-h-[calc(100vh-140px)] scrollbar-thin scrollbar-thumb-zinc-700">
          {menuGroups.map((group, gIdx) => (
            <div key={gIdx} className="space-y-1">
              {!isCollapsed && (
                <p className="text-[10px] font-semibold text-zinc-500 tracking-wider uppercase px-3 mb-1.5">
                  {group.group}
                </p>
              )}
              <div className="space-y-0.5">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      id={`sidebar-item-${item.id}`}
                      key={item.id}
                      onClick={() => setActiveTab(item.id)}
                      className={`w-full flex items-center px-3 py-2 rounded-xl text-left text-xs font-semibold transition-all duration-200 group relative ${
                        isActive
                          ? "bg-gradient-to-r from-cyan-500/10 to-indigo-600/15 border-l-2 border-cyan-400 text-cyan-300 font-semibold animate-fadeIn"
                          : "text-zinc-400 hover:text-zinc-150 hover:bg-zinc-900/60"
                      }`}
                    >
                      <Icon
                        className={`h-4.5 w-4.5 flex-shrink-0 transition-transform duration-200 group-hover:scale-105 ${
                          isActive ? "text-cyan-400" : "text-zinc-400 group-hover:text-zinc-200"
                        }`}
                      />
                      {!isCollapsed && (
                        <span className="ml-3 truncate">{item.label}</span>
                      )}
                      {isActive && !isCollapsed && (
                        <div className="absolute right-3 top-2.5 w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                      )}
                      
                      {/* Tooltip on collapse */}
                      {isCollapsed && (
                        <div className="absolute left-16 hidden group-hover:block bg-zinc-900 text-zinc-100 text-[10px] px-2 py-1 rounded-md ml-1 shadow-xl border border-zinc-800 whitespace-nowrap z-50 animate-fadeIn">
                          {item.label}
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>
      </div>

      {/* Footer Settings & Meta */}
      <div className="p-3 border-t border-zinc-800/60 bg-zinc-950/80">
        <button
          id="sidebar-help-btn"
          onClick={() => setActiveTab("about")}
          className="w-full flex items-center px-3 py-1.5 rounded-xl text-left text-xs font-medium text-zinc-450 hover:text-zinc-200 hover:bg-zinc-900/60 transition-all duration-200 group relative"
        >
          <Layers className="h-4.5 w-4.5 text-zinc-400 group-hover:text-zinc-300" />
          {!isCollapsed && <span className="ml-3 truncate font-semibold">ConvertIQ Engine</span>}
        </button>
        {!isCollapsed && (
          <div className="mt-3 px-3 py-2 rounded-xl bg-gradient-to-br from-indigo-950/40 via-purple-950/25 to-zinc-900 border border-zinc-800/60">
            <div className="flex items-center gap-1.5 text-[10px] font-semibold text-indigo-300">
              <Sparkles className="h-3 w-3 animate-spin duration-3000 text-cyan-400" />
              <span>CO-PILOT ACTIVE</span>
            </div>
            <p className="text-[9px] text-zinc-400 mt-0.5 leading-relaxed">
              Arbitrary spreadsheet mappers successfully deployed.
            </p>
          </div>
        )}
      </div>
    </aside>
  );
}
