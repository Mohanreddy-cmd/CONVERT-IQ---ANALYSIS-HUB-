import { Sun, Moon } from "lucide-react";

interface ThemeToggleProps {
  theme: "dark" | "light";
  toggleTheme: () => void;
}

export default function ThemeToggle({ theme, toggleTheme }: ThemeToggleProps) {
  return (
    <button
      id="theme-toggle-btn"
      onClick={toggleTheme}
      className="p-2 mr-1 rounded-xl transition-all duration-300 relative overflow-hidden bg-gray-100 hover:bg-gray-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-gray-700 dark:text-zinc-200 shadow-sm border border-gray-200/50 dark:border-zinc-700/50 focus:outline-none"
      title={theme === "light" ? "Switch to Dark Mode" : "Switch to Light Mode"}
    >
      <div className="flex items-center justify-center h-5 w-5">
        {theme === "light" ? (
          <Moon className="h-4.5 w-4.5 text-slate-700 transition-transform duration-300 hover:rotate-12" />
        ) : (
          <Sun className="h-4.5 w-4.5 text-amber-400 transition-transform duration-300 hover:scale-110" />
        )}
      </div>
    </button>
  );
}
