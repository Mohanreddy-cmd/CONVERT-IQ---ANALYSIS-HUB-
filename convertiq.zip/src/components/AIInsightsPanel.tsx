import React, { useState } from "react";
import {
  Sparkles,
  HelpCircle,
  CheckCircle,
  AlertTriangle,
  Send,
  RefreshCw,
  TrendingUp,
  Smartphone,
  ShoppingBag,
  Target,
  Brain,
  Zap,
  ArrowRight
} from "lucide-react";
import { AIAnalysisResult } from "../types";

interface AIInsightsPanelProps {
  insights: AIAnalysisResult;
  loading: boolean;
  onRefresh: () => void;
  onAskCustomPrompt: (prompt: string) => Promise<string>;
  conversionPreference: string;
  chatHistory?: { sender: 'user' | 'assistant'; text: string; time: string }[];
  setChatHistory?: React.Dispatch<React.SetStateAction<{ sender: 'user' | 'assistant'; text: string; time: string }[]>>;
}

export default function AIInsightsPanel({
  insights,
  loading,
  onRefresh,
  onAskCustomPrompt,
  conversionPreference,
  chatHistory: propChatHistory,
  setChatHistory: propSetChatHistory
}: AIInsightsPanelProps) {
  const [userInput, setUserInput] = useState("");
  const [localChatHistory, setLocalChatHistory] = useState<{ sender: 'user' | 'assistant'; text: string; time: string }[]>([]);
  const [asking, setAsking] = useState(false);

  const chatHistory = propChatHistory || localChatHistory;
  const setChatHistory = propSetChatHistory || setLocalChatHistory;

  const handleAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userInput.trim()) return;

    const userMessage = userInput;
    setUserInput("");
    setAsking(true);

    const currentTimeStr = new Date().toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });

    // Append user query
    setChatHistory((prev) => [
      ...prev,
      { sender: "user" as const, text: userMessage, time: currentTimeStr }
    ]);

    // Instruct LLM with their custom preference context
    const instructions = `[Context: User's Conversion Preference is "${conversionPreference}"]. Question: ${userMessage}`;

    try {
      const response = await onAskCustomPrompt(instructions);
      setChatHistory((prev) => [
        ...prev,
        { sender: "assistant" as const, text: response, time: currentTimeStr }
      ]);
    } catch (err) {
      setChatHistory((prev) => [
        ...prev,
        { sender: "assistant" as const, text: "Sincere apologies, the secure Gemini calculation framework experienced a transient network state. Please submit the query again.", time: currentTimeStr }
      ]);
    } finally {
      setAsking(false);
    }
  };

  return (
    <div id="ai-insights-panel-container" className="space-y-6 animate-fadeIn">
      
      {/* Executive Command Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center bg-gradient-to-tr from-slate-900 to-indigo-950 p-6 rounded-3xl border border-slate-800 shadow-lg gap-4">
        <div className="flex gap-3 items-center">
          <div className="h-10 w-10 rounded-2xl bg-gradient-to-tr from-cyan-400 to-indigo-500 text-white flex items-center justify-center shadow-lg shadow-cyan-500/15">
            <Sparkles className="h-5 w-5 text-cyan-200 animate-pulse" />
          </div>
          <div className="text-left">
            <h3 className="text-sm font-black text-white uppercase tracking-wider">ConvertIQ Genius LLM Optimizer</h3>
            <p className="text-[10.5px] text-zinc-300 mt-0.5">Automated deep audits, recommendations, and conversational maps derived from LLM parsing models.</p>
          </div>
        </div>

        <button
          id="refresh-insights-btn"
          onClick={onRefresh}
          disabled={loading}
          className="p-2.5 rounded-xl text-zinc-300 hover:text-white bg-white/5 border border-white/10 hover:bg-white/10 transition-colors disabled:opacity-40 focus:outline-none shrink-0"
          title="Regenerate Gemini Insights"
        >
          <RefreshCw className={`h-4.5 w-4.5 ${loading ? "animate-spin" : ""}`} />
        </button>
      </div>

      {/* DYNAMIC CONVERSION PREFERENCE FOCUS CARD */}
      <div className="p-5 bg-indigo-50 border border-indigo-150/75 dark:bg-indigo-950/20 dark:border-indigo-900/60 rounded-3xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex gap-3 items-start">
          <div className="p-2 bg-indigo-100 rounded-2xl dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 shrink-0 mt-0.5">
            <Target className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
          </div>
          <div className="text-left space-y-1">
            <div className="flex items-center gap-1.5 font-sans">
              <span className="text-[10px] font-black text-indigo-650 dark:text-indigo-450 uppercase tracking-widest">Active Preference Alignment</span>
              <span className="h-1.5 w-1.5 rounded-full bg-indigo-500 animate-ping" />
            </div>
            <p className="text-xs font-black text-gray-900 dark:text-white leading-snug">
              "{conversionPreference}"
            </p>
            <p className="text-[10.5px] text-gray-500 dark:text-zinc-400">
              Your customized goals are wired directly into recommendation severity indices and conversation parameters.
            </p>
          </div>
        </div>

        <div className="text-[10px] font-bold text-indigo-750 bg-indigo-100/60 dark:text-indigo-400 dark:bg-indigo-950/40 p-2 rounded-xl border border-indigo-200/50 dark:border-indigo-900/40 flex items-center gap-1">
          <Brain className="h-3.5 w-3.5" />
          <span>Gemini Model Live Tuning Activated</span>
        </div>
      </div>

      {loading ? (
        <div className="p-16 text-center space-y-3 bg-white dark:bg-zinc-900 rounded-3xl border border-gray-150 dark:border-zinc-800">
          <div className="mx-auto h-9 w-9 rounded-full border-4 border-indigo-505/20 border-t-indigo-500 animate-spin" />
          <p className="text-xs text-gray-400 font-bold">Rerouting metrics context to Gemini models...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Main Insights Column */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* AI Business Insight Engine - Dyn Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              
              {/* Card 1 */}
              <div id="conversion-impact-card" className="p-4 rounded-2xl border border-cyan-200/40 dark:border-cyan-950/30 bg-cyan-50/15 dark:bg-cyan-950/5 flex flex-col justify-between hover:border-cyan-405 transition-colors h-40">
                <div className="flex justify-between items-start">
                  <span className="text-[9px] uppercase font-black text-cyan-600 dark:text-cyan-400 bg-cyan-500/10 px-2.5 py-0.5 rounded-full">
                    CONVERSION CORRELATION
                  </span>
                  <div className="p-1 rounded bg-cyan-500/10">
                    <TrendingUp className="h-4 w-4 text-cyan-500" />
                  </div>
                </div>
                <p className="text-[11px] font-black text-gray-900 dark:text-zinc-150 mt-3 leading-relaxed">
                  {insights.revenueIncrInsight || "Revenue increased 12% due to improved checkout conversion."}
                </p>
                <div className="text-[9px] text-gray-400 dark:text-zinc-500 mt-2 font-mono uppercase tracking-wider">
                  Revenue Value Driver
                </div>
              </div>

              {/* Card 2 */}
              <div id="mobile-traffic-card" className="p-4 rounded-2xl border border-indigo-200/40 dark:border-indigo-950/30 bg-indigo-50/15 dark:bg-indigo-950/5 flex flex-col justify-between hover:border-indigo-405 transition-colors h-40">
                <div className="flex justify-between items-start">
                  <span className="text-[9px] uppercase font-black text-indigo-600 dark:text-indigo-400 bg-indigo-500/10 px-2.5 py-0.5 rounded-full">
                    TRAFFIC VS REVENUE
                  </span>
                  <div className="p-1 rounded bg-indigo-500/10">
                    <Smartphone className="h-4 w-4 text-indigo-500" />
                  </div>
                </div>
                <p className="text-[11px] font-black text-gray-900 dark:text-zinc-150 mt-3 leading-relaxed">
                  {insights.deviceContrastInsight || "Mobile users contribute 65% of traffic but only 40% of revenue."}
                </p>
                <div className="text-[9px] text-gray-400 dark:text-zinc-500 mt-2 font-mono uppercase tracking-wider">
                  Mobile Friction Alert
                </div>
              </div>

              {/* Card 3 */}
              <div id="product-funnel-card" className="p-4 rounded-2xl border border-purple-200/40 dark:border-purple-950/30 bg-purple-50/15 dark:bg-purple-950/5 flex flex-col justify-between hover:border-purple-405 transition-colors h-40">
                <div className="flex justify-between items-start">
                  <span className="text-[9px] uppercase font-black text-purple-600 dark:text-purple-400 bg-purple-500/10 px-2.5 py-0.5 rounded-full">
                    FUNNEL LEAKAGE FLAG
                  </span>
                  <div className="p-1 rounded bg-purple-500/10">
                    <ShoppingBag className="h-4 w-4 text-purple-500" />
                  </div>
                </div>
                <p className="text-[11px] font-black text-gray-900 dark:text-zinc-150 mt-3 leading-relaxed">
                  {insights.productLeverInsight || "Product Aura Messenger has high views but low conversion."}
                </p>
                <div className="text-[9px] text-gray-400 dark:text-zinc-500 mt-2 font-mono uppercase tracking-wider">
                  Product Level Analysis
                </div>
              </div>
            </div>

            {/* Executive Summary Card */}
            <div id="executive-summary-card" className="p-5 rounded-2xl border border-gray-150 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 space-y-3">
              <h4 className="text-xs font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <span className="w-1.5 h-3 bg-cyan-500 rounded-full" />
                <span>Executive Performance Summary</span>
              </h4>
              <p className="text-xs text-gray-600 dark:text-zinc-300 leading-relaxed font-sans">
                {insights.executiveSummary}
              </p>
            </div>

            {/* Actions Checklist */}
            <div className="space-y-3 font-sans">
              <h4 className="text-xs font-black text-gray-450 uppercase tracking-widest px-1">Actionable Conversion Directives</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {insights.recommendations.map((rec, rIdx) => (
                  <div
                    key={rIdx}
                    className="p-4 rounded-xl border border-gray-150 dark:border-zinc-850 bg-white dark:bg-zinc-900/30 hover:border-indigo-500/30 transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2.5">
                        <span className={`text-[9px] uppercase font-extrabold px-2 py-0.5 rounded-full ${
                          rec.priority === "high"
                            ? "bg-rose-500/10 text-rose-500"
                            : rec.priority === "medium"
                            ? "bg-amber-500/10 text-amber-500"
                            : "bg-blue-500/10 text-blue-500"
                        }`}>
                          {rec.priority} PRIORITY
                        </span>
                        <span className="text-[9px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                          {rec.impact}
                        </span>
                      </div>
                      <h5 className="text-xs font-bold text-gray-900 dark:text-white mt-2 leading-snug">{rec.title}</h5>
                      <p className="text-[10px] text-gray-500 dark:text-zinc-400 mt-1.5 leading-normal">{rec.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Smart Alerts */}
            <div className="p-4 rounded-2xl border border-rose-200/40 dark:border-rose-950/20 bg-rose-50/25 dark:bg-rose-950/5 space-y-3 text-left">
              <h4 className="text-xs font-bold text-rose-800 dark:text-rose-450 flex items-center gap-1.5 leading-none">
                <AlertTriangle className="h-4.5 w-4.5 text-rose-505" />
                <span>Smart Alerts and Diagnostic Mismatches</span>
              </h4>
              <div className="divide-y divide-rose-200/20 dark:divide-rose-950/25 space-y-2.5">
                {insights.anomalies.map((an, aIdx) => (
                  <div key={aIdx} className="pt-2 flex items-start gap-3">
                    <span className="h-1.5 w-1.5 rounded-full bg-rose-500 shrink-0 mt-2" />
                    <div>
                      <p className="text-xs font-bold text-gray-950 dark:text-zinc-205">{an.title}</p>
                      <span className="text-[9.5px] text-gray-400 font-mono italic">Metric: {an.metric} • Severity: {an.severity}</span>
                      <p className="text-[10px] text-gray-500 dark:text-zinc-400 mt-1 leading-relaxed">{an.details}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* Chat co-pilot container (1 Col) */}
          <div className="p-5 rounded-2xl border border-gray-150 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 space-y-4 flex flex-col justify-between h-[520px] sticky top-20">
            <div className="space-y-4 flex-1 overflow-hidden flex flex-col">
              <div className="border-b border-gray-100 dark:border-zinc-805 pb-3 text-left">
                <h4 className="text-xs font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                  <HelpCircle className="h-4.5 w-4.5 text-cyan-500" />
                  <span>On-Demand AI Co-Pilot Query</span>
                </h4>
                <p className="text-[10px] text-gray-500 dark:text-zinc-400 mt-1 leading-normal">
                  Ask regarding channels, products, regions or conversion trends in your data.
                </p>
              </div>

              {/* Chat Thread Container */}
              <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                {chatHistory.length === 0 ? (
                  <div className="text-center py-20 space-y-2.5">
                    <div className="h-10 w-10 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-150 dark:border-indigo-900 rounded-full flex items-center justify-center text-indigo-500 mx-auto">
                      <Zap className="h-5 w-5 animate-pulse" />
                    </div>
                    <p className="text-[10.5px] text-gray-400 dark:text-zinc-500 max-w-[200px] mx-auto leading-relaxed">
                      "Which product catalog should we optimize first based on mobile conversion drop-offs?"
                    </p>
                  </div>
                ) : (
                  chatHistory.map((ch, i) => (
                    <div
                      key={i}
                      className={`p-2.5 rounded-xl max-w-[90%] text-[10.5px] leading-relaxed text-left ${
                        ch.sender === "user"
                          ? "bg-cyan-500/10 text-gray-900 dark:text-zinc-150 ml-auto border border-cyan-100/30"
                          : "bg-gray-100 dark:bg-zinc-850 text-gray-800 dark:text-zinc-200"
                      }`}
                    >
                      <p className="font-sans whitespace-pre-wrap">{ch.text}</p>
                      <span className="text-[8px] text-gray-400 dark:text-zinc-500 table mt-1 scale-95">{ch.time}</span>
                    </div>
                  ))
                )}

                {asking && (
                  <div className="p-2.5 rounded-xl bg-gray-50 dark:bg-zinc-850 flex items-center gap-2 max-w-[80%] text-[10.5px] text-gray-500 text-left">
                    <RefreshCw className="h-3 w-3 animate-spin text-cyan-500" />
                    <span>Analyzing metrics stream...</span>
                  </div>
                )}
              </div>
            </div>

            {/* Chat Input form */}
            <form onSubmit={handleAsk} className="flex gap-2 border-t border-gray-100 dark:border-zinc-805 pt-3">
              <input
                type="text"
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                placeholder="Ask Co-Pilot about store..."
                className="flex-1 text-[11px] bg-gray-50 dark:bg-zinc-85 border border-gray-200 dark:border-zinc-800 rounded-xl p-2.5 px-3 text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:border-cyan-500 font-sans"
              />
              <button
                id="send-custom-query-btn"
                type="submit"
                disabled={asking || !userInput.trim()}
                className="p-2.5 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 hover:opacity-90 text-white disabled:opacity-40 select-none flex items-center justify-center cursor-pointer"
              >
                <Send className="h-3.5 w-3.5" />
              </button>
            </form>
          </div>

        </div>
      )}

    </div>
  );
}
