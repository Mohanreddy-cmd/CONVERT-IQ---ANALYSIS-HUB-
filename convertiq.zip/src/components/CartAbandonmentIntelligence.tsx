import { useState, useEffect } from "react";
import {
  TrendingDown,
  AlertTriangle,
  ShoppingBag,
  Smartphone,
  Monitor,
  Tablet,
  Lightbulb,
  ArrowDownRight,
  DollarSign,
  Clock,
  Sparkles,
  ArrowRight,
  Percent,
  CheckCircle,
  HelpCircle,
  TrendingUp,
  Inbox
} from "lucide-react";
import { IngestedRecord, UnifiedMetrics, GlobalFilters } from "../types";

interface CartAbandonmentIntelligenceProps {
  metrics: UnifiedMetrics;
  filters: GlobalFilters;
  isSimulating: boolean;
  uploadedData: IngestedRecord[];
}

const PRODUCT_PRICES: Record<string, number> = {
  "Starlight Pro Wireless Headphones": 149.00,
  "Aura Leather Messenger Bag": 185.00,
  "Sonic Wave Waterproof Speaker": 89.00,
  "Titan Fit Waterproof Smartwatch": 65.00,
  "Starlight Pro": 149.00,
  "Aura Leather": 185.00,
  "Sonic Wave": 89.00,
  "Titan Fit": 65.00
};

function getProductPrice(prodName: string, baselineAov: number): number {
  if (!prodName) return baselineAov || 85.00;
  for (const [key, price] of Object.entries(PRODUCT_PRICES)) {
    if (prodName.toLowerCase().includes(key.toLowerCase())) {
      return price;
    }
  }
  return baselineAov || 85.00;
}

export default function CartAbandonmentIntelligence({
  metrics,
  filters,
  isSimulating,
  uploadedData
}: CartAbandonmentIntelligenceProps) {
  const [activeStageFilter, setActiveStageFilter] = useState<"All" | "Cart" | "Checkout">("All");
  const [activeRecIndex, setActiveRecIndex] = useState(0);

  // Core Math Engine
  const baseAOV = metrics.aov || 85.00;
  
  // Variables to be populated dynamically
  let rAbandonmentRate = metrics.cartAbandonment || 68.4;
  let rAbandonedRevenue = 0;
  let rAbandonedCount = 0;
  let rDeviceStats: { device: string; rate: number; count: number; revenue: number }[] = [];
  let rChannelStats: { channel: string; rate: number; count: number; revenue: number }[] = [];
  let rProductStats: { name: string; rate: number; count: number; revenue: number }[] = [];
  let rAbandonedUsers: {
    userId: string;
    sessionId: string;
    timestamp: string;
    device: string;
    channel: string;
    lastStage: "Cart" | "Checkout";
    productName: string;
    abandonedValue: number;
  }[] = [];

  if (isSimulating || uploadedData.length === 0) {
    // ----------------- SIMULATED MODE -----------------
    rAbandonmentRate = metrics.cartAbandonment || 68.4;
    // Scale counts to match baseline metrics logically
    const totalVisCount = Math.round(184500 * (filters.dateRange === "7d" ? 0.23 : filters.dateRange === "90d" ? 3.0 : 1.0));
    const viewsCount = Math.round(totalVisCount * 0.74);
    const cartsCount = Math.round(viewsCount * 0.28);
    const checkoutsCount = Math.round(cartsCount * 0.38);
    const purchasesCount = metrics.orders || 1200;

    // sessions that added to cart but didn't buy
    rAbandonedCount = Math.max(10, cartsCount - purchasesCount);
    rAbandonedRevenue = Math.round(rAbandonedCount * baseAOV * 1.08);

    // Device breakdown
    rDeviceStats = [
      {
        device: "Mobile",
        rate: 74.5,
        count: Math.round(rAbandonedCount * 0.65),
        revenue: Math.round(rAbandonedCount * 0.65 * 68.20)
      },
      {
        device: "Desktop",
        rate: 58.2,
        count: Math.round(rAbandonedCount * 0.25),
        revenue: Math.round(rAbandonedCount * 0.25 * 105.00)
      },
      {
        device: "Tablet",
        rate: 65.8,
        count: Math.round(rAbandonedCount * 0.10),
        revenue: Math.round(rAbandonedCount * 0.10 * 88.00)
      }
    ];

    // Channel breakdown
    rChannelStats = [
      {
        channel: "Meta Social Ads",
        rate: 76.5,
        count: Math.round(rAbandonedCount * 0.35),
        revenue: Math.round(rAbandonedCount * 0.35 * baseAOV)
      },
      {
        channel: "Instagram Influencers",
        rate: 71.2,
        count: Math.round(rAbandonedCount * 0.22),
        revenue: Math.round(rAbandonedCount * 0.22 * baseAOV)
      },
      {
        channel: "Direct Traffic",
        rate: 69.5,
        count: Math.round(rAbandonedCount * 0.18),
        revenue: Math.round(rAbandonedCount * 0.18 * baseAOV)
      },
      {
        channel: "Google Organic",
        rate: 64.2,
        count: Math.round(rAbandonedCount * 0.15),
        revenue: Math.round(rAbandonedCount * 0.15 * baseAOV)
      },
      {
        channel: "Email Newsletter",
        rate: 48.8,
        count: Math.round(rAbandonedCount * 0.10),
        revenue: Math.round(rAbandonedCount * 0.10 * baseAOV)
      }
    ];

    // Product breakdown
    rProductStats = [
      {
        name: "Aura Leather Messenger Bag",
        rate: 78.4,
        count: Math.round(rAbandonedCount * 0.42),
        revenue: Math.round(rAbandonedCount * 0.42 * 185)
      },
      {
        name: "Starlight Pro Wireless Headphones",
        rate: 58.2,
        count: Math.round(rAbandonedCount * 0.28),
        revenue: Math.round(rAbandonedCount * 0.28 * 149)
      },
      {
        name: "Titan Fit Waterproof Smartwatch",
        rate: 48.1,
        count: Math.round(rAbandonedCount * 0.18),
        revenue: Math.round(rAbandonedCount * 0.18 * 65)
      },
      {
        name: "Sonic Wave Waterproof Speaker",
        rate: 38.5,
        count: Math.round(rAbandonedCount * 0.12),
        revenue: Math.round(rAbandonedCount * 0.12 * 89)
      }
    ];

    // Simulated Recent Ingestion Users (12 records)
    const mockChannels = ["Meta Social Ads", "Google Organic", "Instagram Influencers", "Email Newsletter", "Direct Traffic"];
    const mockDevices = ["Mobile", "Desktop", "Tablet"];
    const mockProducts = [
      "Aura Leather Messenger Bag",
      "Starlight Pro Wireless Headphones",
      "Titan Fit Waterproof Smartwatch",
      "Sonic Wave Waterproof Speaker"
    ];

    // Static seeded items to look professional & stable
    const baseSeeds = [
      { offsetSec: 42, dev: "Mobile", chan: "Meta Social Ads", cat: mockProducts[0], val: 185, stage: "Checkout" as const, uid: "USR-4091" },
      { offsetSec: 184, dev: "Mobile", chan: "Instagram Influencers", cat: mockProducts[1], val: 149, stage: "Cart" as const, uid: "USR-7215" },
      { offsetSec: 412, dev: "Desktop", chan: "Google Organic", cat: mockProducts[0], val: 185, stage: "Checkout" as const, uid: "USR-9481" },
      { offsetSec: 850, dev: "Mobile", chan: "Meta Social Ads", cat: mockProducts[2], val: 65, stage: "Cart" as const, uid: "USR-3021" },
      { offsetSec: 1510, dev: "Tablet", chan: "Direct Traffic", cat: mockProducts[3], val: 89, stage: "Checkout" as const, uid: "USR-1156" },
      { offsetSec: 2400, dev: "Desktop", chan: "Email Newsletter", cat: mockProducts[1], val: 149, stage: "Cart" as const, uid: "USR-8824" },
      { offsetSec: 3600, dev: "Mobile", chan: "Instagram Influencers", cat: mockProducts[0], val: 185, stage: "Checkout" as const, uid: "USR-5142" },
      { offsetSec: 5400, dev: "Mobile", chan: "Meta Social Ads", cat: mockProducts[2], val: 65, stage: "Checkout" as const, uid: "USR-2901" },
      { offsetSec: 7200, dev: "Desktop", chan: "Google Organic", cat: mockProducts[3], val: 89, stage: "Cart" as const, uid: "USR-1084" },
      { offsetSec: 9800, dev: "Mobile", chan: "Email Newsletter", cat: mockProducts[1], val: 149, stage: "Cart" as const, uid: "USR-6621" },
      { offsetSec: 14400, dev: "Desktop", chan: "Direct Traffic", cat: mockProducts[0], val: 185, stage: "Checkout" as const, uid: "USR-3450" },
      { offsetSec: 18000, dev: "Tablet", chan: "Meta Social Ads", cat: mockProducts[2], val: 65, stage: "Cart" as const, uid: "USR-8919" }
    ];

    rAbandonedUsers = baseSeeds.map((seed, idx) => {
      const stamp = new Date(Date.now() - seed.offsetSec * 1000);
      return {
        userId: seed.uid,
        sessionId: `SES-${8213 + idx}`,
        timestamp: stamp.toISOString(),
        device: seed.dev,
        channel: seed.chan,
        lastStage: seed.stage,
        productName: seed.cat,
        abandonedValue: seed.val
      };
    });

  } else {
    // ----------------- EXTRACT FROM INGESTED DATA RECORDS -----------------
    // 1) Filter record list relative to dates, channels, products, sizes
    const timestamps = uploadedData.map(r => new Date(r.timestamp).getTime()).filter(t => !isNaN(t));
    const latestTime = timestamps.length > 0 ? timestamps.reduce((max, t) => t > max ? t : max, timestamps[0]) : Date.now();
    const daysLimit = filters.dateRange === "7d" ? 7 : filters.dateRange === "90d" ? 90 : 30;
    const milliLimit = daysLimit * 24 * 60 * 60 * 1000;

    const filtered = uploadedData.filter(record => {
      // Date Range
      const recTime = new Date(record.timestamp).getTime();
      if (isNaN(recTime)) return false;
      if (latestTime - recTime > milliLimit) return false;

      // Region Filter
      if (filters.region !== "all") {
        const matchRegion = record.region.toLowerCase().includes(filters.region.toLowerCase()) || 
                            filters.region.toLowerCase().includes(record.region.toLowerCase());
        if (!matchRegion) return false;
      }

      // Device Filter
      if (filters.device !== "all") {
        if (record.device_type.toLowerCase() !== filters.device.toLowerCase()) return false;
      }

      // Traffic Resource (Channel)
      if (filters.channel !== "all") {
        const matchChannel = record.traffic_source.toLowerCase().includes(filters.channel.toLowerCase()) ||
                             filters.channel.toLowerCase().includes(record.traffic_source.toLowerCase());
        if (!matchChannel) return false;
      }

      // Product Filter
      if (filters.product !== "all") {
        const pNameLower = record.product_name.toLowerCase();
        const pIdLower = record.product_id.toLowerCase();
        const filterProdLower = filters.product.toLowerCase();
        if (!pNameLower.includes(filterProdLower) && !pIdLower.includes(filterProdLower)) {
          return false;
        }
      }

      return true;
    });

    // 2) Group events in memory by session ID
    interface SessionTrace {
      sessionId: string;
      userId: string;
      device: string;
      channel: string;
      hasCart: boolean;
      hasCheckout: boolean;
      hasPurchase: boolean;
      lastTimestamp: string;
      productsAdded: Set<string>;
      records: IngestedRecord[];
    }

    const sessionGroups = new Map<string, SessionTrace>();
    filtered.forEach(rec => {
      const sid = rec.session_id || "unspecified";
      if (!sessionGroups.has(sid)) {
        sessionGroups.set(sid, {
          sessionId: sid,
          userId: rec.user_id,
          device: rec.device_type || "Desktop",
          channel: rec.traffic_source || "Direct",
          hasCart: false,
          hasCheckout: false,
          hasPurchase: false,
          lastTimestamp: rec.timestamp,
          productsAdded: new Set<string>(),
          records: []
        });
      }

      const trace = sessionGroups.get(sid)!;
      trace.records.push(rec);
      if (rec.event_type === "cart") trace.hasCart = true;
      if (rec.event_type === "checkout") trace.hasCheckout = true;
      if (rec.event_type === "purchase") trace.hasPurchase = true;

      if (rec.event_type === "cart" || rec.event_type === "checkout") {
        if (rec.product_name) trace.productsAdded.add(rec.product_name);
      }

      if (new Date(rec.timestamp).getTime() > new Date(trace.lastTimestamp).getTime()) {
        trace.lastTimestamp = rec.timestamp;
      }
    });

    const sessionTraces = Array.from(sessionGroups.values());

    // 3) Filter trace arrays to find "Carts" and "Abandoners"
    const cartSessions = sessionTraces.filter(t => t.hasCart || t.hasCheckout);
    const completedPurchasedCartSessions = cartSessions.filter(t => t.hasPurchase);
    const abandonedCartSessions = cartSessions.filter(t => !t.hasPurchase);

    rAbandonedCount = abandonedCartSessions.length;
    rAbandonmentRate = cartSessions.length > 0 
      ? parseFloat(((rAbandonedCount / cartSessions.length) * 100).toFixed(2)) 
      : 0;

    // 4) Map users to details
    rAbandonedUsers = abandonedCartSessions.map(t => {
      const primaryProduct = Array.from(t.productsAdded)[0] || t.records[0]?.product_name || "Catalog Product";
      // Sum value based on product lookup table or default
      let totalAssessedVal = 0;
      if (t.productsAdded.size > 0) {
        t.productsAdded.forEach(p => {
          totalAssessedVal += getProductPrice(p, baseAOV);
        });
      } else {
        totalAssessedVal = baseAOV;
      }

      return {
        userId: t.userId || "USR-UNKNOWN",
        sessionId: t.sessionId,
        timestamp: t.lastTimestamp,
        device: t.device,
        channel: t.channel,
        lastStage: t.hasCheckout ? ("Checkout" as const) : ("Cart" as const),
        productName: primaryProduct,
        abandonedValue: totalAssessedVal
      };
    }).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    rAbandonedRevenue = rAbandonedUsers.reduce((sum, u) => sum + u.abandonedValue, 0);

    // 5) Breakdown metrics by Device (for carts)
    const deviceGroups = new Map<string, { totalCarts: number; abandonedCarts: number; revenueLost: number }>();
    cartSessions.forEach(t => {
      const d = t.device || "Desktop";
      if (!deviceGroups.has(d)) {
        deviceGroups.set(d, { totalCarts: 0, abandonedCarts: 0, revenueLost: 0 });
      }
      const grp = deviceGroups.get(d)!;
      grp.totalCarts++;
      if (!t.hasPurchase) {
        grp.abandonedCarts++;
        let val = 0;
        t.productsAdded.forEach(p => { val += getProductPrice(p, baseAOV); });
        if (t.productsAdded.size === 0) val = baseAOV;
        grp.revenueLost += val;
      }
    });

    rDeviceStats = Array.from(deviceGroups.entries()).map(([device, grp]) => ({
      device,
      rate: grp.totalCarts > 0 ? parseFloat(((grp.abandonedCarts / grp.totalCarts) * 100).toFixed(1)) : 0,
      count: grp.abandonedCarts,
      revenue: grp.revenueLost
    })).sort((a, b) => b.revenue - a.revenue);

    // 6) Breakdown metrics by Traffic Channel (for carts)
    const channelGroups = new Map<string, { totalCarts: number; abandonedCarts: number; revenueLost: number }>();
    cartSessions.forEach(t => {
      const c = t.channel || "Direct";
      if (!channelGroups.has(c)) {
        channelGroups.set(c, { totalCarts: 0, abandonedCarts: 0, revenueLost: 0 });
      }
      const grp = channelGroups.get(c)!;
      grp.totalCarts++;
      if (!t.hasPurchase) {
        grp.abandonedCarts++;
        let val = 0;
        t.productsAdded.forEach(p => { val += getProductPrice(p, baseAOV); });
        if (t.productsAdded.size === 0) val = baseAOV;
        grp.revenueLost += val;
      }
    });

    rChannelStats = Array.from(channelGroups.entries()).map(([channel, grp]) => ({
      channel,
      rate: grp.totalCarts > 0 ? parseFloat(((grp.abandonedCarts / grp.totalCarts) * 100).toFixed(1)) : 0,
      count: grp.abandonedCarts,
      revenue: grp.revenueLost
    })).sort((a, b) => b.revenue - a.revenue);

    // 7) Breakdown metrics by Product
    const productGroups = new Map<string, { totalCarts: number; abandonedCarts: number; revenueLost: number }>();
    sessionTraces.forEach(t => {
      t.productsAdded.forEach(pName => {
        if (!productGroups.has(pName)) {
          productGroups.set(pName, { totalCarts: 0, abandonedCarts: 0, revenueLost: 0 });
        }
        const grp = productGroups.get(pName)!;
        grp.totalCarts++;
        if (!t.hasPurchase) {
          grp.abandonedCarts++;
          grp.revenueLost += getProductPrice(pName, baseAOV);
        }
      });
    });

    rProductStats = Array.from(productGroups.entries()).map(([name, grp]) => ({
      name,
      rate: grp.totalCarts > 0 ? parseFloat(((grp.abandonedCarts / grp.totalCarts) * 100).toFixed(1)) : 0,
      count: grp.abandonedCarts,
      revenue: grp.revenueLost
    })).sort((a, b) => b.revenue - a.revenue).slice(0, 4);
  }

  // Safety fallbacks if filters empty the stats dataset
  if (rDeviceStats.length === 0) {
    rDeviceStats = [{ device: "All Streams", rate: rAbandonmentRate, count: rAbandonedCount, revenue: rAbandonedRevenue }];
  }
  if (rChannelStats.length === 0) {
    rChannelStats = [{ channel: "All Channels", rate: rAbandonmentRate, count: rAbandonedCount, revenue: rAbandonedRevenue }];
  }
  if (rProductStats.length === 0) {
    rProductStats = [{ name: "Catalog Products", rate: rAbandonmentRate, count: rAbandonedCount, revenue: rAbandonedRevenue }];
  }

  // Determine stage contributions to abandonment
  const checkoutAbandonedCount = rAbandonedUsers.filter(u => u.lastStage === "Checkout").length;
  const cartAbandonedCount = rAbandonedUsers.filter(u => u.lastStage === "Cart").length;
  const totalAbandonedInUsers = checkoutAbandonedCount + cartAbandonedCount;
  const checkoutContributionRate = totalAbandonedInUsers > 0 
    ? Math.round((checkoutAbandonedCount / totalAbandonedInUsers) * 100) 
    : 60; // default realistic fallback

  // Device Comparative Details
  const mobileStat = rDeviceStats.find(d => d.device.toLowerCase().includes("mobile"));
  const desktopStat = rDeviceStats.find(d => d.device.toLowerCase().includes("desktop"));
  const mobileLossRate = mobileStat ? mobileStat.rate : 74.5;
  const desktopLossRate = desktopStat ? desktopStat.rate : 58.2;
  const deviceVariance = parseFloat(Math.abs(mobileLossRate - desktopLossRate).toFixed(1));

  // Dynamic recommendations & structural alerts configuration
  const recommendations = [
    {
      title: "Optimized Mobile Touchpoint Friction",
      description: `Mobile users abandon carts ${deviceVariance}% more often than desktop users. Streamline viewport scaling and embed express digital payment wallets like Apple Pay or Google Pay.`,
      impact: "Reclaim up to 12% of mobile abandonment",
      severity: "medium" as const
    },
    {
      title: "Targeted Checkout Stage Simplification",
      description: `Checkout steps contribute ${checkoutContributionRate}% of overall cart abandonment. Minimize input requirements, disable account creation gatekeeps, and display shipping tiers proactively.`,
      impact: "Recover approximately 15% of checkout leaks",
      severity: "high" as const
    },
    {
      title: "Automated Lifecycle Recovery Sequence",
      description: `Direct acquisition paths represent $${(rAbandonedRevenue * 0.25).toLocaleString(undefined, { maximumFractionDigits: 0 })} in lost transaction revenue. Establish an high-affinity email sequence within 45 minutes of checkouts.`,
      impact: "Increases net cart capture rates by 5.5%",
      severity: "low" as const
    }
  ];

  // Dynamic alerts check
  const alerts: { title: string; desc: string; severity: "critical" | "warning"; suggestion: string }[] = [];
  
  if (rAbandonmentRate > 70) {
    alerts.push({
      title: `Critical Alert: Absolute Abandonment Exceeds Severe Threshold (${rAbandonmentRate}%)`,
      desc: "Cart leak levels are operating above optimal benchmarks. Key friction elements discovered inside payment checkout processing nodes.",
      severity: "critical",
      suggestion: "Enable a direct guest-checkout route and audit delivery fee transparency."
    });
  } else if (rAbandonmentRate > 60) {
    alerts.push({
      title: `Warning: Elevated Abandonment Alert (${rAbandonmentRate}%)`,
      desc: "Your shopping cart leak rate is slightly higher than average. Consistent with industry trends, but optimization is highly recommended.",
      severity: "warning",
      suggestion: "Optimize checkout page performance and speed up asset loading."
    });
  }

  if (mobileLossRate > 70) {
    alerts.push({
      title: `Mobile Cart Ingestion Friction Alert (${mobileLossRate}%)`,
      desc: "Mobile buyers are exiting cart processes at excessive rates. This constitutes a severe bottleneck in touch screen purchasing patterns.",
      severity: "critical",
      suggestion: "Implement express sticky checkout buttons on product screens."
    });
  }

  if (checkoutContributionRate > 55) {
    alerts.push({
      title: `Checkout Terminal Abandonment Alert (${checkoutContributionRate}% of all drops)`,
      desc: "The checkout stage is the primary driver of cart abandonment. Users are adding products with high intent but abandoning during shipping/payment stages.",
      severity: "warning",
      suggestion: "Proactively list hidden surcharges and tax tables on the initial basket page."
    });
  }

  // Filtered Abandoned Users table rendering
  const filteredUsersList = rAbandonedUsers.filter(u => {
    if (activeStageFilter === "All") return true;
    return u.lastStage.toLowerCase() === activeStageFilter.toLowerCase();
  });

  const formatCurrency = (val: number) => {
    if (val >= 1000000) return `$${(val / 1000000).toFixed(2)}M`;
    if (val >= 1000) return `$${(val / 1000).toFixed(1)}k`;
    return `$${val.toLocaleString()}`;
  };

  const getRelativeTime = (isoString: string) => {
    const diff = Date.now() - new Date(isoString).getTime();
    const mins = Math.max(1, Math.floor(diff / 60000));
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return new Date(isoString).toLocaleDateString();
  };

  return (
    <div id="cart-intelligence-root" className="space-y-6">
      
      {/* 1. Alerts Section (Top priority visual block is immediate, high-impact alerts) */}
      {alerts.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {alerts.slice(0, 2).map((alert, idx) => (
            <div
              key={idx}
              className={`p-4 rounded-xl border flex gap-3 text-left shadow-xs transition-transform duration-300 hover:scale-[1.01] ${
                alert.severity === "critical"
                  ? "bg-rose-55/20 border-rose-200/40 dark:bg-rose-950/10 dark:border-rose-900/35"
                  : "bg-amber-55/20 border-amber-200/45 dark:bg-amber-950/10 dark:border-amber-900/35"
              }`}
            >
              <div className="mt-1">
                <AlertTriangle
                  className={`h-5 w-5 ${
                    alert.severity === "critical" ? "text-rose-500 animate-pulse" : "text-amber-500"
                  }`}
                />
              </div>
              <div>
                <h4 className={`text-xs font-bold leading-tight ${alert.severity === "critical" ? "text-rose-700 dark:text-rose-400" : "text-amber-700 dark:text-amber-400"}`}>
                  {alert.title}
                </h4>
                <p className="text-[11px] text-gray-500 dark:text-zinc-400 mt-1 leading-relaxed">
                  {alert.desc}
                </p>
                <div className="mt-2.5 flex items-center gap-1.5 text-[10px] font-black font-mono">
                  <span className="text-indigo-600 dark:text-indigo-400 uppercase">SUGGESTION:</span>
                  <span className="text-gray-700 dark:text-zinc-200">{alert.suggestion}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 2. Executive Math Ledger Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        
        {/* Abandonment Rate */}
        <div className="p-4 rounded-xl border border-rose-200/35 dark:border-rose-950/30 bg-white dark:bg-zinc-900/50 flex flex-col justify-between text-left">
          <div>
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-wider">Cart Abandonment Rate</span>
              <span className="p-1 rounded bg-rose-500/10 text-rose-500 leading-none">
                <TrendingDown className="h-3.5 w-3.5" />
              </span>
            </div>
            <p className="text-3xl font-black text-rose-500 tracking-tight mt-1">{rAbandonmentRate}%</p>
          </div>
          <div className="text-[10px] text-gray-400 mt-2 font-mono flex items-center gap-1">
            <span>Industry Benchmark: 69.8%</span>
          </div>
        </div>

        {/* Abandoned Revenue */}
        <div className="p-4 rounded-xl border border-gray-200/60 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 flex flex-col justify-between text-left">
          <div>
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-wider">Abandoned Revenue Link</span>
              <span className="p-1 rounded bg-indigo-500/10 text-indigo-500 leading-none">
                <DollarSign className="h-3.5 w-3.5" />
              </span>
            </div>
            <p className="text-3xl font-black text-gray-800 dark:text-zinc-150 tracking-tight mt-1">{formatCurrency(rAbandonedRevenue)}</p>
          </div>
          <div className="text-[10px] text-gray-400 mt-2">
            Sum of cart item values abandoned this segment.
          </div>
        </div>

        {/* Total Abandoned Carts */}
        <div className="p-4 rounded-xl border border-gray-200/60 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 flex flex-col justify-between text-left">
          <div>
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-wider">Abandoned Count</span>
              <span className="p-1 rounded bg-teal-500/10 text-teal-500 leading-none">
                <ShoppingBag className="h-3.5 w-3.5" />
              </span>
            </div>
            <p className="text-3xl font-black text-gray-800 dark:text-zinc-150 tracking-tight mt-1">{rAbandonedCount.toLocaleString()}</p>
          </div>
          <div className="text-[10px] text-gray-450 mt-2">
            Total unique checkouts/baskets abandoned.
          </div>
        </div>

        {/* Potential Recovery Target (15%) */}
        <div className="p-4 rounded-xl border border-emerald-200/35 dark:border-emerald-950/25 bg-emerald-55/10 dark:bg-emerald-950/5 flex flex-col justify-between text-left">
          <div>
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-450 uppercase tracking-wider">15% Recovery Capture</span>
              <span className="p-1 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 leading-none">
                <CheckCircle className="h-3.5 w-3.5 font-bold" />
              </span>
            </div>
            <p className="text-3xl font-black text-emerald-600 dark:text-emerald-450 tracking-tight mt-1">{formatCurrency(rAbandonedRevenue * 0.15)}</p>
          </div>
          <div className="text-[10px] text-gray-400 mt-2">
            Target capture by resolving critical mobile/checkout blocks.
          </div>
        </div>

      </div>

      {/* 3. Breakdown Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Progress Bars for Device and Channel */}
        <div className="p-5 rounded-2xl border border-gray-200/60 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 text-left space-y-6">
          
          {/* Abandonment Rate By Device */}
          <div className="space-y-4">
            <div>
              <h3 className="text-xs font-black text-gray-400 dark:text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
                <Smartphone className="h-4 w-4 text-cyan-500" />
                <span>Cart Abandonment By Device</span>
              </h3>
              <p className="text-[10px] text-gray-400 leading-normal">
                Comparative analysis showcasing rates, counts and cash leakage by terminal.
              </p>
            </div>

            <div className="space-y-3 pt-1">
              {rDeviceStats.map((stat, idx) => (
                <div key={idx} className="space-y-1.5">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-gray-800 dark:text-zinc-200 flex items-center gap-1.5">
                      {stat.device === "Mobile" && <Smartphone className="h-3.5 w-3.5 text-gray-400" />}
                      {stat.device === "Desktop" && <Monitor className="h-3.5 w-3.5 text-gray-400" />}
                      {stat.device === "Tablet" && <Tablet className="h-3.5 w-3.5 text-gray-400" />}
                      <span>{stat.device}</span>
                    </span>
                    <span className="font-bold text-gray-900 dark:text-zinc-200 font-mono">
                      {stat.rate}% rate <span className="text-gray-400 font-normal">({stat.count.toLocaleString()} carts | <strong className="text-rose-500 font-semibold">{formatCurrency(stat.revenue)}</strong>)</span>
                    </span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-gray-100 dark:bg-zinc-800 overflow-hidden relative">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-indigo-600 transition-all duration-500"
                      style={{ width: `${stat.rate}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <hr className="border-gray-150 dark:border-zinc-800/80" />

          {/* Abandonment Rate By Traffic Source */}
          <div className="space-y-4">
            <div>
              <h3 className="text-xs font-black text-gray-400 dark:text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
                <TrendingDown className="h-4 w-4 text-indigo-500" />
                <span>By Traffic Acquisition Pipeline</span>
              </h3>
              <p className="text-[10px] text-gray-400 leading-normal">
                Analyzing leakage risks associated with original tracking referrers.
              </p>
            </div>

            <div className="space-y-3.5 pt-1">
              {rChannelStats.slice(0, 4).map((stat, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-gray-700 dark:text-zinc-300 truncate max-w-[140px]">{stat.channel}</span>
                    <span className="font-bold font-mono text-gray-800 dark:text-zinc-200">
                      {stat.rate}% <span className="text-[10px] text-gray-400 font-normal">({stat.count.toLocaleString()} carts | <strong className="text-rose-500 font-semibold">{formatCurrency(stat.revenue)}</strong>)</span>
                    </span>
                  </div>
                  <div className="h-1.5 w-full rounded-full bg-gray-100 dark:bg-zinc-800 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-indigo-500/80 transition-all duration-500"
                      style={{ width: `${stat.rate}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Most Abandoned Products Table */}
        <div className="p-5 rounded-2xl border border-gray-200/60 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 text-left flex flex-col justify-between">
          <div>
            <div className="border-b border-gray-100 dark:border-zinc-850 pb-3">
              <h3 className="text-xs font-black text-gray-400 dark:text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
                <ShoppingBag className="h-4 w-4 text-rose-500" />
                <span>Most Abandoned Products</span>
              </h3>
              <p className="text-[10px] text-gray-400 mt-0.5 leading-relaxed">
                Primary catalog items added to checkout cycles but frequently left behind.
              </p>
            </div>

            <div className="mt-4 space-y-4">
              {rProductStats.map((prod, idx) => {
                // Generate a mockup image color node matching product index
                const badgeThemes = [
                  "bg-cyan-500/10 text-cyan-600 border-cyan-500/20",
                  "bg-indigo-500/10 text-indigo-600 border-indigo-500/20",
                  "bg-teal-500/10 text-teal-600 border-teal-500/20",
                  "bg-rose-500/10 text-rose-600 border-rose-500/20"
                ];
                return (
                  <div key={idx} className="flex justify-between items-center text-xs p-2.5 rounded-xl border border-gray-100/50 dark:border-zinc-800 bg-gray-50/30 dark:bg-zinc-850/10 hover:bg-gray-100/40 dark:hover:bg-zinc-850/20 transition-all">
                    <div className="min-w-0 pr-3 flex items-center gap-3">
                      <div className="h-9 w-9 shrink-0 rounded-lg flex items-center justify-center bg-zinc-150 dark:bg-zinc-800 text-[10px] font-bold text-gray-500 font-mono">
                        #{idx + 1}
                      </div>
                      <div className="min-w-0">
                        <p className="font-semibold text-gray-950 dark:text-zinc-200 truncate">{prod.name}</p>
                        <p className="text-[10px] text-gray-400 mt-0.5">
                          Calculated value: <strong className="font-semibold text-gray-600 dark:text-zinc-350">{formatCurrency(prod.revenue / (prod.count || 1))} each</strong>
                        </p>
                      </div>
                    </div>
                    <div className="text-right shrink-0 space-y-0.5">
                      <p className="font-bold text-rose-500 font-mono">{prod.rate}% abandonment</p>
                      <p className="text-[10px] text-gray-400 font-mono">
                        {prod.count} carts | <span className="font-semibold text-rose-500">{formatCurrency(prod.revenue)}</span>
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-4 bg-indigo-500/5 border border-indigo-500/10 p-3 rounded-xl flex items-center justify-between text-left">
            <span className="text-[10px] text-gray-500 dark:text-zinc-400">
              Is your catalog suffering? Let's check user interactions.
            </span>
            <div className="flex items-center gap-1 text-[11px] font-black text-indigo-600 dark:text-indigo-400 cursor-pointer hover:underline">
              <span>Automate reminders</span>
              <ArrowRight className="h-3 w-3" />
            </div>
          </div>
        </div>

      </div>

      {/* 4. Active Recommendation Directives Carousel */}
      <div className="p-5 rounded-2xl border border-indigo-200/55 dark:border-indigo-900/35 bg-gradient-to-tr from-indigo-55/10 to-transparent dark:from-indigo-950/10 dark:to-transparent text-left">
        <div className="flex justify-between items-center border-b border-gray-150 dark:border-zinc-850 pb-3">
          <div>
            <h3 className="text-xs font-black text-indigo-700 dark:text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
              <Lightbulb className="h-4 w-4" />
              <span>Cart Abandonment Directives</span>
            </h3>
            <p className="text-[10px] text-gray-400 mt-0.5">
              Direct recommendations computed dynamically based on current cohort friction indicators.
            </p>
          </div>
          
          <div className="flex gap-1.5">
            {recommendations.map((_, rIdx) => (
              <button
                key={rIdx}
                onClick={() => setActiveRecIndex(rIdx)}
                className={`h-2.5 w-2.5 rounded-full transition-all ${
                  activeRecIndex === rIdx
                    ? "bg-indigo-600 w-5"
                    : "bg-gray-300 dark:bg-zinc-700"
                }`}
              />
            ))}
          </div>
        </div>

        <div className="mt-4 grid grid-cols-1 md:grid-cols-4 gap-6 items-center">
          <div className="md:col-span-3 space-y-2">
            <div className="flex items-center gap-2">
              <span className={`text-[9px] font-black p-0.5 px-2 rounded-full uppercase tracking-widest ${
                recommendations[activeRecIndex].severity === "high"
                  ? "bg-rose-500/10 text-rose-500"
                  : recommendations[activeRecIndex].severity === "medium"
                  ? "bg-amber-500/10 text-amber-500"
                  : "bg-cyan-500/10 text-cyan-500"
              }`}>
                {recommendations[activeRecIndex].severity} priority directive
              </span>
              <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-450 bg-emerald-500/10 p-0.5 px-2 rounded-full font-mono">
                Impact: {recommendations[activeRecIndex].impact}
              </span>
            </div>
            
            <h4 className="text-sm font-bold text-gray-950 dark:text-white">
              {recommendations[activeRecIndex].title}
            </h4>
            
            <p className="text-xs text-gray-500 dark:text-zinc-400 leading-relaxed">
              {recommendations[activeRecIndex].description}
            </p>
          </div>

          <div className="bg-white dark:bg-zinc-850 border border-gray-100 dark:border-zinc-800 p-4 rounded-xl flex flex-col justify-between h-full shadow-xs">
            <div>
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Calculated Return</span>
              <p className="text-base font-black text-emerald-600 dark:text-emerald-400 font-mono mt-1 leading-none">
                {activeRecIndex === 0 
                  ? formatCurrency(rAbandonedRevenue * 0.12)
                  : activeRecIndex === 1
                  ? formatCurrency(rAbandonedRevenue * 0.15)
                  : formatCurrency(rAbandonedRevenue * 0.055)
                }
              </p>
              <p className="text-[9px] text-gray-400 mt-1.5 leading-tight">
                Projected recovered revenue in next 30 days scenario.
              </p>
            </div>
            <button
              onClick={() => alert(`Initiating workflow automation setup for "${recommendations[activeRecIndex].title}"`)}
              className="mt-3 text-2xs uppercase font-extrabold p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition text-center"
            >
              Exemplar action flow
            </button>
          </div>
        </div>
      </div>

      {/* 5. In-Depth Abandoned Customer Ledger Table */}
      <div className="p-5 rounded-2xl border border-gray-200/60 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 text-left">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-gray-150 dark:border-zinc-850 pb-3">
          <div>
            <h3 className="text-xs font-black text-gray-400 dark:text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
              <Clock className="h-4 w-4" />
              <span>Real-Time Abandoned Cohort Tracker</span>
            </h3>
            <p className="text-[10px] text-gray-400 mt-0.5 leading-relaxed">
              Granular auditing stream displaying recent high-intent clients who abandoned shopping states.
            </p>
          </div>

          {/* Filtering Toggles specific to checkout stages */}
          <div className="flex bg-gray-100 dark:bg-zinc-850 p-1 rounded-xl text-[10px] font-bold">
            <button
              onClick={() => setActiveStageFilter("All")}
              className={`p-1.5 px-3 rounded-lg transition-colors ${activeStageFilter === "All" ? "bg-white dark:bg-zinc-800 text-indigo-600 dark:text-cyan-400 shadow-xs" : "text-gray-500"}`}
            >
              All Stages ({rAbandonedUsers.length})
            </button>
            <button
              onClick={() => setActiveStageFilter("Cart")}
              className={`p-1.5 px-3 rounded-lg transition-colors ${activeStageFilter === "Cart" ? "bg-white dark:bg-zinc-800 text-indigo-600 dark:text-cyan-400 shadow-xs" : "text-gray-500"}`}
            >
              Cart Stage ({rAbandonedUsers.filter(u => u.lastStage === "Cart").length})
            </button>
            <button
              onClick={() => setActiveStageFilter("Checkout")}
              className={`p-1.5 px-3 rounded-lg transition-colors ${activeStageFilter === "Checkout" ? "bg-white dark:bg-zinc-800 text-indigo-600 dark:text-cyan-400 shadow-xs" : "text-gray-500"}`}
            >
              Checkout Stage ({rAbandonedUsers.filter(u => u.lastStage === "Checkout").length})
            </button>
          </div>
        </div>

        <div className="mt-4 overflow-x-auto">
          {filteredUsersList.length > 0 ? (
            <table className="w-full text-xs text-left text-gray-500 dark:text-zinc-400">
              <thead className="text-[9.5px] font-black uppercase text-gray-400 dark:text-zinc-500 border-b border-gray-150 dark:border-zinc-800">
                <tr>
                  <th scope="col" className="py-2.5 px-2">Segment User</th>
                  <th scope="col" className="py-2.5 px-2">Device & Channel</th>
                  <th scope="col" className="py-2.5 px-2">Last Touchpoint</th>
                  <th scope="col" className="py-2.5 px-2">Abandoned Items</th>
                  <th scope="col" className="py-2.5 px-2 text-right">Lost Value</th>
                  <th scope="col" className="py-2.5 px-2 text-right">Activity Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-150 dark:divide-zinc-850 font-medium">
                {filteredUsersList.map((user, index) => (
                  <tr key={index} className="hover:bg-gray-55/35 dark:hover:bg-zinc-850/15 transition-colors">
                    <td className="py-3 px-2">
                      <p className="font-bold text-gray-900 dark:text-white font-mono">{user.userId}</p>
                      <span className="text-[9.5px] text-gray-400 font-mono">Session {user.sessionId}</span>
                    </td>
                    <td className="py-3 px-2">
                      <div className="flex flex-col">
                        <span className="text-gray-750 dark:text-zinc-250 font-semibold">{user.device}</span>
                        <span className="text-[10px] text-gray-400">{user.channel}</span>
                      </div>
                    </td>
                    <td className="py-3 px-2">
                      <span className={`inline-flex px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                        user.lastStage === "Checkout"
                          ? "bg-amber-500/10 text-amber-500 border border-amber-500/20"
                          : "bg-indigo-500/10 text-indigo-500 border border-indigo-500/20"
                      }`}>
                        {user.lastStage} Stage
                      </span>
                    </td>
                    <td className="py-3 px-2">
                      <p className="text-gray-800 dark:text-zinc-300 font-semibold truncate max-w-[210px]">{user.productName}</p>
                    </td>
                    <td className="py-3 px-2 text-right font-bold text-rose-500 font-mono">
                      {formatCurrency(user.abandonedValue)}
                    </td>
                    <td className="py-3 px-2 text-right font-bold text-gray-700 dark:text-zinc-300 font-mono">
                      {getRelativeTime(user.timestamp)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="text-center py-8 text-gray-400 space-y-2">
              <Inbox className="h-8 w-8 mx-auto text-gray-300" />
              <p className="text-[11px] font-bold">No abandoned workflows match your stage filters.</p>
            </div>
          )}
        </div>
      </div>

    </div>
  );
}
