import { IngestedRecord, GlobalFilters, UnifiedMetrics, ValidationSummary } from "../types";
import { DataProcessor } from "./dataProcessor";
import { MetricsEngine } from "./metricsEngine";

export class AnalyticsService {
  private static liveStore: IngestedRecord[] = [];

  /**
   * Resets active dataset store with parsed values
   */
  public static setStore(records: IngestedRecord[]): void {
    this.liveStore = records;
  }

  /**
   * Extends active dataset store with additional parsed values
   */
  public static appendStore(records: IngestedRecord[]): void {
    this.liveStore = [...this.liveStore, ...records];
  }

  /**
   * Retrieves the current state of ingested elements
   */
  public static getStore(): IngestedRecord[] {
    return this.liveStore;
  }

  /**
   * Clears the current state of ingested elements
   */
  public static clearStore(): void {
    this.liveStore = [];
  }

  /**
   * Complete validation and pipeline ingestion.
   * Runs schema validation. If valid, cleans and sets standard stores.
   */
  public static processIngestion(rawRows: any[]): {
    validation: ValidationSummary;
    records: IngestedRecord[];
  } {
    const validation = DataProcessor.validate(rawRows);
    
    if (!validation.isValid) {
      return {
        validation,
        records: []
      };
    }

    const records = DataProcessor.transformAndClean(rawRows);
    this.setStore(records);

    return {
      validation,
      records
    };
  }

  /**
   * Computes clean dashboards using global filters over the current live data store
   */
  public static generateDashboardMetrics(filters: GlobalFilters): UnifiedMetrics {
    return MetricsEngine.compute(this.liveStore, filters);
  }
}
