import { IngestedRecord, ValidationSummary } from "../types";

export class DataProcessor {
  private static REQUIRED_COLUMNS = [
    "timestamp",
    "user_id",
    "session_id",
    "product_id",
    "product_name",
    "category",
    "event_type",
    "traffic_source",
    "device_type",
    "region",
    "revenue"
  ];

  /**
   * Normalizes keys of a raw object to trim whitespace and lowercase
   */
  public static normalizeKeys(row: Record<string, any>): Record<string, any> {
    const normalized: Record<string, any> = {};
    for (const key of Object.keys(row)) {
      normalized[key.trim().toLowerCase()] = row[key];
    }
    return normalized;
  }

  /**
   * Cleans and formats parsed rows into standard typesafe IngestedRecord instances
   */
  public static transformAndClean(rawRows: any[]): IngestedRecord[] {
    return rawRows.map(rawRow => {
      const row = this.normalizeKeys(rawRow);
      
      // Revenue cleaning: strip "$", commas, trim whitespace, fallback to 0
      let revenueVal = 0;
      if (row["revenue"] !== undefined && row["revenue"] !== null) {
        const parsedStr = String(row["revenue"]).replace(/[$,\s]/g, "");
        revenueVal = parseFloat(parsedStr) || 0;
      }

      // Timestamp ISO conversion
      let cleanTimestamp = new Date().toISOString();
      if (row["timestamp"]) {
        const timeVal = new Date(row["timestamp"]);
        if (!isNaN(timeVal.getTime())) {
          cleanTimestamp = timeVal.toISOString();
        }
      }

      return {
        timestamp: cleanTimestamp,
        user_id: String(row["user_id"] || "").trim() || "anonymous",
        session_id: String(row["session_id"] || "").trim() || "session_unspecified",
        product_id: String(row["product_id"] || "").trim() || "p_unspecified",
        product_name: String(row["product_name"] || "").trim() || "Unnamed Product",
        category: String(row["category"] || "").trim() || "Uncategorized",
        event_type: String(row["event_type"] || "view").trim().toLowerCase(),
        traffic_source: String(row["traffic_source"] || "Direct").trim(),
        device_type: String(row["device_type"] || "Desktop").trim(),
        region: String(row["region"] || "Global").trim(),
        revenue: revenueVal
      };
    });
  }

  /**
   * Full dataset validator highlighting duplicates, broken stamps, and missing metrics
   */
  public static validate(rawRows: any[]): ValidationSummary {
    const errors: string[] = [];
    const missingColumns: string[] = [];

    if (!rawRows || rawRows.length === 0) {
      return {
        isValid: false,
        totalRecords: 0,
        duplicateCount: 0,
        emptyValueCount: 0,
        invalidTimestampCount: 0,
        missingColumns: [],
        errors: ["Payload contains no data rows to process."]
      };
    }

    const firstRowNormalized = this.normalizeKeys(rawRows[0]);
    const presentColumns = Object.keys(firstRowNormalized);

    for (const col of this.REQUIRED_COLUMNS) {
      if (!presentColumns.includes(col)) {
        missingColumns.push(col);
      }
    }

    if (missingColumns.length > 0) {
      errors.push(`Required headers missing in data schema: ${missingColumns.join(", ")}`);
      return {
        isValid: false,
        totalRecords: rawRows.length,
        duplicateCount: 0,
        emptyValueCount: 0,
        invalidTimestampCount: 0,
        missingColumns,
        errors
      };
    }

    let duplicateCount = 0;
    let emptyValueCount = 0;
    let invalidTimestampCount = 0;
    const seenRows = new Set<string>();

    for (const rawRow of rawRows) {
      const row = this.normalizeKeys(rawRow);
      const rowString = JSON.stringify(row);

      if (seenRows.has(rowString)) {
        duplicateCount++;
      } else {
        seenRows.add(rowString);
      }

      let rowHasEmpty = false;
      for (const col of this.REQUIRED_COLUMNS) {
        const val = row[col];
        if (val === undefined || val === null || String(val).trim() === "") {
          emptyValueCount++;
          rowHasEmpty = true;
        }
      }

      const tsVal = row["timestamp"];
      if (tsVal) {
        const parsedDate = new Date(tsVal);
        if (isNaN(parsedDate.getTime())) {
          invalidTimestampCount++;
        }
      } else if (!rowHasEmpty) {
        invalidTimestampCount++;
      }
    }

    if (duplicateCount > 0) {
      errors.push(`Identified ${duplicateCount} duplicate transaction row values.`);
    }
    if (emptyValueCount > 0) {
      errors.push(`Found ${emptyValueCount} cell values that are blank inside key columns.`);
    }
    if (invalidTimestampCount > 0) {
      errors.push(`Found ${invalidTimestampCount} timestamps with unparseable string formats.`);
    }

    const isValid = missingColumns.length === 0 && errors.length === 0;

    return {
      isValid,
      totalRecords: rawRows.length,
      duplicateCount,
      emptyValueCount,
      invalidTimestampCount,
      missingColumns,
      errors
    };
  }
}
